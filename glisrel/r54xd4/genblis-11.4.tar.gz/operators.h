/* @(#)operators.h	1.4   7/23/98 */

void oper1();
void oper2();
void oper3();
void oper4();
void oper5();
void oper6();
void oper7();
FLAG satis_con();
void find_range();
int irange_ran();
double get_F();
void oper8();
