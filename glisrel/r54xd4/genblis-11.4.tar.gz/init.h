/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/




/* @(#)init.h	11.4   7/23/98 */

#include <stdio.h>
#include "parms.h"
#include "unif.h"

extern integer genoudseed ;
extern integer bootseed ;

/* functions declared in init.c */
void readsample(char **fullsamplename, double **fullsampledata, int ngroups,
		int *numobsv, int *novarsv);
void readbootd(unsigned short int *bootdata, int numobs, int nboots);
void createbootd(unsigned short int **bootdata, int *numobsv, int ngroups,
		 int nboots);
void samplestats(double **obsdata, int ngroups, int *numobsv, int *novarsv,
		 int weightflag, double **weightdata);
void record_dump(double *record, int nparms, char *fname, long int number);
void setup_record(int nparms, int ncases, int nboots);
void printspecs(int what, int recordlocation);
void definemodel();
int parsemodel(FILE *fmodel);
int boundchk(double *X);
void onboundset(int fromgspec, int togspec, int bhitn, int *bhitvec);
void dumpbootdata(unsigned short int *bootdata, int *numobsv, int ngroups,
		  int nboots);
long int countcases();
