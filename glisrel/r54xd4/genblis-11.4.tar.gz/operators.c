/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html


   Some of the code in this file was adapted from an early version of
   GENOCOP I (Zbigniew Michalewicz, zbyszek@uncc.edu).  For information
   about GENOCOP III please see
   http://www.coe.uncc.edu/~gnazhiya/gchome.html.
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/


#include "data.h"
#include "genoud.h"
#include "operators.h"
#include "evaluate.h"
#include "unif.h"

static char *sccsversion = "@(#)operators.c	11.4   7/23/98";


void oper1(parent,fin_mat,rc)
VECTOR parent;  /*The parent vector*/
MATRIX fin_mat; /*The final matrix*/
INDEX rc;       /*Row and column of the final matrix*/
{
  int comp,i;
  double llim,ulim;/*Lower and Upper limits of the value to be mutated*/

  comp = irange_ran(1,rc.c-2);

  /*Finding the lower and upper limits between which the values are to be mutated*/
  find_range(&llim,&ulim,comp,fin_mat,rc,parent);

  /*Find a random value between the lower and the upper limits, to substitute*/
  /*for the old value*/
  parent[comp] = frange_ran(llim,ulim);
}



void oper2(parent,fin_mat,rc)
VECTOR parent;  /*The parent vector*/
MATRIX fin_mat; /*The final matrix*/
INDEX rc;       /*Row and column of the final matrix*/
{
  int comp,i;
  double llim,ulim;/*Lower and Upper limits of the value to be mutated*/

  comp = irange_ran(1,rc.c-2);

  /*Finding the lower and upper limits between which the values are to be mutated*/
  find_range(&llim,&ulim,comp,fin_mat,rc,parent);

  /*Replace either the lower limit or the upper limit at random,*/
  /*for the old value*/
  parent[comp] = (flip() == TAIL) ? llim : ulim;
}


void oper3(parent,fin_mat,rc,T,t,B)
VECTOR parent;
MATRIX fin_mat;
INDEX rc;
unsigned long T;    /*Total number of generations*/
unsigned long t;    /*Current generation number*/
int B;
{
  int comp,i;
  double llim,ulim;

  comp = irange_ran(1,rc.c-2);
  find_range(&llim,&ulim,comp,fin_mat,rc,parent);

  /*From the current value of the component to be mutated, chooose at random*/
  /*whether to mutate with a lesser value or a greater value*/
  /*Then find a value lesser or greater than the original value from the*/
  /*function get_f()*/
  parent[comp] = (flip() == TAIL) ? parent[comp]-get_F(T,t,parent[comp]-llim,B) :
                                     parent[comp]+get_F(T,t,ulim-parent[comp],B);
}



/* GENOUD Polytope Crossover */
void oper4(p,p2use,x2_vari)
MATRIX p;  /*The parents chosen for crossover*/
int x2_vari,   /* Length of the parameter vector (cols in p) */
    p2use;     /* number of parents (rows) in p */
{
  double A[MAX_VAR+1], sum;
  int    i,k;

  sum=0.0;
  for (k=1; k<=p2use; k++) {
    do
      A[k] = frange_ran(0.0,1.0);
    while (A[k]==0.0);                   /* insure A[k] is above 0.0 */
    sum += A[k];
  }
  sum = 1.0/sum;
  for (k=1; k<=p2use; k++) {    /* rescale A[k] to sum to 1.0 */
    A[k] *= sum;
  }

  for(i=1; i<=x2_vari; i++) {
    sum = p[1][i] * A[1];
    for (k=2; k<=p2use; k++)
      sum += p[k][i] * A[k];
    p[1][i] = sum;
  }
}



void oper5(p1,p2,STEP,rc,fin_mat)
VECTOR p1,p2;   /*The two parents for crossing over*/
INDEX rc;       /*Row and column of the final matrix*/
MATRIX fin_mat; /*The final matrix*/
int    STEP;    /*Parameter for the crossover*/
{
  static MATRIX child = NULL;
  static IVECTOR next = NULL;
  FLAG _CHECK1 = FALSE,/*Check to see if the newly created vectors satisfies the*/
       _CHECK2 = FALSE;/*set of constraints*/
  int i,n=1,cut, comp, setval, nparms=rc.c-2;
  double nsrat;

  if (child == NULL) {
    child = matrix(1,2,1,MAX_VAR);
    next = ivector(1, MAX_VAR);
  }

  /*Get a random number of points on the vector for crossover*/
  cut = irange_ran(1,nparms);
  setval = 0;
  if (cut > nparms/2) {
    setval = 1;
    cut = nparms - cut;
  }
  for(i=1; i<=nparms; i++) {
    next[i] = setval;
  }
  setval = 1-setval;
  for(i=1; i<=cut; i++) {
    do
      comp = irange_ran(1, nparms);
    while (next[comp] == setval);
    next[comp] = setval;
  }
  
  /*Copy the parent vectors on to the child vectors*/
  for(i=1; i<=nparms; i++) {
    if (next[i] == 0) {
      child[1][i] = p1[i];
      child[2][i] = p2[i];
    }
  }
  do {
    nsrat = (double)n/(double)STEP ;
    /*Cross the two vectors*/
    for(i=1; i<=nparms; i++) {
      if (next[i] == 1) {
	child[1][i] = p1[i] * nsrat + p2[i] * (1.0-nsrat);
	child[2][i] = p2[i] * nsrat + p1[i] * (1.0-nsrat);
      }
    }

    /*Check to see if they satisfy the constraints*/
    _CHECK1 = satis_con(child[1],fin_mat,rc);
    _CHECK2 = satis_con(child[2],fin_mat,rc);
    n++;
    /*If the constraints not satisfied, then generate another*/
    /*set of crossed over values*/
   } while((n<=STEP) && ((_CHECK1 == FALSE) || (_CHECK2 == FALSE)));

  for(i=1; i<=nparms; i++)
    {
      p1[i] = child[1][i];
      p2[i] = child[2][i];
    }
}





void oper6(parent,fin_mat,rc,T,t,B)
VECTOR parent;
MATRIX fin_mat;
INDEX rc;
unsigned long T;    /*Total number of generations*/
unsigned long t;    /*Current generation number*/
int B;
{
  int  i, nparms=rc.c-2;
  double llim,ulim;

  for (i=1; i<=nparms; i++)
    {
       find_range(&llim,&ulim,i,fin_mat,rc,parent);

       /*From the current value of the component to be mutated, chooose at random*/
       /*whether to mutate with a lesser value or a greater value*/
       /*Then find a value lesser or greater than the original value from the*/
       /*function get_f()*/
       parent[i] = (flip() == TAIL) ? parent[i]-get_F(T,t,parent[i]-llim,B) :
                                          parent[i]+get_F(T,t,ulim-parent[i],B);
    }
}




void oper7(p1,p2,rc,fin_mat)
VECTOR p1,p2;   /*The two parents for crossing over*/
INDEX rc;       /*Row and column of the final matrix*/
MATRIX fin_mat; /*The final matrix*/
{
  static VECTOR child = NULL;
  FLAG _CHECK = FALSE;/*Check to see if the newly created vector satisfies the*/
                      /*set of constraints*/
  int i,n=2,tries=10, nparms=rc.c-2;
  double A;

  if (child == NULL)
    child = vector(1,MAX_VAR);

  do
    {
      A = frange_ran(0.0,1.0);
      for(i=1; i<=nparms; i++)
        child[i] =   A * (p2[i] - p1[i]) + p2[i];

      /*Check to see if it satisfies the constraints*/
      _CHECK = satis_con(child,fin_mat,rc);
      n++;
      /*If the constraints not satisfied, then try again */
    }
  while((n<=tries) && (_CHECK == FALSE));

  if (_CHECK)
    for(i=1; i<=nparms; i++)
      p1[i] = child[i];
}




FLAG satis_con(child,fin_mat,rc)
VECTOR child;   /*The vector to be checked for violation of constriants*/
MATRIX fin_mat; /*The final matrix*/
INDEX rc;       /*Row and column of the final matrix*/
{
  int i,j;
  double tot;


  for(j=1; j<=rc.c-2; j++)
    if((child[j] > fin_mat[j][rc.c]) || (child[j] < fin_mat[j][1]))
      return(FALSE);

  /*Substitute the values for all the variables, with the new values of*/
  /*the vector passed and check if the limits are crossed*/
  for(j=1; j<=rc.r; j++)
    {
      tot = 0.0;
      for(i=2; i<=rc.c-1; i++)
        tot = tot + fin_mat[j][i] * child[i-1];

      /*If the limits are crossed, return FALSE*/
      if((tot < fin_mat[j][1]) || (tot > fin_mat[j][rc.c]))
        return(FALSE);
    }

  /*If the limits are not crossed, return TRUE*/
  return(TRUE);
}




void find_range(llim,ulim,comp,fin_mat,rc,parent)
double *llim,*ulim;/*Upper and lower limits*/
int comp;         /*Component of the vector to be mutated*/
INDEX rc;         /*Row and column of the final matrix*/
MATRIX fin_mat;   /*The final matrix*/
VECTOR parent;         /*The vector with the values of the variables*/
{
  int i,j;
  double tot,templ,tempu,temp;
  FLAG _CHANGE=FALSE;

  /*Replace the values of the variables, and for the values of the vectors*/
  /*except the one which is to be mutated*/
  /*Find the lower and upper limits within which the mutation component's*/
  /*value should be found*/
  for(j=1; j<=rc.r; j++)
    if(fin_mat[j][comp+1] != 0.0)
      {
        tot = 0.0;
        for(i=2; i<=rc.c-1; i++)
          if(i!=comp+1)
            tot = tot + fin_mat[j][i] * parent[i-1];

        templ = (fin_mat[j][1] - tot) / fin_mat[j][comp+1];
        tempu = (fin_mat[j][rc.c] - tot) / fin_mat[j][comp+1];

        if(fin_mat[j][comp+1]<0)
          swap(&templ,&tempu);


/*      if(templ > tempu)
          swap(&templ,&tempu);
*/
        if(!_CHANGE)
          {
            *llim = templ;
            *ulim = tempu;
            _CHANGE = TRUE;
          }
        else
          {
            if(*llim < templ)
              *llim = templ;
            if(*ulim > tempu)
              *ulim = tempu;
          }
      }
}



int irange_ran(llim,ulim)
int ulim,llim;
{
  int num;

  do
    num =  llim + ((int) ((newrand()*(long)(ulim-llim+1))/(long) 65535));
  while ((num < llim) || (num > ulim));
  return(num);
}



double get_F(T,t,y,B)
unsigned long t,T;
int           B;
double         y;
{
  double factor;

  factor =  (double) pow(1.0 - (double)t/(double)T,(double)B);
  factor = factor * frange_ran(0.0,1.0);
  if (factor < 0.00001)
    factor = 0.00001;
  return(y * factor);
}





void oper8(parent,fin_mat,rc,domains)
VECTOR parent;  /*The parent vector*/
MATRIX fin_mat; /*The final matrix*/
INDEX rc;       /*Row and column of the final matrix*/
MATRIX domains; /* boundaries */
{
  extern void dfgsmin(double *p, int n, double gtol, int *iter,
		      double *fret, double *hessin);
  int ii, j, iterations, nofvars, btest;
  double gtol, fitvalue;
  double A, B;
  
  extern int observedy, latenty, runvars, runcases;
  static double *work, *parm, *hessin;
  static int firsttime=0;

  if (firsttime==0) {
    work  = (double *) malloc((runvars+1)*sizeof(double));
    parm  = (double *) malloc((runvars)*sizeof(double));
    hessin  = (double *) malloc((runvars*runvars+runvars)*sizeof(double));
    firsttime=1;
  }
  
  A = frange_ran(0.0,1.0);
  B = 1.0 - A;

  nofvars=runvars;  
  gtol=0.0000000001;
  iterations=100;
  for (ii=1;ii<=runvars;ii++) 
    {
      parm[ii-1]= parent[ii];
    }
  fitvalue = 1000.0;
  dfgsmin(parm, nofvars, gtol, &iterations, &fitvalue, hessin);

  for (j=0; j<20; j++) 
    {
      btest = 0;
      for (ii=1; ii<=runvars; ii++) 
	{
	  work[ii] = A * parm[ii-1] + B * parent[ii];
	  btest = (domains[ii][1] > work[ii]) || (work[ii] > domains[ii][3]) ;
	  /* shrink point until all parameters are in bounds */
	  if (btest) 
	    {
	      fprintf(output,"KILLING: BOUNDARY TRIGGER IN BFGS OPER(8). FIT:%10.8lf\n",fitvalue);
	      break;
	    }
	}
      if (btest) break;
      A *= 0.5 ;
      B = 1.0 - A;
    }
  if (j<20) 
    { 
      /* leave parent unchanged if not in boundary after 20 halvings */
      for (ii=1; ii<=runvars; ii++) 
	{
	  parent[ii] = work[ii];
	}
    }
} /* end of function */
