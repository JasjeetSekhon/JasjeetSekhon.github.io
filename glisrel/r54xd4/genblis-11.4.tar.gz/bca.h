/* @(#)bca.h	1.4   7/23/98 */

int bcacmp(double *a, double *b);
void fitfprt(int nparms, int ncases, int nbused, int nboots,
	     double *out, double fitml);
void allfitfunc(int nparms, int ncases, int nboots);
void adjfitfunc(int nparms, int ncases, int nboots);
void subfitfunc(int nparms, int ncases, int nboots);
void bcacore(int nparms, int ncases, int nbused, int nboots, int *bulist,
	     int adjflag);
void allbca(int nparms, int ncases, int nboots);
void adjbca(int nparms, int ncases, int nboots);
void subbca(int nparms, int ncases, int nboots);
double nrmcdfs(double x);
double inrmcdf(double ppp);
void bca(int nparms, int ncases, int nboots);
