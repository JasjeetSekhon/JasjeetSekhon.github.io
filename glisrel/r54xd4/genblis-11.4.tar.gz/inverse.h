/* @(#)inverse.h	1.4   7/23/98 */

void ludcmp(double *a, int n, int *indx, double *d);
void lubksb(double *a, int *indx, double *b, int n);
int ludcmpH(double *a, int n, int *indx, double *d);

