/* @(#)gradient.h	1.4   7/23/98 */

void gradient(double *X, double *p);
void set_der(double *pp, double *der_lambda_y, 
	     double *der_theta_epsilon,
	     double *der_beta,
	     double *der_psi);
