/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include "data.h"
#include "numgrads.h"

#ifdef __CYGWIN32__
int signgam = 0;
#endif

static char *sccsversion = "@(#)numgrads.c	11.4   7/23/98";

/* array of estimated accuracies */
double *epsacc;

/* array of estimated optimal intervals */
double *optint;

/* estimate accuracy */
/* see Gill, Murray and Wright, 1981, "Practical Optimization," p. 337 */

double **eaccuracy(int nparms, int ndiffs, double h, double *invals,
		   double *wrk, double (*func)(double *))
{
  static double **table = NULL;
  static int tndiffs = 0;

  int i,j,k, idx;
  int nsteps = 1+2*ndiffs, nrows = nparms*nsteps, ncols = ndiffs+1;
  double u, huse, v, hchk;
  double scale = 2.0*pow(10.0,6.0);
  double hmax = 0.1;

  /* allocate storage for the table of differences to be returned */
  if (table == NULL || tndiffs != ndiffs) {
    table = (double **) malloc(ncols*sizeof(double *));
    for (i=0; i<ncols; i++)
      table[i] = (double *) calloc(nrows, sizeof(double));
    tndiffs = ndiffs;
  }

  /* evaluate func at the input point */
  u = func(invals);
  for (i=0; i<nparms; i++) table[0][i*nsteps] = u;

  /* copy the parameter values for point at which to evaluate the gradient */
  for (i=0; i<nparms; i++) wrk[i] = invals[i];

  /* evaluate the offsets */
  for (i=0; i<nparms; i++) {
    /* make sure huse is sufficiently small */
    v = fabs(invals[i]);
    huse = h;
    if (v>MACHEPS*scale) {
      while (huse > v/scale)
	huse *= 0.1;
    }
    /* but not too small */
    while (huse<hmax) {
      wrk[i] += huse;
      hchk = func(wrk);
      wrk[i] = invals[i];
      if (fabs(u-hchk)==0.0) {
	huse *= 10.0;
      }
      else break;
    }
    for (j=1; j<nsteps; j++) {
      wrk[i] += huse;
      table[0][i*nsteps+j] = func(wrk) ;
    }
    wrk[i] = invals[i];
  }

  /* compute the differences */
  for (i=0; i<nparms; i++) {
    idx = i*nsteps;
    for (j=0; j<ndiffs; j++) {
      for (k=0; k<nsteps-j-1; k++) {
	table[j+1][idx+k] = table[j][idx+k+1] - table[j][idx+k];
      }
    }
  }
  return table;
}

/* estimate intervals for use in numerical gradients */
/* see Gill, Murray and Wright, 1981, "Practical Optimization," p. 343-344 */

struct estints *algfd(int nparms, double *eps, double *invals, double *wrk,
		      double (*func)(double *))
{
  static struct estints *outstruc = NULL;

  int i,j,k;
  int K = 20;
  int errval = 0;
  double omega = 1.0, eta = 1.0;
  double u;
  double hf, hk, hbar, hs, hphi;
  double fplus, fminus, phi, phif, phib, phic, phi2, cf, cb, c2;
  double ef, ebar;

  /* allocate structure to return */
  if (outstruc == NULL) {
    outstruc = (struct estints *) malloc(sizeof(struct estints));
    outstruc->errors = (int *) calloc(nparms, sizeof(int));
    outstruc->hf = (double *) calloc(nparms, sizeof(double));
    outstruc->phi = (double *) calloc(nparms, sizeof(double));
    outstruc->phic = (double *) calloc(nparms, sizeof(double));
    outstruc->phi2 = (double *) calloc(nparms, sizeof(double));
    outstruc->ef = (double *) calloc(nparms, sizeof(double));
    outstruc->nparms = nparms;
  }

  /* evaluate func at the input point */
  u = func(invals);

  /* copy the parameter values for point at which to evaluate the gradient */
  for (i=0; i<nparms; i++) wrk[i] = invals[i];

  for (i=0; i<nparms; i++) {
  FD1:
    hbar = 2.0*(eta+fabs(invals[i]))* sqrt(eps[i]/(omega + fabs(u))) ;
    hk = 10.0 * hbar;
    k = 0;
    fdestimates(i, u, invals, wrk, eps[i], hk,
		 &fplus, &fminus, &phif, &phib, &phic, &phi2, &cf, &cb, &c2,
		 func);
    hs = -1.0;
  FD2:
    if ((cf>cb ? cf : cb) <= 0.1) hs = hk;
    if (0.001 <= c2 && c2 <= 0.1) {
      hphi = hk;
      goto FD5;
    }
    if (0.001 > c2) goto FD4;
  FD3:
    do {
      k++;
      hk *= 10.0;
      fdestimates(i, u, invals, wrk, eps[i], hk,
		  &fplus, &fminus, &phif, &phib, &phic, &phi2, &cf, &cb, &c2,
		  func);
      if (hs<0 && ((cf>cb ? cf : cb) <= 0.1)) hs = hk;
      if (c2 <= 0.1) {
	hphi = hk;
	goto FD5;
      }
    } while (k<K);
    if (k==K) goto FD6;
  FD4:
    do {
      k++;
      hk /= 10.0;
      fdestimates(i, u, invals, wrk, eps[i], hk,
		  &fplus, &fminus, &phif, &phib, &phic, &phi2, &cf, &cb, &c2,
		  func);
      if (c2 > 0.1) {
	hphi = hk * 10.0;
	goto FD5;
      }
      if ((cf>cb ? cf : cb) <= 0.1) hs = hk;
      if (0.001 <= c2 && c2 <= 0.1) {
	hphi = hk;
	goto FD5;
      }
    } while (k<K);
    if (k==K) goto FD6;
  FD5:
    hf = 2.0*sqrt(eps[i]/fabs(phi2));
    wrk[i] = invals[i] + hf;
    fplus = func(wrk);
    phi = (fplus-u)/hf;
    wrk[i] = invals[i] + hphi;
    fplus = func(wrk);
    wrk[i] = invals[i] - hphi;
    fminus = func(wrk);
    wrk[i] = invals[i];
    phic = (fplus-fminus)/(2.0*hphi);

    ef = hf*fabs(phi2)*0.5 + 2.0*eps[i]/hf ;
    ebar = fabs(phi-phic);

    outstruc->hf[i] = hf;
    outstruc->phi[i] = phi;
    outstruc->phic[i] = phic;
    outstruc->phi2[i] = phi2;
    outstruc->ef[i] = ef;
    if ((ef>ebar ? ef : ebar) <= 0.5*fabs(phi)) {
      outstruc->errors[i] = 0;
    }
    else
      outstruc->errors[i] = 1;
    continue;
  FD6:
    if (hs<0) {
      hf = hbar;
      phi = phi2 = ef = 0.0;
      errval = 2;
    }
    else if (hs > 0 && c2 > 0.1) {
      hf = hs;
      wrk[i] = invals[i] + hf;
      fplus = func(wrk);
      wrk[i] = invals[i];
      phi = (fplus-u)/hf;
      phi2 = 0.0;
      ef = 2.0*eps[i]/hf ;
      errval = 3;
    }
    else {
      hf = hk;
      wrk[i] = invals[i] + hf;
      fplus = func(wrk);
      phi = (fplus-u)/hf;
      wrk[i] = invals[i] - hf;
      fminus = func(wrk);
      wrk[i] = invals[i];
      phic = (fplus-fminus)/(2.0*hf);
      ef = hf*fabs(phi2)*0.5 + 2.0*eps[i]/hf ;
      errval = 4;
    }
    outstruc->hf[i] = hf;
    outstruc->phi[i] = phi;
    outstruc->phic[i] = phic;
    outstruc->phi2[i] = phi2;
    outstruc->ef[i] = ef;
    outstruc->errors[i] = errval;
  }
  return outstruc;
}

void fdestimates(int parm, double fvalue, double *invals, double *wrk,
		 double eps, double h,
		 double *fplus, double *fminus,
		 double *phif, double *phib, double *phic, double *phi2,
		 double *cf, double *cb, double *c2,
		 double (*func)(double *))
{
  double ih = 1.0/h;

  wrk[parm] = invals[parm] + h;
  *fplus = func(wrk);
  wrk[parm] = invals[parm] - h;
  *fminus = func(wrk);
  wrk[parm] = invals[parm];
  *phif = (*fplus-fvalue) * ih;
  *phib = (fvalue-*fminus) * ih;
  *phic = (*fplus-*fminus) * 0.5 * ih;
  *phi2 = (*phif-*phib) * ih;
  *cf = 2.0*eps*ih/fabs(*phif);
  *cb = 2.0*eps*ih/fabs(*phib);
  *c2 = 4.0*eps*ih*ih/fabs(*phi2);
}

struct estints *estoptint(int nparms, int ndiffs, int pflag, double *invals,
		double (*func)(double *))
{
  static double *wrk = NULL;
  static struct estints *estructure;

  int i,j,k, idx;
  int nsteps=1+2*ndiffs, nrows=nparms*nsteps, ncols=ndiffs+1;
  double h, beta, dwrk;
  double **table;

  if (wrk==NULL)
    wrk = (double *) malloc(nparms*(ndiffs+1)*sizeof(double));

  h = 0.0000002;
  table = eaccuracy(nparms, ndiffs, h, invals, wrk, func);

  for (i=0; i<nparms*ndiffs; i++) wrk[i] = 0.0;

  for (i=0; i<nparms; i++) {
    for (j=0; j<ndiffs; j++) {
      for (k=1; k<=ndiffs; k++) {
	/* find largest difference of each order for each parm */
	dwrk = fabs(table[j+1][i*nsteps+k]);
	if (wrk[i*ndiffs+j] < dwrk) wrk[i*ndiffs+j] = dwrk;
      }
      beta = sqrt(gamma(1.0+2.0*(1.0+(double)j))/pow(gamma(2.0+(double)j),2.0));
      wrk[i*ndiffs+j] /= beta;
    }
  }
  /* put estimates for highest difference order into epsacc */
  for (i=0; i<nparms; i++) {
    dwrk = wrk[i*ndiffs+ndiffs-1];
    /* make sure epsacc values >= MACHEPS */
    epsacc[i] = (dwrk > MACHEPS ? dwrk : MACHEPS) ;
  }

#ifdef NEVERDEFINED
  printf("accuracy estimates:\n");
  for (i=0; i<nparms; i++) {
    printf("parm = %d\n", i+1);
    for (j=0; j<ndiffs; j++) {
      printf(" %14.7e", wrk[i*ndiffs+j]);
    }
    printf("\n");
  }
#endif NEVERDEFINED

#ifdef NEVERDEFINED
  printf("difference table:\n");
  for (i=0; i<nparms; i++) {
    printf("parm = %d\n", i+1);
    for (j=0; j<=ndiffs; j++) {
      for (k=0; k<=ndiffs; k++) {
	printf(" %14.7e", table[j][i*nsteps+k]);
      }
      printf("\n");
    }
  }
#endif NEVERDEFINED

  estructure = algfd(nparms, epsacc, invals, wrk, func);
  if (pflag==1) {
    printf("err   interval          f'                fc'               f''               errorbound\n");
    for (i=0; i<nparms; i++) {
      printf(" %d  ", estructure->errors[i]);
      printf(" %17.10e", estructure->hf[i]);
      printf(" %17.10e", estructure->phi[i]);
      printf(" %17.10e", estructure->phic[i]);
      printf(" %17.10e", estructure->phi2[i]);
      printf(" %17.10e", estructure->ef[i]);
      printf("\n");
    }
  }

  /* put estimates for optimal interval into optint */
  for (i=0; i<nparms; i++) {
    optint[i] = estructure->hf[i];
  }

  return estructure;
}
