/* @(#)toplevel.h	1.4   7/23/98 */

void toplevel(int ngroups, int *numobsv, int numobs, int nboots, int *novarsv,
	      int novars, int nparms);
void rungen(int binit, int nparms, int resetX, int dumpflag);
void glisrelbca(double **fullsampledata, double **weightdata,
		unsigned short int **bootdata,
		int numobs, int nboots, int novars, int nparms,
		int ngroups, int *numobsv, int *novarsv);
