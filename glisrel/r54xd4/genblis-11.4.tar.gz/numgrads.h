/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



/* @(#)numgrads.h	11.4   7/23/98 */
#define MACHEPS 0.000000000000001   /* machine precision */

extern double *epsacc;
extern double *optint;

struct estints {
  int nparms;
  int *errors;  /* 0 == OK, >=1 == error */
  double
    *hf,   /* interval */
    *phi,  /* f' (first derivative) */
    *phic,  /* f' (first derivative, central-difference) */
    *phi2, /* f'' (second derivative) */
    *ef,   /* error bound */
    *hessian;  /* hessian matrix (lower triangle) */
};

double **eaccuracy(int nparms, int ndiffs, double h, double *invals,
		   double *wrk, double (*func)(double *));

struct estints *algfd(int nparms, double *eps, double *invals, double *wrk,
		      double (*func)(double *));

void fdestimates(int parm, double fvalue, double *invals, double *wrk,
		 double eps, double h,
		 double *fplus, double *fminus,
		 double *phif, double *phib, double *phic, double *phi2,
		 double *cf, double *cb, double *c2,
		 double (*func)(double *));

struct estints *estoptint(int nparms, int ndiffs, int pflag, double *invals,
		double (*func)(double *));
