/* @(#)evaluate.h	1.4   7/23/98 */

void optimization(VECTOR X, IVECTOR x1, IVECTOR x2, MATRIX fin_mat, INDEX rc,
	 int tot_eq, VECTOR a1_b, MATRIX domains);
void sort(int MinMax,MATRIX population, int pop_size);
void swap(double **x, double **y);
int find_parent(IVECTOR live, int pop_size);
void assign_probab(VECTOR probab, int pop_size, double Q);
double x_pow_y(double x, int y);
void find_cum_probab(VECTOR cum_probab, VECTOR probab, int pop_size);
void find_live(VECTOR cum_probab, IVECTOR live, int pop_size, int P);
int find_die(VECTOR cum_probab, IVECTOR die, int pop_size);
void find_X(MATRIX final, VECTOR agent, VECTOR X, int x2_vari, int tot_eq,
	    IVECTOR x1, IVECTOR x2, VECTOR a1_b);
double evaluate(VECTOR X);
