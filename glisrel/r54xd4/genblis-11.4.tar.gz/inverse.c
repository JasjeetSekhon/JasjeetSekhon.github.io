/*

  The code in this file has been adapted from Press, Teukolsky, Vetterling
  and Flannery (1992). "Numerical Recipes in C."

*/



#include <math.h>
#include "parms.h"

/* @(#)inverse.c	11.4   7/23/98 */

#define TINY 0.0000000000000001

void ludcmp(double *a, int n, int *indx, double *d)
{

  int i, imax, j, k, idx;
  double big, dum, sum, temp;
  static lisrelgen=0;
  extern int observedy, latenty, runvars, runcases;
  static firsttime=0;
  static double *vv;

  if (firsttime==0) {
    vv = (double *) malloc((observedy*latenty+1)*sizeof(double));
    firsttime=1;
  }
 
  /* vv=vector(0,n-1); */
  
  lisrelgen++;
  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      idx = M(i,j,n);
      if ((temp=fabs(a[idx])) > big) big=temp;
    }
    /* if (big == 0.0) fprintf(output,"\nSINGULAR MATRIX IN ROUTINE LUDCMP in call:%10i\n", lisrelgen); */
    vv[i]=1.0/big;
  } /* end of i for loop */

  for (j=0;j<n;j++) {
    for(i=0;i<j;i++) {
      sum=a[M(i,j,n)];
      for (k=0;k<i;k++) sum -= a[M(i,k,n)]*a[M(k,j,n)];
      a[M(i,j,n)]=sum;
    } /* end of i for */

    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[M(i,j,n)];
      for (k=0;k<j;k++) sum -= a[M(i,k,n)]*a[M(k,j,n)];
      a[M(i,j,n)]=sum;
      if ((dum=vv[i]*fabs(sum)) >= big) {
	big=dum;
	imax=i;
      }
    }

    if (j!=imax) {
      for (k=0;k<n;k++) {
	dum=a[M(imax,k,n)];
	a[M(imax,k,n)]=a[M(j,k,n)];
	a[M(j,k,n)]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }

    indx[j]=imax;
    if (a[M(j,j,n)] == 0.0) { 
      a[M(j,j,n)]=TINY;
      /* fprintf(output,"USE OF TINY IN LUDCMP\n"); */
    }
    if (j!=n-1) {
      dum=1.0/(a[M(j,j,n)]);
      for (i=j+1;i<n;i++) a[M(i,j,n)] *= dum;
    }
  }

  /* free_vector(vv,0,n-1); */
} /* end ludcmp.c */

void lubksb(double *a, int *indx, double *b, int n)
{
  int i, ii=-1, ip, j;
  double sum;

  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii>-1)
      for (j=ii;j<=i-1;j++) sum -= a[M(i,j,n)]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }

  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[M(i,j,n)]*b[j];
    b[i]=sum/a[M(i,i,n)]; 
  }
}

int ludcmpH(double *a, int n, int *indx, double *d)
{
  static firsttime=0;
  static double *vv;

  int i, imax, j, k, idx;
  int issingular = 0;
  double big, dum, sum, temp;
  double tol = 0.0;

  if (firsttime==0) {
    vv = (double *) malloc((n*n+1)*sizeof(double));
    firsttime=1;
  }
 
  /* vv=vector(0,n-1); */

  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++) {
      if ((temp=fabs(a[M(i,j,n)])) > big) big=temp;
    }
    if (big <= tol) {
      issingular = 1;
      /*fprintf(output,"\(ludcmpH) SINGULAR MATRIX -- row %d is all zero\n",i);*/
      goto END;
    }
    vv[i]=1.0/big;
  } /* end of i for loop */

  for (j=0;j<n;j++) {
    for(i=0;i<j;i++) {
      sum=a[M(i,j,n)];
      for (k=0;k<i;k++) sum -= a[M(i,k,n)]*a[M(k,j,n)];
      a[M(i,j,n)]=sum;
    } /* end of i for */
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[M(i,j,n)];
      for (k=0;k<j;k++) sum -= a[M(i,k,n)]*a[M(k,j,n)];
      a[M(i,j,n)]=sum;
      if ((dum=vv[i]*fabs(sum)) >= big) {
	big=dum;
	imax=i;
      }
    }
    if (j!=imax) {
      for (k=0;k<n;k++) {
	dum=a[M(imax,k,n)];
	a[M(imax,k,n)]=a[M(j,k,n)];
	a[M(j,k,n)]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (j!=n-1) {
      dum=1.0/(a[M(j,j,n)]);
      for (i=j+1;i<n;i++) a[M(i,j,n)] *= dum;
    }
  }
  /* free_vector(vv,0,n-1); */

 END:
  return issingular;
} /* end ludcmpH.c */
