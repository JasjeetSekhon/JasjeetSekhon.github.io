/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/




static char *sccsversion = "@(#)bca.c	11.4   7/23/98";

#include "data.h"
#include "bca.h"

int bcacmp(double *a, double *b) {
  int i = 0;

  if (*a > *b) i = 1;
  else if (*a < *b) i = -1;
  return i;
}

void fitfprt(int nparms, int ncases, int nbused, int nboots,
	     double *out, double fitml)
{
  extern int bcacmp();  /* comparison function, used for qsort */
  extern FILE *flistfile;

  double where_ml_value, where_ml_pos, ml_below;
  int j,i;
  double bound95, bound90, diff95, diff90;
  int iused;
  double fracbnu, a_wrk;

  /* fraction of bootstraps not usable */
  fracbnu = 1.0 - (((double) nbused) / nboots);

  qsort(out, nbused, sizeof(double), bcacmp);

  if (fracbnu < 0.05) {
    a_wrk = (0.05-fracbnu)/(1.0-fracbnu);
    bound95=out[(int)ceil((nbused)*(1.0-a_wrk))-1]-fitml;
    diff95=bound95-fitml;
  }
  if (fracbnu < 0.10) {
    a_wrk = (0.10-fracbnu)/(1.0-fracbnu);
    bound90=out[(int)ceil((nbused)*(1.0-a_wrk))-1]-fitml;
    diff90=bound90-fitml;
  }

  for (i=(nbused-1); i>=0; i--) {
    if (fitml > (out[i]-fitml) ) {
      where_ml_value = out[i]-fitml;
      ml_below = out[i-1]-fitml;
      where_ml_pos = ((double) (i+nboots-nbused))/((double) nboots);
      break;
    }
  }

  fprintf(output,"Goodness-of-fit tests:\n");
  fprintf(output,"The ML Fit:%20.16lf\n", fitml);
  fprintf(flistfile,"Goodness-of-fit tests:\n");
  fprintf(flistfile,"The ML Fit:%20.16lf\n", fitml);
  if (fracbnu < 0.05) {
    fprintf(output,"The 95 Percent Bound: %10.8lf \t diff: %10.8lf\n", bound95, diff95);
    fprintf(flistfile,"The 95 Percent Bound: %10.8lf \t diff: %10.8lf\n", bound95, diff95);
  }
  else {
    fprintf(output,"The 95 Percent Bound is undefined\n");
    fprintf(flistfile,"The 95 Percent Bound is undefined\n");
  }
  if (fracbnu < 0.10) {
    fprintf(output,"The 90 Percent Bound: %10.8lf \t diff: %10.8lf\n", bound90, diff90);
    fprintf(flistfile,"The 90 Percent Bound: %10.8lf \t diff: %10.8lf\n", bound90, diff90);
  }
  else {
    fprintf(output,"The 90 Percent Bound is undefined\n");
    fprintf(flistfile,"The 90 Percent Bound is undefined\n");
  }

    fprintf(output,"The Position of the ML Fit Statistic: %10.8lf\n", where_ml_pos);
    fprintf(output,"Fit value at Position:    %10.8lf \t diff: %10.8lf\n", where_ml_value,
    where_ml_value-fitml);
    fprintf(output,"Fit value Below Position: %10.8lf \t diff: %10.8lf\n", ml_below,
    ml_below-fitml);
    fprintf(flistfile,"The Position of the ML Fit Statistic: %10.8lf\n", where_ml_pos);
    fprintf(flistfile,"Fit value at Position:    %10.8lf \t diff: %10.8lf\n", where_ml_value,
    where_ml_value-fitml);
    fprintf(flistfile,"Fit value Below Position: %10.8lf \t diff: %10.8lf\n", ml_below,
    ml_below-fitml);
} /* end of fit function */

/* use all bootstrap runs */
void allfitfunc(int nparms, int ncases, int nboots)
{
  extern double *record;

  int i;
  double fitml;
  static double *out; 
  static int firsttime=0;

  if (firsttime==0) {
      out = (double *) malloc((nboots+1)*sizeof(double));
      firsttime=1;
    }

  fitml = record[M(0,0,nparms+OFFSET)];
  for (i=0; i<nboots; i++) {
    out[i] = record[M(i+1+ncases,0,nparms+OFFSET)] /*- fitml*/;
  }

  fitfprt(nparms, ncases, nboots, nboots, out, fitml);

} /* end of fit function */

/* use only the converged bootstrap runs, adjusting for nonconverged proportion */
void adjfitfunc(int nparms, int ncases, int nboots)
{
  extern double *record;

  int i;
  double fitml;
  int iused;

  static double *out; 
  static int firsttime=0;

  if (firsttime==0) {
      out = (double *) malloc((nboots+1)*sizeof(double));
      firsttime=1;
    }

  fitml = record[M(0,0,nparms+OFFSET)];
  for (iused=0, i=0; i<nboots; i++) {
    if (record[M(i+1+ncases,nparms+3,nparms+OFFSET)] > 0.0) {
      out[iused++] = record[M(i+1+ncases,0,nparms+OFFSET)] /*- fitml*/;
    }
  }

  fitfprt(nparms, ncases, iused, nboots, out, fitml);

} /* end of fit function */

/* use only the converged bootstrap runs */
void subfitfunc(int nparms, int ncases, int nboots)
{
  extern double *record;

  int i;
  double fitml;
  int iused;

  static double *out; 
  static int firsttime=0;

  if (firsttime==0) {
      out = (double *) malloc((nboots+1)*sizeof(double));
      firsttime=1;
    }

  fitml = record[M(0,0,nparms+OFFSET)];
  for (iused=0, i=0; i<nboots; i++) {
    if (record[M(i+1+ncases,nparms+3,nparms+OFFSET)] > 0.0) {
      out[iused++] = record[M(i+1+ncases,0,nparms+OFFSET)] /*- fitml*/;
    }
  }

  fitfprt(nparms, ncases, iused, iused, out, fitml);

} /* end of fit function */

/* macro to remap j==0 to point to Cox test statistic values in col nparms+5 */
#define MAPJ(J) (J==0 ? nparms+5 : J)
void bcacore(int nparms, int ncases, int nbused, int nboots, int *bulist,
	     int adjflag)
{
  extern double nrmcdfs(), inrmcdf();  /* Normal CDF and inverse (defuns below) */
  extern int bcacmp();  /* comparison function, used for qsort */

  extern double *record;

  extern int *whereXrow, *whereXcol, *whereXtype;
  extern short int bootstrapdetails;
  extern FILE *flistfile;

  int i, j, jflag;
  double ml_value;
  int ml_pos;
  double fracbnu, fracbnu2;
  double oncases = 1.0/((double) ncases);
  /* strings for use in formatting the results for printing */
  char fmts14[] = "              ";  /* 14 spaces */
  double a_wrk, a_sub, a_sub2;
  double zwrk, wi, zfull;

  static double *z0, *a, *a_mean, *a_top, *a_under, *wrk, *zunder, *zover, 
    *alpha1_95, *alpha2_95, *alpha1_90, *alpha2_90,
    *cbounds_95, *cbounds_90,
    *cbpct_95, *cbpct_90 ;
  static int firsttime=0;

  if (firsttime==0) {
    z0 = (double *) malloc((nparms+1)*sizeof(double));
    a = (double *) malloc((nparms+1)*sizeof(double));
    a_mean = (double *) malloc((nparms+1)*sizeof(double));
    a_top = (double *) malloc((nparms+1)*sizeof(double));
    a_under = (double *) malloc((nparms+1)*sizeof(double));
    wrk = (double *) malloc((nboots+1)*sizeof(double));
    zunder = (double *) malloc((nparms+1)*sizeof(double));
    zover = (double *) malloc((nparms+1)*sizeof(double));
    alpha1_95 = (double *) malloc((nparms+1)*sizeof(double));
    alpha2_95 = (double *) malloc((nparms+1)*sizeof(double));
    alpha1_90 = (double *) malloc((nparms+1)*sizeof(double));
    alpha2_90 = (double *) malloc((nparms+1)*sizeof(double));
    cbounds_95 = (double *) malloc(((2*(nparms+2)+nparms+2))*sizeof(double));
    cbounds_90 = (double *) malloc(((2*(nparms+2)+nparms+2))*sizeof(double));
    cbpct_95 = (double *) malloc(((2*(nparms+2)+nparms+2))*sizeof(double));
    cbpct_90 = (double *) malloc(((2*(nparms+2)+nparms+2))*sizeof(double));
  }


  /* fraction of bootstraps not usable */
  fracbnu = 1.0 - (((double) nbused) / nboots);
  fracbnu2 = fracbnu / 2.0;

  /* note:  array locations [j==0] are being used to compute intervals for the
     Cox test statistic, which is in column nparms+5 of record[].
     MAPJ(j) remaps the j==0 values appropriately for reading from record[]. */
  /* skip j==0: no longer using the Cox g-of-fit test */
  for (j=1; j<=nparms; j++) {
    zunder[j]=0.0;
    zover[j]=0.0;
    a_mean[j]=0.0;
    a_top[j]=0.0;
    a_under[j]=0.0;

    /* CALCULATIONS for "z0" */
    zwrk = zfull = record[M(0,MAPJ(j),nparms+OFFSET)];
    if (bulist != NULL) {  /* use the subset of bootstraps indexed in bulist */
      for (i=0; i<nbused; i++) {
	wi = record[M(bulist[i]+1+ncases,MAPJ(j),nparms+OFFSET)];
	wrk[i] = wi;
	if (wi < zwrk) zunder[j]++;
	if (wi > zwrk) zover[j]++;
      }
      qsort(wrk, nbused, sizeof(double), bcacmp);
    }
    else {
      for (i=0; i<nboots; i++) {
	wi = record[M(i+1+ncases,MAPJ(j),nparms+OFFSET)];
	wrk[i] = wi;
	if (wi < zwrk) zunder[j]++;
	if (wi > zwrk) zover[j]++;
      }
      qsort(wrk, nboots, sizeof(double), bcacmp);
    }
    if (zunder[j] == 0.0)
      zunder[j] = (double)nbused-zover[j];
    z0[j] = inrmcdf(zunder[j]/((double)nbused));

    /* CALCULATIONS for a */

    jflag = 0;  /* flag used to check that jackknife values vary */
    wi = record[M(1,MAPJ(j),nparms+4)];
    for (i=1; jflag==0 && i<=ncases; i++) {  /* mean of jackknife estimates */
      if (wi != record[M(i,MAPJ(j),nparms+4)]) jflag = 1;
    }

    if (jflag==0) {
      a[j] = 0.0;
    }
    else {
      for (i=1; i<=ncases; i++) {  /* mean of jackknife estimates */
	a_mean[j] += record[M(i,MAPJ(j),nparms+OFFSET)];
      }
      a_mean[j] *= oncases ;

      a_wrk = a_mean[j];
      for (i=1; i<=ncases; i++) {
	a_sub = a_wrk-record[M(i,MAPJ(j),nparms+OFFSET)];
	a_sub2 = a_sub*a_sub;
	a_under[j] += a_sub2;
	a_top[j]   += a_sub2*a_sub;
      }

      a[j] = a_top[j] / ( 6.0*pow(a_under[j],3.0/2.0) );
    }

    /* ALPHA 1 */
    if (adjflag==0 || fracbnu < 0.05) {
      a_wrk = adjflag>0 ? (0.05-fracbnu)/(1.0-fracbnu) : 0.05;
      a_wrk *= 0.5;
      zwrk = inrmcdf(a_wrk);
      alpha1_95[j] = z0[j] + ((z0[j]+zwrk)/(1-a[j]*(z0[j]+ zwrk)));
      zwrk = inrmcdf(1.0-a_wrk);
      alpha2_95[j] = z0[j] + ((z0[j]+zwrk)/(1-a[j]*(z0[j]+zwrk)));

      alpha1_95[j] = nrmcdfs(alpha1_95[j]);
      alpha2_95[j] = nrmcdfs(alpha2_95[j]);
    }
    else {
      alpha1_95[j] = 0.0;
      alpha2_95[j] = 0.0;
    }

    if (adjflag==0 || fracbnu < 0.10) {
      a_wrk = adjflag>0 ? (0.1-fracbnu)/(1.0-fracbnu) : 0.1;
      a_wrk *= 0.5;
      zwrk = inrmcdf(a_wrk);
      alpha1_90[j] = z0[j] + ((z0[j]+zwrk)/(1-a[j]*(z0[j]+zwrk)));
      zwrk = inrmcdf(1.0-a_wrk);
      alpha2_90[j] = z0[j] + ((z0[j]+zwrk)/(1-a[j]*(z0[j]+zwrk)));

      alpha1_90[j] = nrmcdfs(alpha1_90[j]);
      alpha2_90[j] = nrmcdfs(alpha2_90[j]);
    }
    else {
      alpha1_90[j] = 0.0;
      alpha2_90[j] = 0.0;
    }

    if (adjflag==0 || fracbnu < 0.05) {
      cbounds_95[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*alpha1_95[j])-1];
      cbounds_95[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*alpha2_95[j])-1];

      if (j==0) {
	cbpct_95[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*0.025)-1];
	cbpct_95[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*0.975)-1];
      }
      else {
	cbpct_95[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*0.025)-1] ;
	cbpct_95[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*0.975)-1] ;
      }
    }
    else {
      cbounds_95[M(0,j,nparms+1)] = cbounds_95[M(1,j,nparms+1)] = 0.0;

      cbpct_95[M(0,j,nparms+1)] = cbpct_95[M(1,j,nparms+1)] = 0.0;
    }
    if (adjflag==0 || fracbnu < 0.10) {
      cbounds_90[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*alpha1_90[j])-1];
      cbounds_90[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*alpha2_90[j])-1];

      if (j==0) {
	cbpct_90[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*0.05)-1];
	cbpct_90[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*0.95)-1];
      }
      else {
	cbpct_90[M(0,j,nparms+1)] = wrk[(int)ceil(nbused*0.05)-1] ;
	cbpct_90[M(1,j,nparms+1)] = wrk[(int)ceil(nbused*0.95)-1] ;
      }
    }
    else {
      cbounds_90[M(0,j,nparms+1)] = cbounds_90[M(1,j,nparms+1)] = 0.0;

      cbpct_90[M(0,j,nparms+1)] = cbpct_90[M(1,j,nparms+1)] = 0.0;
    }
  }

  /* print results */
#ifdef NEVERDEFINED
  /* print intervals for the Cox test */
  fprintf(output,"full sample Cox test statistic:  M = %14.8e\n",
	 record[M(0, MAPJ(0), nparms+OFFSET)]);
  fprintf(output,"BCa of Cox test for fit:  N = %d, replications = %d (used = %d)\n",
	 ncases, nboots, nbused);
  fprintf(output,"proportion of bootstraps that are not usable: %9.4lf\n", fracbnu);
  fprintf(output,"BCa confidence intervals:\n");
  fprintf(output,"%s95%% %s   %s90%%\n",fmts14,fmts14,fmts14);
  if (adjflag==0 || fracbnu < 0.05)
    fprintf(output,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
	   cbounds_95[M(0,0,nparms+1)],cbounds_95[M(1,0,nparms+1)],
	   cbounds_90[M(0,0,nparms+1)],cbounds_90[M(1,0,nparms+1)]);
  else if (fracbnu < 0.10)
    fprintf(output,"(%s, %s) (%14.8e, %14.8e)\n",
	   fmts14,fmts14,
	   cbounds_90[M(0,0,nparms+1)],cbounds_90[M(1,0,nparms+1)]);
  else
    fprintf(output,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
  fprintf(output,"\n\nalpha1_95, alpha2_95, alpha1_90, alpha2_90:\n");
  fprintf(output,"%f  %f  %f  %f\n",
	 alpha1_95[0],alpha2_95[0],alpha1_90[0],alpha2_90[0]);

  fprintf(output,"\nzunder, z0, a:\n");
  fprintf(output,"%10.8f  %10.8f  %10.8f\n", zunder[0], z0[0], a[0]);

  fprintf(output,"\npercentile intervals:\n");
  fprintf(output,"%s95%% %s   %s90%%\n",fmts14,fmts14,fmts14);
  if (adjflag==0 || fracbnu < 0.05)
    fprintf(output,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
	   cbpct_95[M(0,0,nparms+1)],cbpct_95[M(1,0,nparms+1)],
	   cbpct_90[M(0,0,nparms+1)],cbpct_90[M(1,0,nparms+1)]);
  else if (fracbnu < 0.10)
    fprintf(output,"(%s, %s) (%14.8e, %14.8e)\n",
	   fmts14,fmts14,
	   cbpct_90[M(0,0,nparms+1)],cbpct_90[M(1,0,nparms+1)]);
  else
    fprintf(output,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
#endif

  /* print intervals for the parameter estimates */
  if (firsttime==0) {
    fprintf(output,
	    "Simple Percentile intervals:  N= %d, bootstrap replication = %d (used = %d)\n",
	    ncases, nboots, nbused);
    fprintf(output,"Percentile intervals are NOT adjusted for nonconvergence.\n");
    fprintf(output,"               %s95%% %s %s90%%\n",fmts14,fmts14,fmts14);
    fprintf(flistfile,
	    "Simple Percentile intervals:  N= %d, bootstrap replication = %d (used = %d)\n",
	    ncases, nboots, nbused);
    fprintf(flistfile,"Percentile intervals are NOT adjusted for nonconvergence.\n");
    fprintf(flistfile,"               %s95%% %s %s90%%\n",fmts14,fmts14,fmts14);
    if (adjflag==0 || fracbnu < 0.05)
      for (j=1; j<=nparms; j++) {
	fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(output,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
		cbpct_95[M(0,j,nparms+1)],cbpct_95[M(1,j,nparms+1)],
		cbpct_90[M(0,j,nparms+1)],cbpct_90[M(1,j,nparms+1)]);
	fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(flistfile,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
		cbpct_95[M(0,j,nparms+1)],cbpct_95[M(1,j,nparms+1)],
		cbpct_90[M(0,j,nparms+1)],cbpct_90[M(1,j,nparms+1)]);
      }
    else if (fracbnu < 0.10)
      for (j=1; j<=nparms; j++) {
	fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(output,"(%s, %s) (%14.8e, %14.8e)\n",
		fmts14,fmts14,
		cbpct_90[M(0,j,nparms+1)],cbpct_90[M(1,j,nparms+1)]);
	fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(flistfile,"(%s, %s) (%14.8e, %14.8e)\n",
		fmts14,fmts14,
		cbpct_90[M(0,j,nparms+1)],cbpct_90[M(1,j,nparms+1)]);
      }
    else
      for (j=1; j<=nparms; j++) {
	fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(output,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
	fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
		whereXrow[j-1]+1, whereXcol[j-1]+1);
	fprintf(flistfile,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
      }
    fprintf(output,"\n");
    fprintf(output,
	    "\n\nBCa intervals and bootstrap goodness-of-fit test with NO adjustments for\n");
    fprintf(output,
	    "nonconvergence.  These intervals will be larger than or equal to the intervals\n");
    fprintf(output,"produced with adjustments.\n");
    fprintf(flistfile,"\n");
    fprintf(flistfile,
	    "\n\nBCa intervals and bootstrap goodness-of-fit test with NO adjustments for\n");
    fprintf(flistfile,
	    "nonconvergence.  These intervals will be larger than or equal to the intervals\n");
    fprintf(flistfile,"produced with adjustments.\n");
  }
  else {
    fprintf(output,
	    "\n\nBCa intervals and bootstrap goodness-of-fit test WITH adjustments for\n");
    fprintf(output,
	    "nonconvergence.  These intervals will be smaller than or equal to the intervals\n");
    fprintf(output,"produced without adjustments.\n");
    fprintf(flistfile,
	    "\n\nBCa intervals and bootstrap goodness-of-fit test WITH adjustments for\n");
    fprintf(flistfile,
	    "nonconvergence.  These intervals will be smaller than or equal to the intervals\n");
    fprintf(flistfile,"produced without adjustments.\n");
  }


  fprintf(output,"BCa results:  N = %d, bootstrap replications = %d (used = %d)\n",
	 ncases, nboots, nbused);
  fprintf(output,"proportion of bootstraps that are not usable: %9.4lf\n", fracbnu);
  fprintf(output,"BCa confidence intervals:\n");
  fprintf(output,"               %s95%% %s %s90%%\n",fmts14,fmts14,fmts14);
  fprintf(flistfile,"BCa results:  N = %d, bootstrap replications = %d (used = %d)\n",
	 ncases, nboots, nbused);
  fprintf(flistfile,"proportion of bootstraps that are not usable: %9.4lf\n", fracbnu);
  fprintf(flistfile,"BCa confidence intervals:\n");
  fprintf(flistfile,"               %s95%% %s %s90%%\n",fmts14,fmts14,fmts14);
  if (adjflag==0 || fracbnu < 0.05)
    for (j=1; j<=nparms; j++) {
      fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(output,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
	     cbounds_95[M(0,j,nparms+1)],cbounds_95[M(1,j,nparms+1)],
	     cbounds_90[M(0,j,nparms+1)],cbounds_90[M(1,j,nparms+1)]);
      fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(flistfile,"(%14.8e, %14.8e) (%14.8e, %14.8e)\n",
	     cbounds_95[M(0,j,nparms+1)],cbounds_95[M(1,j,nparms+1)],
	     cbounds_90[M(0,j,nparms+1)],cbounds_90[M(1,j,nparms+1)]);
    }
  else if (fracbnu < 0.10)
    for (j=1; j<=nparms; j++) {
      fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(output,"(%s, %s) (%14.8e, %14.8e)\n",
	     fmts14,fmts14,
	     cbounds_90[M(0,j,nparms+1)],cbounds_90[M(1,j,nparms+1)]);
      fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(flistfile,"(%s, %s) (%14.8e, %14.8e)\n",
	     fmts14,fmts14,
	     cbounds_90[M(0,j,nparms+1)],cbounds_90[M(1,j,nparms+1)]);
    }
  else
    for (j=1; j<=nparms; j++) {
      fprintf(output,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(output,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
      fprintf(flistfile,"%2d) %4s %2d %2d ", j, parmsyms[whereXtype[j-1]],
	     whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(flistfile,"(%s, %s) (%s, %s)\n", fmts14,fmts14,fmts14,fmts14);
    }

  if (bootstrapdetails==1) {
    fprintf(output,"alpha1_95, alpha2_95, alpha1_90, alpha2_90:\n");
    fprintf(flistfile,"alpha1_95, alpha2_95, alpha1_90, alpha2_90:\n");
    for (j=1; j<=nparms; j++) {
      fprintf(output,"%2d) %4s %2d %2d : ", j, parmsyms[whereXtype[j-1]],
	      whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(output,"%f  %f  %f  %f\n",
	      alpha1_95[j],alpha2_95[j],alpha1_90[j],alpha2_90[j]);
      fprintf(flistfile,"%2d) %4s %2d %2d : ", j, parmsyms[whereXtype[j-1]],
	      whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(flistfile,"%f  %f  %f  %f\n",
	      alpha1_95[j],alpha2_95[j],alpha1_90[j],alpha2_90[j]);
    }
    fprintf(output,"zunder, z0, a:\n");
    fprintf(flistfile,"zunder, z0, a:\n");
    for (j=1; j<=nparms; j++) {
      fprintf(output,"%2d) %4s %2d %2d : ", j, parmsyms[whereXtype[j-1]],
	      whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(output,"%10.8f  %10.8f  %10.8f\n", zunder[j], z0[j], a[j]);
      fprintf(flistfile,"%2d) %4s %2d %2d : ", j, parmsyms[whereXtype[j-1]],
	      whereXrow[j-1]+1, whereXcol[j-1]+1);
      fprintf(flistfile,"%10.8f  %10.8f  %10.8f\n", zunder[j], z0[j], a[j]);
    }
  }

  firsttime=1;
} /* end bcacore */


/* use all bootstrap runs */
void allbca(int nparms, int ncases, int nboots)
{
  bcacore(nparms, ncases, nboots, nboots, (int *)NULL, 1);

  allfitfunc(nparms, ncases, nboots);

} /* end allbca */

/* use only the converged bootstrap runs, adjusting for nonconverged proportion */
void adjbca(int nparms, int ncases, int nboots)
{
  extern double *record;

  int i, iused;

  static int *bulist, firsttime=0;
  if (firsttime==0) {
    bulist = (int *) malloc((nboots)*sizeof(int));
    firsttime=1;
  }

  /* get indexes of bootstraps to use */
  for (iused=0, i=0; i<nboots; i++) {
    if (record[M(i+1+ncases,nparms+3,nparms+OFFSET)] > 0.0) {
      bulist[iused++] = i;
    }
  }

  bcacore(nparms, ncases, iused, nboots, bulist, 1);

  adjfitfunc(nparms, ncases, nboots);

} /* end adjbca */

/* use only the converged bootstrap runs */
void subbca(int nparms, int ncases, int nboots)
{
  extern double *record;

  int i, iused;

  static int *bulist, firsttime=0;
  if (firsttime==0) {
    bulist = (int *) malloc((nboots)*sizeof(int));
    firsttime=1;
  }

  /* get indexes of bootstraps to use */
  for (iused=0, i=0; i<nboots; i++) {
    if (record[M(i+1+ncases,nparms+3,nparms+OFFSET)] > 0.0) {
      bulist[iused++] = i;
    }
  }

  bcacore(nparms, ncases, iused, nboots, bulist, 0);

  subfitfunc(nparms, ncases, nboots);

} /* end subbca */

/* standard Normal cumulative density function (accurate enough for BCa) */
double nrmcdfs(double x) {
  static double isqrt2 = 1.0/1.4142135623730951, half = 1.0/2.0;

  return erf(x*isqrt2)*half + half;
}

/* inrmcdf:  inverse normal CDF;  f2c translation of phinv, slightly edited */
double inrmcdf(double ppp)
{
    extern double nrmcdfs();

    /* Initialized data */

    static double pt5neg = -.5;
    static double d1 = 1.432788;
    static double d2 = .189269;
    static double d3 = .001308;
    static double osr2pi = .39894228040143267793;
    static double pt5 = .5;
    static double zero = 0.;
    static double one = 1.;
    static double two = 2.;
    static double six = 6.;
    static double c0 = 2.515517;
    static double c1 = .802853;
    static double c2 = .010328;

    /* System generated locals */
    double ret_val, d__1, d__2, d__3, d__4;

    /* Local variables */
    double p, t;
    int iflip;
    double x0, sfeex0, ph;

    iflip = 0;
    p = ppp;
    if (ppp == one) {
	goto L998;
    }
    if (ppp == zero) {
	goto L999;
    }
    if (ppp > pt5) {
	p = one - ppp;
	iflip = 1;
    }
/* ***** */
/*     p<0.5 as required by inversion: */
/* ***** */
/* Computing 2nd power */
    d__1 = p;
    t = sqrt(log(one / (d__1 * d__1)));
/* Computing 2nd power */
    d__1 = t;
/* Computing 2nd power */
    d__2 = t;
/* Computing 3rd power */
    d__3 = t, d__4 = d__3;
    x0 = t - (c0 + c1 * t + c2 * (d__1 * d__1)) / (one + d1 * t + d2 * (d__2 *
	     d__2) + d3 * (d__4 * (d__3 * d__3)));
/* ***** */
/*     up to now x0<0: */
/* ***** */
    x0 = -x0;
/* ***** */
/*     now x0>0 as required by inverse interpolation: */
/* ***** */
/* Computing 2nd power */
    d__1 = x0;
    sfeex0 = osr2pi * exp(pt5neg * (d__1 * d__1));
    t = (p - nrmcdfs(x0)) / sfeex0;
/* Computing 2nd power */
    d__1 = t;
/* Computing 2nd power */
    d__2 = x0;
/* Computing 3rd power */
    d__3 = t, d__4 = d__3;
    ph = x0 + t + x0 * (d__1 * d__1) / two + (two * (d__2 * d__2) + one) * (
	    d__4 * (d__3 * d__3)) / six;
/* ***** */
/*     back to original x0<0, ph<0: */
/* ***** */
    ph = -ph;
    if (iflip == 0) {
	ph = -ph;
    }
    ret_val = ph;
    return ret_val;
L998:
    ret_val = 18.;
/* *****a crude way of dealing with ppp=1 */
    return ret_val;
L999:
    ret_val = -18.;
/* *****a crude way of dealing with ppp=0 */
    return ret_val;
} /* inrmcdf_ */

void bca(int nparms, int ncases, int nboots)
{
  /*
  fprintf(output,"BCa intervals using all bootstraps:\n");
  allbca(nparms, ncases, nboots);
  */
  subbca(nparms, ncases, nboots);
  adjbca(nparms, ncases, nboots);
  /*
  cox_fit(nparms, ncases, nboots);
  */
}
