/* @(#)multi.h	1.4   7/23/98 */

void multi(double *in1, double *in2, double *out,
         int row1, int col1, int row2, int col2, int outrowcol[2]);
void submulti(double *in1, double *in2, double *out,
	      int row1s, int row1e, int col1s, int col1e, int ncols1,
	      int row2s, int row2e, int col2s, int col2e, int ncols2,
	      int orows, int ocols, int ncolso);
void add(double *in1, double *in2, double
         *out, int row, int col);
void addtheta(double *in, double *theta, int n);
void subtract(double *in1, double *in2,
         double *out, int row, int col);
void copy(double *in, double *target, int row, int col);
void copy2(double *in, int colin, int offset, double *target,
	   int rowout, int colout);
void scalarmulti(double scalar, double *in1, double *out, int row, int col);
void scalarmultioffdiag(double scalar, double *in1, double *out, int row, int col);
void transpose(double *orig_matrix,
            double *t_matrix,
            int orig_rows, int orig_columns);
double trace(double *a, int n);
