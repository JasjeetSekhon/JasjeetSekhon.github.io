/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/




/* @(#)multi.c	11.4   7/23/98 */

#include "data.h"
#include "multi.h"

void multi(double *in1, double *in2, double *out,
	   int row1, int col1, int row2, int col2, int outrowcol[2])
{
  int oi, oj, h, i, j;
  extern FILE *output;

  if (col1!=row2) {
    fprintf(output,"\nTHE MATRICES ARE NOT CONFORMABLE FOR MULIPLICATION\n"); 
    return;
  }

  outrowcol[0]=row1;
  outrowcol[1]=col2;

  for (oi=0;oi<outrowcol[0];oi++) {
    for (oj=0;oj<outrowcol[1];oj++) {
      out[M(oi,oj,outrowcol[1])] = 0.0;
    }
  }

  for (oi=0;oi<outrowcol[0];oi++) {
    for (oj=0;oj<outrowcol[1];oj++) {
      for (i=0;i<col1;i++) {
	out[M(oi,oj,outrowcol[1])] += in1[M(oi,i,col1)]*in2[M(i,oj,col2)];
      }
    }
  }
}


void submulti(double *in1, double *in2, double *out,
	      int row1s, int row1e, int col1s, int col1e, int ncols1,
	      int row2s, int row2e, int col2s, int col2e, int ncols2,
	      int orows, int ocols, int ncolso)
{
  int oi, oj, h, i, j;
  int nr1, nc1, nr2, nc2;
  extern FILE *output;

  nr1 = row1e-row1s+1;
  nc1 = col1e-col1s+1;
  nr2 = row2e-row2s+1;
  nc2 = col2e-col2s+1;

  if (nc1 != nr2) {
    fprintf(output,"\nTHE MATRICES ARE NOT CONFORMABLE FOR MULIPLICATION\n"); 
    return;
  }

  for (oi=0;oi<nr1;oi++) {
    for (oj=0;oj<nc2;oj++) {
      out[M(orows+oi,ocols+oj,ncolso)] = 0.0;
    }
  }

  for (oi=0;oi<nr1;oi++) {
    for (oj=0;oj<nc2;oj++) {
      for (i=0;i<nc1;i++) {
	out[M(orows+oi,ocols+oj,ncolso)] +=
	  in1[M(row1s+oi,col1s+i,ncols1)]*in2[M(row2s+i,col2s+oj,ncols2)];
      }
    }
  }
}


void add(double *in1, double *in2, double
         *out, int row, int col)
{
  int i, j, idx;

  for (i=0;i<row;i++) {
    for (j=0;j<col;j++) {
      idx=M(i,j,col);
      out[idx]=in1[idx]+in2[idx];
    }
  }
}


void addtheta(double *in, double *theta, int n)
{
  int i;

  for (i=0;i<n;i++) {
    in[M(i,i,n)]+=theta[i];
  }
}


void subtract(double *in1, double *in2,
         double *out, int row, int col)
{
  int i, j, idx;

  for (i=0;i<row;i++) {
    for (j=0;j<col;j++) {
      idx=M(i,j,col);
      out[idx]=in1[idx]-in2[idx];
    }
  }
}



void copy(double *in, double *target, int row, int col)
{
  int i, j, idx;

  for (i=0;i<row;i++) {
    for (j=0;j<col;j++) {
      idx=M(i,j,col);
      target[idx]=in[idx];
    }
  }
}


void copy2(double *in, int colin, int offset, double *target, int rowout, int colout)
{
  int i, j, idxin, idxout;

  for (i=0;i<rowout;i++) {
    for (j=0;j<colout;j++) {
      idxin=M(i+offset,j+offset,colin);
      idxout=M(i,j,colout);
      target[idxout]=in[idxin];
    }
  }
}


void scalarmulti(double scalar, double *in1, double *out, int row, int col) 
{
  int i, j, idx;

  for (i=0;i<row;i++) {
    for (j=0;j<col;j++) {
      idx=M(i,j,col);
      out[idx]=scalar*in1[idx];
    }
  }
}

void scalarmultioffdiag(double scalar, double *in1, double *out, int row, int col) 
{
  int i, j, idx;

  for (i=0;i<row;i++) {
    for (j=0;j<col;j++) {
      idx=M(i,j,col);
      if (i==j)
	out[idx] = in1[idx];
      else
	out[idx] = scalar*in1[idx];
    }
  }
}


void transpose(double *orig_matrix, double *t_matrix, int orig_rows,
	       int orig_columns) 
{
  int i, j, idx, t_idx;

  for(i=0;i<orig_rows;i++) {
    for(j=0;j<orig_columns;j++) {
      idx = M(i,j,orig_columns);
      t_idx = M(j,i,orig_rows);
      t_matrix[t_idx]=orig_matrix[idx];
    }
  }

  /*
  for (i=0;i<orig_rows;i++) {
    for (j=0;j<orig_columns;j++) {
      idx = M(i,j,orig_columns);
      fprintf(output,"original (from transpose) orig_matrix[%3i%3i](%4i)=%10lf\n",
	      i,j,idx,orig_matrix[idx]);
    }
  }

  fprintf(output,"\n\n");
  for (i=0;i<orig_rows;i++) {
    for (j=0;j<orig_columns;j++) {
      t_idx = M(i,j,orig_rows);
      fprintf(output,"transposeed matrix[%3i%3i](%4i)=%10lf\n",
	      i,j,t_idx,t_matrix[t_idx]);
    }
  }
  */

} /* end transpose */


double trace(double *a, int n)
{
  int i;
  double  out;
  out=0.0;

  for (i=0;i<n;i++) {
    out += a[M(i,i,n)];
  }

  return out;
}
