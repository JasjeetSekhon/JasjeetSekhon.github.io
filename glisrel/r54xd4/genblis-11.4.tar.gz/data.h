/* @(#)data.h	1.4   7/23/98 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "parms.h"

#define TRUE 1
#define FALSE 0

#define WINDOWS_SYS FALSE        /* set true for windows 95/NT */
#define UNIX_SYS TRUE            /* set to true for unix AND windows/95/NT, false for dos */
#define DOS_SYS  FALSE           /* set to true for dos, false for unix AND windows 95/nt */

#if UNIX_SYS
  extern FILE *input, *output, *flistfile;
#endif

extern char redirect_stdout[MAXPATH];
#if WINDOWS_SYS
extern short int redirect_trigger;
#endif

extern int whichcontrol;
extern int reset_from_X;
extern int converged_flag;
extern short int runcovflag, jacks, doboots, dobig, bootstrapdetails, covmatrix;
extern int usecovflag, usecrosspflag, usecorrflag, weightflag;
extern int *caseuse;
extern long int number, jacknumber,bootnumber;
extern int doing;
extern int boundary_flag;
extern int *boundary_hit, *boundary_use;
extern int constrained_flag;

/* global variables required to get rid of the control files */
extern int population_size[NUMCONTROLS], 
  oper1_use[NUMCONTROLS], oper2_use[NUMCONTROLS], oper3_use[NUMCONTROLS], 
  oper4_use[NUMCONTROLS], oper5_use[NUMCONTROLS], oper6_use[NUMCONTROLS], 
  oper7_use[NUMCONTROLS], oper8_use[NUMCONTROLS];
extern double control_gradient_tolerance[NUMCONTROLS];
/* done */

extern double *record;
extern double **data, **wdata;
extern double *cov;
extern double *sigma, *inverse_sigma;

extern char *control_filename[NUMCONTROLS];

extern int degrees_of_freedom, ilambda, itheta, ibeta, ipsi, ipsi_diag;
extern int start_fcov, end_fcov, start_psi, end_psi, fcov_vars;
extern double *initial_values;
extern short int starting_values, use_boundary;

extern char *parmsyms[4];
extern int *whereXrow, *whereXcol, *fixXrow, *fixXcol;
extern int *whereXtype, *fixXtype;
extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
extern int *whereXtype_array[MAXBOUNDHITS+1];
extern int *varmap, *varmap_array[MAXBOUNDHITS+1];
extern int first_set_structures;
extern int equality_constraints;
extern int *equal_lambda_row, *equal_lambda_col, *equal_beta_row, *equal_beta_col,
  *equal_psi_row, *equal_psi_col, *equal_theta_row, *equal_theta_col;

extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
extern int observedy, latenty, runvars, runcases, runboots;
extern int rungroups, *runcasesv, *observedyv;
extern int runvars_array[MAXBOUNDHITS+1];
extern int run_nochange_lim, run_notdone_lim;
extern int runfixvars;
extern int bhitlimit;
extern double bhitthreshold;

extern char modelfilename[MAXPATH];
extern char **fullsamplename;
extern char **weightname;
extern char recordfilename[MAXPATH];
extern char readrecordfilename[MAXPATH];
extern char bootdatafilename[MAXPATH];
extern char listfile[MAXPATH];
extern short int readrecordtrigger;
extern short int record_dumptrigger;
extern short int bootdatatrigger;
