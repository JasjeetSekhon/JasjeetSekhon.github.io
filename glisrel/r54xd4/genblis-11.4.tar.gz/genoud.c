/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html


   Some of the code in this file was adapted from an early version of
   GENOCOP I (Zbigniew Michalewicz, zbyszek@uncc.edu).  For information
   about GENOCOP III please see
   http://www.coe.uncc.edu/~gnazhiya/gchome.html.
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include<time.h>
#include "data.h"
#include "genoud.h"
#include "genetic.h"
#include "evaluate.h"
#include "unif.h"

static char *sccsversion = "@(#)genoud.c	11.4   7/23/98";

#if DOS_SYS
  FILE *input,*output;
#endif

struct optcontrol *octrl;  /* values read from control file */
struct optcontrol ctrlvals[NUMOFMODELS];  /* values read from control file */

struct gspecobjs gosvec[NUMOFMODELS];
int firsttime_g[NUMOFMODELS];
struct optimobjs objs[NUMOFMODELS];
int firsttime_o[NUMOFMODELS];

void genoud(void)
{
  extern struct optcontrol *octrl;  /* ptr to values read from control file */
  extern struct optcontrol ctrlvals[NUMOFMODELS];  /* values read from control file */

  extern char *control_filename[NUMCONTROLS];  /* names of control files to read */
  extern struct gspecobjs gosvec[NUMOFMODELS];
  extern firsttime_g[NUMOFMODELS];
  extern int whichcontrol;
  extern int converged_flag;
  extern int reset_from_X;
  extern int *varmap;

  extern int population_size[NUMCONTROLS], max_number_of_generations[NUMCONTROLS], 
    oper1_use[NUMCONTROLS], oper2_use[NUMCONTROLS], oper3_use[NUMCONTROLS], 
    oper4_use[NUMCONTROLS], oper5_use[NUMCONTROLS], oper6_use[NUMCONTROLS], 
    oper7_use[NUMCONTROLS], oper8_use[NUMCONTROLS], run_notdone_lim;
  extern double control_gradient_tolerance[NUMCONTROLS];

  extern int runvars, runvars_array[MAXBOUNDHITS+1];

#if WINDOWS_SYS
  extern char redirect_stdout[MAXPATH];
  extern short int redirect_trigger;
#endif

  static double Xprev[MAX_VAR];  /* to hold previous best-found parameter values */

  struct gspecobjs *gosp, *gospB, *gosp0, *gosp1;

  MATRIX equalities,   /*Matrix for equalities*/
         inequalities, /*Matrix for inequalities*/
         domains,      /*Matrix for Domains*/
         a1,           /*Equalities split into a1 and a2*/
         a2,
         inv_a1,       /*Inverse matrix of a1*/
         c1,           /*Inequalities split into c1 and c2*/
         c2,
         new_in_eq,    /*Inequalities obtained from Equalities*/
         org_ineq,     /*Modified original Inequalities*/
         final_mat,    /*The final Domain*/
         inva1_a2;     /*Product of Inverse of a1 and a2*/

  VECTOR inva1_b,      /*Product of InverseA1 and vector, rhs of equalities*/
         eq_rhs,       /*Right hand side of the equalities*/
         ineq_rhs,     /*Right hand side of the inequalities*/
         ldomain,      /*Lower limits of the domains*/
         udomain,      /*Upper limits of the domains*/
         l1,           /*lower and upper limits corresponding to the variables*/
         l2,                        /*in x1 and x2*/
         u1,
         u2,
         X;            /*Initial values for the variables*/

  IMATRIX var_order;   /*Order of the variables x1 followed by x2*/

  IVECTOR eq_co,       /*Vector X for the Equalities*/
          ineq_co,     /*Vector X for the Inequalities*/
          x1,          /*eq_co divided into x1 and x2*/
          x2,
          cart;        /*Array containing the 'p' variables*/

  FLAG _PROGEND;       /*Flag to check the correctness of input data*/

  int
    cart_count = 0,  /*Get a different combination of x2 variables*/
    tot_combi,       /*Total combinations of x2 variables*/
    tot_var,         /*Total number of variables in the problem*/
    tot_equ,         /*Total number of equalities, also p-equalities*/
    x2_vari;         /*Remaining variables after p-variables were eliminated*/

  INDEX fin;    /*Size of final matrix*/

  INDEX newin,         /*Size of new inequalities*/
        a1a2;          /*Size of the product matrix a1_a2*/

  int i,k,             /*Counter variables*/
      org_col,         /*Final inequalities col - x2_variables + RHS of ineq*/
      tot_ine,         /*Total number of inequalities*/
      tot_dom,         /*Total number of domains, given in the input file*/
      tot_arr[4];      /*Array holding total number of variables, equalities,*/
                       /*inequalites and domains in the same order*/
  time_t start_time,
         stop_time;
  unsigned long delta_time;
  char   time_str[27];

/********************************************************************************/

#if DOS_SYS
  timezone = 60*60*(EST_OFFSET+5);  /* compute offset form GMT */
#endif
  start_time = time(NULL);
  strcpy(time_str, ctime(&start_time));

  fprintf(output,"%s\n",time_str);
  fflush(output);

#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif

  /* set external ptrs for control file values to point to external structures */
  octrl = ctrlvals + whichcontrol;
  gosp = gosvec + whichcontrol;
  if (firsttime_g[whichcontrol] == 0) {
    if (whichcontrol < NUMCONTROLS) {
      
      tot_arr[0] = runvars;  /*total variables (i.e., parameters)*/
      tot_arr[1] = 0;  /*total equalities*/
      tot_arr[2] = 0;  /*total inequalities*/
      tot_arr[3] = runvars;  /*total domains*/

      tot_var = tot_arr[0];    /*total number of variables*/
      if (tot_var > MAX_VAR) {
	fprintf(output,"Too many variables - Increase MAX_VAR in header file");
	exit(4);
      }
      tot_equ = tot_arr[1];    /*total number of equalities*/
      tot_ine = tot_arr[2];    /*total number of inequalities*/
      gosp->tot_var = tot_var;
      gosp->tot_equ = tot_equ;

      /*
      gosp->equalities = matrix(1,tot_equ,1,tot_var+1);
      gosp->inequalities = matrix(1,tot_ine,1,tot_var+1);
      gosp->domains = matrix(1,tot_var,1,3);
      */

      /*Reading from the control file:
	the population size,
	total number of generations,
	total number of times to apply each of the operators,
	probability of the best agent,
	minimization or maximization problem,
	the parameters for the operators,
	BFGS control parameters
      */

      octrl->pop_size = population_size[whichcontrol];
      octrl->genbound = run_notdone_lim;
      octrl->P1 = oper1_use[whichcontrol];
      octrl->P2 = oper2_use[whichcontrol];
      octrl->P3 = oper3_use[whichcontrol];
      octrl->P4 = oper4_use[whichcontrol];
      octrl->P5 = oper5_use[whichcontrol];
      octrl->P6 = oper6_use[whichcontrol];
      octrl->P7 = oper7_use[whichcontrol];
      octrl->P8 = oper8_use[whichcontrol];
      octrl->gradtol = control_gradient_tolerance[whichcontrol];

      octrl->Q = 0.2;
      octrl->MinMax = 0;
      octrl->B = 6;
      octrl->STEP = 10;
      octrl->portion = 0.1;
      
      fprintf(output,"Number of operators   : %d  %d  %d  %d  %d  %d  %d  %d\n",
	      octrl->P1, octrl->P2, octrl->P3, octrl->P4, octrl->P5, octrl->P6,
	      octrl->P7, octrl->P8);
      fprintf(output,"Number of generations : %lu\n", octrl->genbound);
      fprintf(output,"Population size       : %d\n", octrl->pop_size);
      fprintf(output,"Gradient tolerance    : %17.10e\n", octrl->gradtol);
      /* fprintf(output,"Portion for BFGS      : %10.9lf\n", octrl->portion);
      fprintf(output,"Parameter B           : %d\n", octrl->B);
      fprintf(output,"Parameter Q           : %lf\n", octrl->Q); */

    }
    else {
      k = runvars_array[0] - runvars;  /* number of boundary-hit constraints */
      /* determine which boundary-hit pop this is */
      i = whichcontrol - NUMCONTROLS;
      if (i % 2 == 0)
	*octrl = ctrlvals[0];  /* copy from fullsample */
      else
	*octrl = ctrlvals[1];  /* copy from BIG */


      tot_arr[0] = runvars;  /*total variables (i.e., parameters)*/
      tot_arr[1] = 0;  /*total equalities*/
      tot_arr[2] = 0;  /*total inequalities*/
      tot_arr[3] = runvars;  /*total domains*/

      tot_var = tot_arr[0];    /*total number of variables*/
      tot_equ = tot_arr[1];    /*total number of equalities*/
      tot_ine = tot_arr[2];    /*total number of inequalities*/
      gosp->tot_var = tot_var;
      gosp->tot_equ = tot_equ;
    }

    fin.r = tot_arr[2]+tot_arr[0];    /*total number of inequalities + domains*/
    fin.c = tot_arr[0]-tot_arr[1]+2;  /*x2 variables + lower limits + upper limits*/
    org_col = tot_arr[0]-tot_arr[1]+1;/*x2 variables + rhs*/
    x2_vari = tot_arr[0] - tot_arr[1];/*total variables - p-equalities*/
    newin.r = tot_equ;
    newin.c = fin.c;
    a1a2.r = tot_equ;
    a1a2.c = org_col;

    gosp->x2_vari = x2_vari;
    gosp->fin.r = fin.r;
    gosp->fin.c = fin.c;

    /*Allocating memory for all the vectors and matrices*/
    gosp->final_mat = matrix(1,fin.r,1,fin.c);

    gosp->eq_co = ivector(1,tot_var);
    gosp->eq_rhs = vector(1,tot_equ);
    gosp->a1 = matrix(1,tot_equ,1,tot_equ);
    gosp->a2 = matrix(1,tot_equ,1,x2_vari);
    gosp->inv_a1 = matrix(1,tot_equ,1,tot_equ);
    gosp->inva1_a2 = matrix(1,tot_equ,1,x2_vari);
    gosp->inva1_b = vector(1,tot_equ);
    gosp->new_in_eq = matrix(1,tot_equ,1,fin.c);

    gosp->ineq_co = ivector(1,tot_var);
    gosp->ineq_rhs = vector(1,tot_ine);
    gosp->c1 = matrix(1,tot_ine,1,tot_equ);
    gosp->c2 = matrix(1,tot_ine,1,x2_vari);
    gosp->org_ineq = matrix(1,tot_ine,1,org_col);

    gosp->ldomain = vector(1,tot_var);
    gosp->udomain = vector(1,tot_var);

    gosp->l1 = vector(1, tot_equ);
    gosp->u1 = vector(1, tot_equ);
    gosp->x1 = ivector(1,tot_equ);

    gosp->l2 = vector(1, x2_vari);
    gosp->u2 = vector(1, x2_vari);
    gosp->x2 = ivector(1,x2_vari);

    gosp->X = vector(1,tot_var);
    gosp->var_order = imatrix(1,tot_var,1,2);
    gosp->cart = ivector(1,tot_equ);
  }

  /* get local objects from values saved in structure gos */
  tot_var = gosp->tot_var;
  tot_equ = gosp->tot_equ;
  x2_vari = gosp->x2_vari;
  fin.r = gosp->fin.r;
  fin.c = gosp->fin.c;
  final_mat = gosp->final_mat;
  equalities = gosp->equalities;
  eq_co = gosp->eq_co;
  eq_rhs = gosp->eq_rhs;
  a1 = gosp->a1;
  a2 = gosp->a2;
  inv_a1 = gosp->inv_a1;
  inva1_a2 = gosp->inva1_a2;
  inva1_b = gosp->inva1_b;
  new_in_eq = gosp->new_in_eq;
  inequalities = gosp->inequalities;
  ineq_co = gosp->ineq_co;
  ineq_rhs = gosp->ineq_rhs;
  c1 = gosp->c1;
  c2 = gosp->c2;
  org_ineq = gosp->org_ineq;
  domains = gosp->domains;
  ldomain = gosp->ldomain;
  udomain = gosp->udomain;
  l1 = gosp->l1;
  u1 = gosp->u1;
  x1 = gosp->x1;
  l2 = gosp->l2;
  u2 = gosp->u2;
  x2 = gosp->x2;
  X = gosp->X;
  var_order = gosp->var_order;
  cart = gosp->cart;

  if (firsttime_g[whichcontrol] == 0) {
    /*Initialization*/
    for(i=1; i<=tot_var; i++)
      {
	eq_co[i] = i;
	ineq_co[i] = i;
      }
    for(i=1; i<=tot_equ; i++)
      eq_rhs[i] = equalities[i][tot_var+1];
    for(i=1; i<=tot_ine; i++)
      ineq_rhs[i] = inequalities[i][tot_var+1];

    if (whichcontrol < NUMCONTROLS) {
      print_domains(domains,tot_var);
    }
  }

  if (firsttime_g[whichcontrol] == 0) {
    gosp->cart_count = cart_count;
    do {
      for (i=1; i<=tot_var; i++) {
	l2[i] = domains[i][1];
	x2[i] = domains[i][2];
	u2[i] = domains[i][3];
      }
      initialize(final_mat,fin);
      find_final_mat1(l2,u2,final_mat,tot_var,fin.c);

      /*This function gets a set of starting points for the variables*/
      _PROGEND = initialize_x2(final_mat,fin,x1,x2,tot_equ,X,inva1_b);
    } while((!_PROGEND)&&(cart_count < tot_combi));

    firsttime_g[whichcontrol] = 1;
  }

  if (reset_from_X == 2) for (i=1; i<=fin.c-2; i++) X[i] = Xprev[varmap[i-1]+1];
  converged_flag = 0;
  optimization(X,x2,x2,final_mat,fin,tot_equ,inva1_b,domains);
  for (i=1; i<=fin.c-2; i++) Xprev[varmap[i-1]+1] = X[i];

  /* free allocated objects in reverse order of allocation, to try to
     minimize fragmentation (hopefully free() can recombine all the blocks */
  /*
  free_ivector(gosp->cart,1);
  free_imatrix(gosp->var_order,1,tot_var,1);
  free_vector(gosp->X,1);

  free_ivector(gosp->x2,1);
  free_vector(gosp->u2,1);
  free_vector(gosp->l2,1);

  free_ivector(gosp->x1,1);
  free_vector(gosp->u1,1);
  free_vector(gosp->l1,1);

  free_vector(gosp->udomain,1);
  free_vector(gosp->ldomain,1);
  free_matrix(gosp->domains,1,tot_var,1);

  free_matrix(gosp->org_ineq,1,tot_ine,1);
  free_matrix(gosp->c2,1,tot_ine,1);
  free_matrix(gosp->c1,1,tot_ine,1);
  free_vector(gosp->ineq_rhs,1);
  free_ivector(gosp->ineq_co,1);
  free_matrix(gosp->inequalities,1,tot_ine,1);

  free_matrix(gosp->new_in_eq,1,tot_equ,1);
  free_vector(gosp->inva1_b,1);
  free_matrix(gosp->inva1_a2,1,tot_equ,1);
  free_matrix(gosp->inv_a1,1,tot_equ,1);
  free_matrix(gosp->a2,1,tot_equ,1);
  free_matrix(gosp->a1,1,tot_equ,1);
  free_vector(gosp->eq_rhs,1);
  free_ivector(gosp->eq_co,1);
  free_matrix(gosp->equalities,1,tot_equ,1);
  free_matrix(gosp->final_mat,1,fin.r,1);
  */

  stop_time = time(NULL);
  delta_time = (unsigned long) stop_time - start_time;
  fprintf(output,"\nTotal run time : %lu seconds\n\n",delta_time);

}

double frange_ran(double llim, double ulim)
{

  /*llim, ulim:  The upper and lower limits between which the random
      number is to be generated*/

  double num1, diff = ulim - llim;

  if (diff == 0)
    return(llim);
  else if(diff < 0.0001)
    return((flip() == TAIL) ? llim : ulim);
  do
    num1 = llim +  newunif()*(ulim-llim) ;
  while((num1<llim)||(num1>ulim));
  return(num1);
}

