/*

  The code in this file has been adapted from Press, Teukolsky, Vetterling
  and Flannery (1992). "Numerical Recipes in C."

*/


#include "data.h"
#include "lisrel.h"
#include "gradient.h"
#include "bfgs.h"

static char *sccsversion = "@(#)bfgs.c	11.4   7/23/98";

#define ITMAX 900    /* max number of small iterations */
#define MAXBIG 30    /* max number of big iterations */
#define EPS 0.000000000000001   /* machine precision */
#define TOLX (4*EPS) /* convergence criterion on x values */
#define STPMX 100000      /* scaled maximum step length allowed in 
                        line searches */
#define LM_MAX 1000   /* the maximum number of LM steps */

short int stepcheck;

/*defs */
static double maxarg1, maxarg2;
#define FMAX(a,b) (maxarg1=(a), maxarg2=(b), (maxarg1) < (maxarg2) ?\
(maxarg1) : (maxarg2))

void dfgsmin(double *p, int n, double gtol, int *iter, double *fret, double *hessian)
{
  extern int observedy, runvars;
  extern short int stepcheck;

  int check, i , its, j, bigloop, nullity, k;
  short int print_bfgs, lm_fix;
  double den, fac, fad, fae, fp, stpmax, sum=0.0,sumdg,sumxi, temp,test;
  double newstep;

  static short int firsttime=0;
  static double *dg, *g, *hdg, *pnew, *xi;

  if (firsttime==0) {
    dg = (double *) malloc((runvars)*sizeof(double));
    g = (double *) malloc((runvars)*sizeof(double));
    hdg = (double *) malloc((runvars)*sizeof(double));
    pnew = (double *) malloc((runvars)*sizeof(double));
    xi = (double *) malloc((runvars)*sizeof(double)); 
    firsttime=1;
  }

  fp=(double) lisrel(p); /* calculate starting function value and gradient */
  gradient(p,g);  /* calculate the original gradient */

  newstep=STPMX;
  print_bfgs=0;
  /*fprintf(output,"Starting BFGS\n");*/
  stepcheck=1;
  for(bigloop=1;bigloop<=MAXBIG;bigloop++)  {

    if (stepcheck == 0) {
      /*     fprintf(output,"Bigloop exit\n");*/
      break;
    }

    if (stepcheck == 1)
      stepcheck=0;

    /* initialize the est. inverse Hessian to the unit matrix */
    for (i=0;i<n;i++) {
      for (j=0;j<n;j++) hessian[M(i,j,runvars)]=0.0;
      hessian[M(i,i,runvars)]=1.0;
      xi[i]=-g[i];
      sum += p[i]*p[i];
    }

    stpmax=newstep*FMAX(sqrt(sum),(double)n);

    /* INNER LOOP OVER ITERATIONS */
    for (its=1;its<=ITMAX;its++) {
      *iter=its;

      lnsrch(n,p,fp,g,xi,pnew,fret,stpmax,&check);

      if (stepcheck == 1) {
	/*     fprintf(output,"STEP SIZE CHANGE: breaking inner loop\n");*/
	newstep=newstep/2;
	break;
      }

      fp= *fret;

      /* update line direction, and the current point */
      for (i=0;i<n;i++) {
	xi[i]=pnew[i]-p[i];
	p[i]=pnew[i];
      }   

      /* test for convergence */
      test=0.0;
      for (i=0;i<n;i++) {
	temp=fabs(xi[i])/FMAX(fabs(p[i]),1.0);
	if (temp > test) test=temp;
      }

      if (test < TOLX) {
	/*
	fprintf(output,"\nThe job ended at BIG(%i):%i\n",bigloop,its);
	fprintf(output,"TOLX exit\n");
	fprintf(output,"The final parms and gradients at fit value(%lf) are:\n",*fret);
	for(i=0;i<observedy;i++) 
	  fprintf(output,"X[%i] = %lf; \t with grad=%lf\n",i+1, p[i], g[i]);
	*/
	return;
      }

      /* Save the old Gradient, and get the new gradient.
	 Test for convergence on zero gradient */
      for (i=0;i<n;i++) dg[i]=g[i];

      gradient(p,g);
      test=0.0;
      den=FMAX(*fret, 1.0);

      for (i=0;i<n;i++)
	{
	  temp=fabs(g[i])*FMAX(fabs(p[i]),1.0)/den;
	  if (temp > test) test=temp;
	}

      if (test < gtol) {
	/*
	fprintf(output,"\nThe job ended at BIG(%i):%i\n",bigloop,its);
	fprintf(output,"GTOL exit\n");
	fprintf(output,"The final parms and gradients at fit value(%lf) are:\n",*fret);
	for(i=0;i<observedy;i++) 
	  fprintf(output,"X[%i] = %lf; \t with grad=%lf\n",i+1, p[i], g[i]);
	*/      
	return;
      }

      /* Compute difference of gradients, and difference times current matrix */
      for (i=0;i<n;i++) dg[i]=g[i]-dg[i];
      for (i=0;i<n;i++) 
	{
	  hdg[i]=0.0;
	  for (j=0;j<n;j++) hdg[i] += hessian[M(i,j,runvars)]*dg[j];
	}

      /* Calculate dot products for the denomminators */
      fac=fae=sumdg=sumxi=0.0;
      for (i=0;i<n;i++)
	{
	  fac += dg[i]*xi[i];
	  fae += dg[i]*hdg[i];
	  sumdg += dg[i]*dg[i];
	  sumxi += xi[i]*xi[i];
	}

      /* Skip update if fac not sufficiently positive */
      if (fac*fac > EPS*sumdg*sumxi)
	{
	  fac=1.0/fac;
	  fad=1.0/fae;
	  /* The Vector that makes BFGS different from DFP */
	  for (i=0;i<n;i++) dg[i]=fac*xi[i]-fad*hdg[i];
	  /* The BFGS Update Formula */
	  for (i=0;i<n;i++)
	    {
	      for (j=0;j<n;j++)
		{
		  hessian[M(i,j,runvars)] += fac*xi[i]*xi[j]-fad*hdg[i]*
		    hdg[j]+fae*dg[i]*dg[j];
		}
	    }
	}

      /* check that the hessian is positive definite */
      hessian_positive_check(hessian, &nullity);
      if (nullity != 0) { 

	/*
	if (print_bfgs==0) {
	  fprintf(output,"bfgs:  singular hessian (%d), using LM correction.", 
		 nullity);
	  fprintf(output," matrix.\n"); 
	  print_bfgs=1;
	}
	*/
	

	lm_fix=0; /* lm didn't fix the problem */
	for (k=0; k<LM_MAX; k++) {
	  sum=0.0;
	  for (i=0;i<n;i++) {
	    hessian[M(i,i,n)] += .1*(k+1)*10; 
	    xi[i]=-g[i];
	    sum += p[i]*p[i];
	  }

	  hessian_positive_check(hessian, &nullity);
	  if (nullity==0) {
	    /*	    fprintf(output,"hessian PD at k=%d\n", k); */
	    lm_fix=1;
	    break;
	  }
	} /* end of LM_MAX loop */

	if (lm_fix==0) {
	  /* fprintf(output,"LM faluire. k=%d\n", k); */
	  /* replace hessian with identity matrix */
	  sum=0.0;
	  for (i=0;i<n;i++) {
	    for (j=0;j<n;j++)
	      hessian[M(i,j,n)]= 0.0;
	    hessian[M(i,i,n)]= 1.0;
	    xi[i]=-g[i];
	    sum += p[i]*p[i];
	  }
	} /* end of lm_fix==0 */
      } /* end of nullity!=0 */


      /* The next direction to go in */
      for (i=0;i<n;i++)
	{
	  xi[i]=0.0;
	  for (j=0;j<n;j++) xi[i] += hessian[M(i,j,runvars)]*g[j];
	  xi[i] *= -1.0;
	}
	
    } /* end of iteration loop */
  } /* end of bigloop */
} /* end of function */


/* THE LNSRCH CALL */
#define ALF 1.0e-4  /* ensures sufficient decrease in function */

void lnsrch(int n, double *xold, double fold, double *g, double *p,
            double *x, double *f, double stpmax, int *check)
{
  extern int observedy, runvars;

  int i;
  double a, alam, alam2, alamin, b, disc, f2, fold2, rhs1, rhs2, slope,
  sum, temp, test, tmplam;
  
  *check=0;
  for (sum=0.0,i=0;i<n;i++) sum += p[i]*p[i];
  sum=sqrt(sum);
  if (sum > stpmax)
    for (i=0; i<n; i++) p[i] *= stpmax/sum; /* scale if attempted step is too big */
  for (slope=0.0, i=0;i<n;i++)
    slope += g[i]*p[i];
  test=0.0;
  for (i=0;i<n;i++) {
    temp=fabs(p[i])/FMAX(fabs(xold[i]),1.0);
    if (temp > test) test=temp;
  }

  alamin=TOLX/test;
  alam=1.0;
  for (;;) {
    for (i=0;i<n;i++) x[i]=xold[i]+alam*p[i];

    /* fprintf(output,"\n the x is:\n");
       for (i=0;i<observedy;i++) fprintf(output,"X[%i]=%lf\n", i, x[i]); */

    *f=(double) lisrel(x);

    /*  if (stepcheck == 1) {
	fprintf(output,"STEP SIZE CHANGE: leaving lnsrch\n");
	return;
	} */

    if (alam < alamin) {
      for (i=0;i<n;i++) x[i]=xold[i];
      *check=1;
      return;
    } else if (*f <= fold+ALF*alam*slope) return;
    else {
      if (alam == 1.0)
	tmplam = -slope/(2.0*(*f-fold-slope));

      else {
	rhs1 = *f-fold-alam*slope;
	rhs2=f2-fold2-alam2*slope;
	a=(rhs1/(alam*alam)-rhs2/(alam2*alam2))/(alam-alam2);
	b=(-alam2*rhs1/(alam*alam)+alam*rhs2/(alam2*alam2))/(alam-alam2);
	if (a == 0.0) tmplam = -slope/(2.0*b);
	else {
	  disc=b*b-3.0*a*slope;
	  if (disc<0.0) { 
	    /*           fprintf(output,"\nROUNDOFF PROBLEM IN LNSRCH.\n");*/
	    stepcheck=1;
	    return;
	  }
	  else tmplam=(-b+sqrt(disc))/(3.0*a);
	}
	if (tmplam>0.5*alam) tmplam=0.5*alam;  
      }
    }

    alam2=alam;
    f2= *f;
    fold2=fold;
    alam=FMAX(tmplam,0.1*alam);
  }

} /* end of procedure */


#define TOOSMALL ((double) 2.0e-14)
void hessian_positive_check(double *hessian, int *nullity)
{
  extern int runvars;
  static short int firsttime=0;

  static double *hessian2, *w;
  int i, j, k, row;
  double sum;


  if (firsttime==0) {
    hessian2 = 
      (double *) malloc(((runvars*runvars)+(runvars))*sizeof(double));
    w = 
      (double *) malloc(((runvars*runvars)+(runvars))*sizeof(double));
    firsttime =1;
  }

  *nullity = 0;
  for (row=0; row<runvars; row++) {
    /* First compute w[M(row,row,runvars)] */
    sum = hessian[M(row,row,runvars)];
    for (j=0; j<row; j++) sum -= w[M(j,row,runvars)]*w[M(j,row,runvars)];
    if (sum > TOOSMALL) {
      w[M(row,row,runvars)] = sqrt(sum);
      /* Now find elements w[M(row,k,runvars)], k > row. */
      for (k=(row+1); k<runvars; k++) {
	sum = hessian[M(row,k,runvars)];
	for (j=0; j<row; j++) 
	  sum -= w[M(j,row,runvars)]*w[M(j,k,runvars)];
	w[M(row,k,runvars)] = sum/w[M(row,row,runvars)];
      }
    }
    else {  /* blast off the entire row. */
      for (k=row; k<runvars; k++) w[M(row,k,runvars)] = 0.0;
      (*nullity)++;
    }
  }

} /* end of hessian_positive_check procedure */
