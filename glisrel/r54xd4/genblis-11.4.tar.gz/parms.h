/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



/* @(#)parms.h	11.4   7/23/98 */

#ifndef PARMS_H_READ_ALREADY

#define PARMS_H_READ_ALREADY 1

enum parmtypes { LAMBDAY, THETAEPS, BETA, PSI };
extern char *parmsyms[4];

#define NUMCONTROLS 4

#define MAXBOUNDHITS 5
#define NUMOFMODELS ((2*MAXBOUNDHITS)+NUMCONTROLS)

#define M(ROW,COL,NCOLS) (((ROW)*(NCOLS))+(COL))

#define NOCHANGE_SHRINK 999999

#define MAXPARMS 1000 /* the maximum number of estimated parms
			 (automatically sets MAX_VAR in genoud.h) */

#define MAXPATH 4096 /* maximum length in characters of path/filename strings */

#define OFFSET 5  /* record file offset --i.e., nparms+?? 
		     5= non-cox test version */

#endif
