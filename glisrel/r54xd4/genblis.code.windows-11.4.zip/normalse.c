/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include <string.h>
#include "data.h"
#include "genoud.h"
#include "init.h"
#include "lisrel.h"
#include "gradient.h"
#include "multi.h"
#include "inverse.h"
#include "numgrads.h"
#include "normalse.h"

static char *sccsversion = "@(#)normalse.c	11.4   7/23/98";

void copy(double *in, double *target, int row, int col);

static int whichparm;

struct NormalAsy *Normal_SEs(void)
{
  extern struct gspecobjs gosvec[NUMOFMODELS];
  extern int boundary_flag;
  extern int runvars, runvars_array[MAXBOUNDHITS+1];
  extern int *whereXrow, *whereXcol;
  extern int *whereXtype;
  extern int whichcontrol, converged_flag;
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap, *varmap_array[MAXBOUNDHITS+1];
  extern int *boundary_hit, *boundary_use;

  static int firsttime = 0;
  static int *varmapsave;
  static double *ihessian, *SEvector, *MLEvector;
  static struct NormalAsy *NAstruct;

  int i;
  int holdcontrol, usecontrol=0;
  int issingular = 0;
  struct gspecobjs *gosp;

  if (firsttime==0) {
    varmapsave = (int *) malloc(runvars_array[0]*sizeof(int));
    SEvector = (double *) malloc(runvars_array[0]*sizeof(double));
    MLEvector = (double *) malloc(runvars_array[0]*sizeof(double));
    NAstruct = (struct NormalAsy *) malloc(sizeof(struct NormalAsy));
    firsttime=1;
  }

  holdcontrol = whichcontrol;
  whichcontrol = usecontrol;
  gosp = gosvec + usecontrol;

  if (boundary_flag > 0) {
    whichcontrol = NUMCONTROLS + (boundary_flag-1)*2;
    runvars = runvars_array[boundary_flag];
    whereXrow = whereXrow_array[boundary_flag];
    whereXcol = whereXcol_array[boundary_flag];
    whereXtype = whereXtype_array[boundary_flag];
    varmap = varmap_array[boundary_flag];
    onboundset(holdcontrol, whichcontrol, boundary_flag, boundary_hit);
  }

  ihessian = DoNormalSE(gosp->X, 0, &issingular);

  whichcontrol = holdcontrol;

  for (i=0; i<runvars_array[usecontrol]; i++) {
    MLEvector[i] = gosp->X[i+1];
    varmapsave[i] = varmap[i];
    if (issingular==1 || boundary_use[i]==1)
      SEvector[i] = 0.0;
    else
      SEvector[i] = sqrt(ihessian[M(i,i,runvars)]);
  }

  NAstruct->nallparms = runvars_array[usecontrol];
  NAstruct-> ncovparms = runvars;
  NAstruct->varmap = varmapsave;
  NAstruct->issingular = issingular;
  NAstruct->MLEvector = MLEvector;
  NAstruct->SEvector = SEvector;
  NAstruct->AsyCovmat = ihessian;

  return NAstruct;
}

double NSElisrelg(double *parmvector)
{
  extern int runvars_array[MAXBOUNDHITS+1];

  extern int whichparm;

  static int firsttime = 0;
  static double *gwrk = NULL;

  if (firsttime==0) {
    gwrk = (double *) malloc(runvars_array[0]*sizeof(double));
    firsttime=1;
  }

  gradient(parmvector, gwrk);
  return gwrk[whichparm];
}

double *DoNormalSE(double *X, int usecontrol, int *issingular)
{
  extern int runcases;
  extern int runvars, runvars_array[MAXBOUNDHITS+1];
  extern int whichcontrol;
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap;
  extern int *boundary_hit, *boundary_use;

  extern int whichparm;

  extern double NSElisrelg(double *);

  static int firsttime = 0;
  static int runvars0;
  static int *indx;
  static double *parmvector, *hessian, *ihessian, *iwrkmat, *colwrk;
  static struct estints *estructure;

  int i, ii, j;
  int ndiffs = 9;
  int nparms;
  double hwrk, ncadj;

  double (*func4g)(double *) = NSElisrelg;

  if (firsttime==0) {
    runvars0 = runvars_array[0];
    /* allocate storage for vectors used in computing numerical gradients */
    epsacc = (double *) malloc(runvars0*sizeof(double));
    optint = (double *) malloc(runvars0*sizeof(double));
    indx = (int *) malloc((1+runvars0*runvars0)*sizeof(int));
    parmvector = (double *) malloc(runvars0*sizeof(double));
    hessian = (double *) malloc(runvars0*runvars0*sizeof(double));
    ihessian = (double *) malloc(runvars0*runvars0*sizeof(double));
    iwrkmat = (double *) malloc(runvars0*runvars0*sizeof(double));
    colwrk = (double *) malloc(runvars0*runvars0*sizeof(double));
    firsttime=1;
  }

  nparms = runvars;

  for (j=0; j<runvars; j++) {
    whichparm = j;
    for (ii=0, i=0; i< runvars_array[usecontrol]; i++, ii++) {
      while (boundary_use[varmap[ii]]==1) ii++;
      parmvector[i] = X[varmap[ii]+1];
    }

    /* estimate optimal intervals for the numerical gradients at starting values */
    estructure = estoptint(nparms, ndiffs, 0, parmvector, func4g);

    /* use forward differences (phi) */
    for (i=0; i< runvars; i++) hessian[M(i,j,runvars)] = estructure->phi[i];
  }

  /* ensure that hessian is exactly symmetric */
  /* also, adjust for number of cases and constant 2.0 */
  ncadj = ((double)runcases)/2.0;
  for (j=0; j< runvars; j++) {
    hessian[M(j,j,runvars)] *= ncadj;
    for (i=0; i<j; i++) {
      hwrk = (hessian[M(j,i,runvars)]+hessian[M(i,j,runvars)])/2.0;
      hessian[M(j,i,runvars)] = hessian[M(i,j,runvars)] = hwrk * ncadj;
    }
  }

  *issingular = InvertHessian(runvars,hessian,ihessian,iwrkmat,colwrk,indx);

  return ihessian;
}

void PrintNormalSEs(struct NormalAsy *NAstruct, FILE *outfile)
{
  extern char *parmsyms[4];
  extern int *whereXtype;
  extern int *whereXrow, *whereXcol;
  extern int runcases, degrees_of_freedom;

  int i, len, len0;
  double mle, se, lo, up, znorm = 1.95996398454005;
  char buf[128];
  char *parmheader = "parameter";

  if (NAstruct->issingular == 1) {
    fprintf(outfile,"%s\n%s\n\n",
	"ERROR:  THE HESSIAN EVALUATED AT THE PARAMETER ESTIMATES IS SINGULAR.",
	"Standard errors cannot be computed.  Values are printed as zero.");
  }
  if (NAstruct->issingular == 2) {
    fprintf(outfile,"%s\n%s\n\n",
	"ERROR:  THE HESSIAN EVALUATED AT THE PARAMETER ESTIMATES IS SINGULAR.",
	"Standard errors of the unidentified parameters are printed as NaNQ.");
  }

  /* determine length of the longest parameter name */
  for (len0=0, i=0; i < NAstruct->nallparms; i++) {
    sprintf(buf,"%s %d %d (%d)",
	    parmsyms[whereXtype[i]], whereXrow[i]+1, whereXcol[i]+1,i+1);
    len = strlen(buf);
    if (len>len0) len0=len;
  }
  len0 -= strlen(parmheader);
  for (i=0; i<(-len0); i++) buf[i] = ' ';
  buf[i] = 0;

  fprintf(outfile,"\n\n*********************************************************************************\n\n");
  fprintf(outfile,"FULL SAMPLE RESULTS\n\n");
  fprintf(outfile,"Fit: %17.10e \t N: %d \n", record[M(0,0,runvars+OFFSET)], runcases);
  fprintf(outfile,"Chi-square goodness-of-fit: %17.10e \t df: %d\n\n",
	  record[M(0,0,runvars+OFFSET)]*(runcases-1), degrees_of_freedom);
  fprintf(outfile,"Parameter MLEs and Normal-theory Asymptotic Standard Errors\n");
  fprintf(outfile,"%s",parmheader);
  for (i=0; i<len0; i++) fputc(' ',outfile);
  fprintf(outfile,"\tMLE\t\t    SE\t\t\t %s\n","t-statistic");
  for (i=0; i < NAstruct->nallparms; i++) {
    mle = NAstruct->MLEvector[i];
    se = NAstruct->SEvector[i];
    lo = mle - znorm*se;
    up = mle + znorm*se;
    fprintf(outfile,"%s %d %d (%d)%s\t%17.10e   %17.10e   %11.4e\n",
	    parmsyms[whereXtype[i]], whereXrow[i]+1, whereXcol[i]+1, i+1, buf,
	    mle,se,(mle/se));
  }
  fprintf(outfile,"\n");
}

void PrintNormalCovmat(struct NormalAsy *NAstruct, FILE *outfile)
{
  int i, j, nparms = NAstruct->ncovparms;

  if (NAstruct->issingular > 0) {
    fprintf(outfile,"%s\n%s\n",
	"ERROR:  THE HESSIAN EVALUATED AT THE PARAMETER ESTIMATES IS SINGULAR.",
	"The asymptotic covariance matrix cannot be computed.");
  }
  else {
    fprintf(outfile,
       "Asymptotic Covariance Matrix of Estimated (Off-Boundary) Parameters:\n");
    fprintf(outfile,"pnum  ");
    for (i=0; i<nparms; i++)
      fprintf(outfile,"%s%4d", "              ", NAstruct->varmap[i]+1);
    fprintf(outfile,"\n");
    for (i=0; i<nparms; i++) {
      fprintf(outfile,"%4d  ", NAstruct->varmap[i]+1);
      for (j=0; j<nparms; j++) {
	fprintf(outfile," %17.10e", NAstruct->AsyCovmat[M(i,j,nparms)]);
      }
      fprintf(outfile,"\n");
    }
  }
  fflush(outfile);
}

int InvertHessian(int size, double *hessian, double *ihessian, double *trash,
		      double *col, int *indx)
{
  static double d;
  int i, j, issingular = 0;

  copy(hessian,trash,size,size);
  issingular = ludcmpH(trash,size,indx,&d);
  if (issingular==0) {
    for (j=0;j<size;j++) {
      for(i=0;i<size;i++) col[i]=0.0;
      col[j]=1.0;
      lubksb(trash,indx,col,size);
      for(i=0;i<size;i++) ihessian[M(i,j,size)]=col[i];
      if (ihessian[M(j,j,size)] <= 0.0)
	issingular = 2;
    }
  }
  else {
    for (j=0;j<size;j++) {
      for(i=0;i<size;i++)
	ihessian[M(i,j,size)]=0.0;
    }
  }
  return issingular;
}
