/* @(#)bfgs.h	1.4   7/23/98 */

extern short int stepcheck;

void dfgsmin(double *p, int n, double gtol, int *iter, double *fret, double *hessian);
void lnsrch(int n, double *xold, double fold, double *g, double *p,
            double *x, double *f, double stpmax, int *check);
void hessian_positive_check(double *hessian, int *nullity);
