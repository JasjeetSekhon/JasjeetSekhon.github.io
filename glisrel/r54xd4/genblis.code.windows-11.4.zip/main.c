/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include <string.h>

#include "data.h"
#include "init.h"
#include "toplevel.h"

static char *sccsversion = "@(#)main.c	11.4   7/23/98";

int main(int argc, char *argv[])
{
  extern int runcases, runboots, observedy, latenty, runvars, runfixvars;
  extern int rungroups, *runcasesv, *observedyv;
  extern char modelfilename[MAXPATH];

  extern char redirect_stdout[MAXPATH];
#if WINDOWS_SYS
  extern short int redirect_trigger;
#endif

  if (argc == 2) {
    strcpy(modelfilename, argv[1]);
    output=stdout;
#if WINDOWS_SYS
    redirect_trigger=0;
#endif

  }
  else if (argc == 3) {
    strcpy(modelfilename, argv[1]);
    strcpy(redirect_stdout, argv[2]);
    
    if((output = fopen(redirect_stdout, "w")) == NULL) {
      fprintf(stderr,"cannot open file:  %s\n", redirect_stdout);
      exit(1);
    }
#if WINDOWS_SYS
    redirect_trigger=1;
#endif
  }
  else {
    strcpy(modelfilename, "modelspec");
    output=stdout;
#if WINDOWS_SYS
    redirect_trigger=0;
#endif
  }

  definemodel();
  printspecs(0,0);
  fclose(flistfile);
  
  toplevel(rungroups, runcasesv, runcases, runboots, observedyv, observedy, runvars);

  fclose(flistfile);
  fclose(output);
  exit(0);
} /* end main */

