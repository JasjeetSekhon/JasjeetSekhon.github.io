/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include "data.h"

static char *sccsversion = "@(#)data.c	1.4   7/23/98";

#if UNIX_SYS
  FILE *input, *output, *flistfile;
#endif

char redirect_stdout[MAXPATH];
#if WINDOWS_SYS
short int redirect_trigger;
#endif

int whichcontrol;
int reset_from_X;
int converged_flag;
short int runcovflag, jacks, doboots, dobig, bootstrapdetails, covmatrix;
int usecovflag, usecrosspflag, usecorrflag, weightflag;
int *caseuse;
long int number, jacknumber,bootnumber;
int doing;
int boundary_flag;
int *boundary_hit, *boundary_use;
int constrained_flag;

/* global variables required to get rid of the control files */
int population_size[NUMCONTROLS], 
  oper1_use[NUMCONTROLS], oper2_use[NUMCONTROLS], oper3_use[NUMCONTROLS], 
  oper4_use[NUMCONTROLS], oper5_use[NUMCONTROLS], oper6_use[NUMCONTROLS], 
  oper7_use[NUMCONTROLS], oper8_use[NUMCONTROLS];
double control_gradient_tolerance[NUMCONTROLS];
/* done */

double *record;
double **data, **wdata;
double *cov;
double *sigma, *inverse_sigma;

char *control_filename[NUMCONTROLS] = {
  "control", "control.big", "control.jack", "control.boot"
};

int degrees_of_freedom, ilambda, itheta, ibeta, ipsi, ipsi_diag, psizeros;
int start_fcov, end_fcov, start_psi, end_psi, fcov_vars;
double *initial_values;
short int starting_values, use_boundary;

char *parmsyms[4] = { "LY", "TE", "B", "PSI" };
int *whereXrow, *whereXcol, *fixXrow, *fixXcol;
int *whereXtype, *fixXtype;
int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
int *whereXtype_array[MAXBOUNDHITS+1];
int *varmap, *varmap_array[MAXBOUNDHITS+1];
int first_set_structures = 1;
int equality_constraints;
int *equal_lambda_row, *equal_lambda_col, *equal_beta_row, *equal_beta_col,
  *equal_psi_row, *equal_psi_col, *equal_theta_row, *equal_theta_col;

double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
int observedy, latenty, runvars, runcases, runboots;
int rungroups, *runcasesv, *observedyv;
int runvars_array[MAXBOUNDHITS+1];
int run_nochange_lim, run_notdone_lim;
int runfixvars;
int bhitlimit;
double bhitthreshold;

char modelfilename[MAXPATH];
char **fullsamplename;
char **weightname;
char recordfilename[MAXPATH];
char readrecordfilename[MAXPATH];
char bootdatafilename[MAXPATH];
char listfile[MAXPATH];
short int readrecordtrigger;
short int record_dumptrigger;
short int bootdatatrigger;

