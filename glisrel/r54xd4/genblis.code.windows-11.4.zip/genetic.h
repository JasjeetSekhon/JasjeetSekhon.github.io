/* @(#)genetic.h	1.4   7/23/98 */

void initialize();
void find_final_mat1();
FLAG initialize_x2();
void nrerror();
double *vector();
int *ivector();
double **matrix();
int **imatrix();
void free_vector();
void free_ivector();
void free_matrix();
void free_imatrix();
void print_domains();
void print_population();
void print_vector();
