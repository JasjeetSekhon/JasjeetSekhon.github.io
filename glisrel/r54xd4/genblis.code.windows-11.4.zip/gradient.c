/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/




#include "data.h"
#include "gradient.h"

static char *sccsversion = "@(#)gradient.c	11.4   7/23/98";

void gradient(double *X, double *p)
{
  extern short int runcovflag;
  extern int usecovflag, usecrosspflag, usecorrflag, weightflag;
  extern double *cov;
  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
  extern int observedy, latenty, runvars, runcases;
  extern int rungroups, *observedyv;

  extern int equality_constraints;
  extern int *equal_lambda_row, *equal_lambda_col, *equal_beta_row, *equal_beta_col,
    *equal_psi_row, *equal_psi_col, *equal_theta_row, *equal_theta_col;

  
  /*
     p=oy          m=ly
     q=ox          n=lx
     */
  
  static double fml3;
  
  int drow, dcol, drow2, dcol2;
  
  int der_lambda_yROW, der_phiROW,
  der_psiROW, der_theta_epsilonROW, der_betaROW,
  der_betaCOL;

  int der_lambda_yCOL, der_lambda_xCOL, der_gammaCOL,
  der_phiCOL, der_psiCOL, der_theta_epsilonCOL,
  der_theta_deltaCOL;

  double d, fml, fml1, fml2;
  
  int ink, outrowcol[2], nextinrow, nextincol, sigma1row,
  sigma1col, sigma1arow, sigma1acol, sigma1brow, sigma1bcol;
  
  int sigma2row, sigma2col, sigma3row, sigma3col, sigma4row, sigma4col;
  
  int i,j, idx;
  double doublefml;
  
  /* read stuff */
  int cases;
  char ch;

  int
    size1 = runvars*runcases,
    size2 = observedy*observedy,
    size3 = observedy*latenty,
    size4 = latenty*latenty;

  static int firsttime=0;

  /* new declarations */
  static double *omega, *omega1, *omega2, *omega3, *omega4, *t_omega3
    ,*transpose_lambda_y,
    *trash1, *trash2, *trash3, *trash4, *trash5, *trash6, *trash7,
    *t_neg_A_der, *C_der,
    *der_beta, *der_lambda_y, *der_psi, *der_theta_epsilon,
    *col, *sigma, *sigma1, *sigma1a, *sigma1b, *sigma2, *sigma3, *sigma4, *trash,
    *fmlm2, *inverse_sigma,
    *t_lambda_y, *t_inverse_sub_beta, *sub_beta, *inverse_sub_beta;

  static int *indx;

  /* memory allocation */
  if (firsttime==0) {
    indx = (int *) malloc((size3+1)*sizeof(int));
    col = (double *) malloc((size3+1)*sizeof(double));
    omega = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    omega1 = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    omega2 = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    omega3 = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    omega4 = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    transpose_lambda_y = (double *) malloc(((size3)+(observedy))*sizeof(double));
    trash1 = (double *) malloc((size1)*sizeof(double));
    trash2 = (double *) malloc((size1)*sizeof(double));
    trash3 = (double *) malloc((size1)*sizeof(double));
    trash4 = (double *) malloc((size1)*sizeof(double));
    trash5 = (double *) malloc((size1)*sizeof(double));
    trash6 = (double *) malloc((size1)*sizeof(double));
    trash7 = (double *) malloc((size1)*sizeof(double));
    t_omega3 = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    t_neg_A_der = (double *) malloc(((size4)+(latenty))*sizeof(double));
    C_der = (double *) malloc(((size4)+(latenty))*sizeof(double));
    der_beta = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    der_lambda_y = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    der_psi = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    der_theta_epsilon = (double *) malloc(((size2)+(observedy))*sizeof(double));      
    sigma = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma1 = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma1a = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma1b = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma2 = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma3 = (double *) malloc(((size2)+(observedy))*sizeof(double));
    sigma4 = (double *) malloc(((size2)+(observedy))*sizeof(double));
    trash = (double *) malloc((size1)*sizeof(double));
    fmlm2 = (double *) malloc(((size2)+(observedy))*sizeof(double));
    inverse_sigma = (double *) malloc(((size2)+(observedy))*sizeof(double));
    t_lambda_y = (double *) malloc(((size3)+(observedy))*sizeof(double));
    t_inverse_sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));
    sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));
    inverse_sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));

    for (i=0; i<size2; i++) inverse_sigma[i] = 0.0;

    firsttime = 1;
  }

  if (runcovflag!=9) {
    runcovflag=9;

    if (weightflag==1) {
      if (usecovflag==1) fwcov();
      else if (usecrosspflag==1) fwcrossp();
      else if (usecorrflag==1) fwcorr();
    }
    else {
      if (usecovflag==1) fcov();
      else if (usecrosspflag==1) fcrossp();
      else if (usecorrflag==1) fcorr();
    }

    d = det_by_block(cov,trash,indx,observedy,rungroups,observedyv);
    fml3=log(d);
  } 

  set_structures(X);


  /* THE SIGMA MATRIX PUT TOGETHER STUFF */
  /* to get inverse beta made */
  subtract(identity_beta, beta, sub_beta, latenty, latenty);
  copy(sub_beta,trash,latenty,latenty);
  ludcmp(trash,latenty,indx,&d);
  for (j=0;j<latenty;j++) {
    for(i=0;i<latenty;i++) col[i]=0.0;
    col[j]=1.0;
    lubksb(trash,indx,col,latenty);
    for(i=0;i<latenty;i++) inverse_sub_beta[M(i,j,latenty)]=col[i];
  } 
  /* inverse beta is made! */

  /* THE TRANSPOSES */
  transpose(lambda_y, t_lambda_y, observedy, latenty);
  transpose(inverse_sub_beta,t_inverse_sub_beta,latenty,latenty); 

  /* BUILD SIGMA1 */
  /* build sigma 1a */
  multi(lambda_y,inverse_sub_beta,sigma1a,observedy,latenty,latenty,latenty,outrowcol);
  sigma1arow=outrowcol[0];
  sigma1acol=outrowcol[1];
  /* sigma 1a built */

  /* build sigma 1b */
  /* sigma 1b built */

  multi(sigma1a, psi, trash, sigma1arow, sigma1acol, latenty,
	latenty, outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  multi(trash, t_inverse_sub_beta, trash2, sigma1row, sigma1col, latenty, latenty,
	outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  multi(trash2, t_lambda_y, trash3, sigma1row, sigma1col, latenty, observedy, outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  add(trash3, theta_epsilon, sigma, observedy, observedy);
  /* SIGMA 1 IS DONE */
  
  /* DO THE FML THING */
  /* inverse sigma */
  invert_by_block(sigma,inverse_sigma,trash,indx,col,observedy,rungroups,observedyv);

  /* THE DERIVATIVE PORTION PROPER */
  /* A_der = inverse_beta */

  /* The C_der portion */
  multi(inverse_sub_beta, psi, trash, latenty, latenty, latenty, latenty, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash, t_inverse_sub_beta, trash2, drow, dcol, latenty, latenty, outrowcol);
  /* multiply by 2.0 here, for der_lambda and der_beta */
  drow=outrowcol[0];
  dcol=outrowcol[1];
  scalarmulti(2.0, trash2, C_der, drow, dcol);
  /* C_der done */

  subtract(sigma, cov, omega, observedy, observedy);
  multi(inverse_sigma, omega, trash, observedy, observedy, observedy, observedy,
	outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash, inverse_sigma, omega, observedy, observedy, drow, dcol, outrowcol);

  /* create omega1 */
  for(j=0; j<sigma1row; j++)
    {
      for(i=0; i<sigma1col; i++)
	{
	  omega1[M(j,i,sigma1col)]=omega[M(j,i,observedy)];
	}
    }
  
  /* transposes for the dervs */
  transpose(lambda_y, transpose_lambda_y, observedy, latenty);
  
  /* CREATE der_lambda_y */
  multi(omega1, lambda_y, trash, sigma1row, sigma1col, observedy, latenty, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash, C_der, der_lambda_y, drow, dcol, latenty, latenty, outrowcol);
  der_lambda_yROW=outrowcol[0];
  der_lambda_yCOL=outrowcol[1];
  /* der_lambda_y is DONE */
  
  /* CREATE der_beta */
  multi(t_inverse_sub_beta, transpose_lambda_y, trash1, latenty, latenty, latenty, observedy, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  
  multi(omega1, lambda_y, trash, sigma1row, sigma1col, observedy, latenty, outrowcol);
  drow2=outrowcol[0];
  dcol2=outrowcol[1];
  multi(trash, C_der, trash2, drow2, dcol2, latenty, latenty, outrowcol); 
  
  multi(trash1, trash2, der_beta, drow, dcol, drow2, dcol2, outrowcol);
  der_betaROW=outrowcol[0];
  der_betaCOL=outrowcol[1]; 
  /* der_beta DONE! */

  /* CREATE der_psi */
  multi(t_inverse_sub_beta, transpose_lambda_y, trash, latenty, latenty, latenty, observedy, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash, omega1, trash2, drow, dcol, sigma1row, sigma1col, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash2, lambda_y, trash3, drow, dcol, observedy, latenty, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  multi(trash3, inverse_sub_beta, trash2, drow, dcol, latenty, latenty, outrowcol);
  drow=outrowcol[0];
  dcol=outrowcol[1];
  /* multiply off-diagonal by 2.0 to adjust for symmetry */
  scalarmultioffdiag(2.0, trash2, der_psi, drow, dcol);
  der_psiROW=outrowcol[0];
  der_psiCOL=outrowcol[1];
  /* der_psi DONE */

  /* CREATE der_theta_epsilon */
  /* multiply off-diagonal by 2.0 to adjust for symmetry */
  scalarmultioffdiag(2.0, omega1, der_theta_epsilon, sigma1row, sigma1col);
  der_theta_epsilonROW=sigma1row;
  der_theta_epsilonCOL=sigma1col;
  /* der_theta_epsilon DONE */


  if (equality_constraints > 0) {
    for (i=0; i<observedy; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_lambda_row[i] != (MAXPARMS+1) && equal_lambda_col[j] != (MAXPARMS+1)) {
	  der_lambda_y[M(equal_lambda_row[i],equal_lambda_col[j],latenty)] = 
	    der_lambda_y[M(equal_lambda_row[i],equal_lambda_col[j],latenty)] + 
	      der_lambda_y[M(i,j,latenty)];
	}
      }
      for (j=0; j<observedy; j++) {
	if (equal_theta_row[i] != (MAXPARMS+1) && equal_theta_col[j] != (MAXPARMS+1)) {
	  der_theta_epsilon[M(equal_theta_row[i],equal_theta_col[j],observedy)] = 
	    der_theta_epsilon[M(equal_theta_row[i],equal_theta_col[j],observedy)] + 
	      der_theta_epsilon[M(i,j,observedy)];
	}
      }
    }
    for (i=0; i<latenty; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_beta_row[i] != (MAXPARMS+1) && equal_beta_col[j] != (MAXPARMS+1)) {
	  der_beta[M(equal_beta_row[i],equal_beta_col[j],latenty)] = 
	    der_beta[M(equal_beta_row[i],equal_beta_col[j],latenty)] + 
	      der_beta[M(i,j,latenty)];
	}
	if (equal_psi_row[i] != (MAXPARMS+1) && equal_psi_col[j] != (MAXPARMS+1)) {
	  der_psi[M(equal_psi_row[i],equal_psi_col[j],latenty)] = 
	    der_psi[M(equal_psi_row[i],equal_psi_col[j],latenty)] + 
	      der_psi[M(i,j,latenty)];
	}
      }
    }
  }


  set_der(p, der_lambda_y, der_theta_epsilon, der_beta, der_psi);

} /* function end */



void set_der(double *pp, double *der_lambda_y, 
	     double *der_theta_epsilon,
	     double *der_beta,
	     double *der_psi)
{
  extern int *whereXrow, *whereXcol, *whereXtype;
  extern int observedy, latenty, runvars;

  int i;

  for (i=0; i<runvars; i++)
    switch (whereXtype[i]) {
    case LAMBDAY:
      pp[i]=der_lambda_y[M(whereXrow[i], whereXcol[i],latenty)];
      break;
    case THETAEPS:
      pp[i]=der_theta_epsilon[M(whereXrow[i], whereXcol[i],observedy)];
      break;
    case BETA:
      pp[i]=der_beta[M(whereXrow[i], whereXcol[i],latenty)];
      break;
    case PSI:
      pp[i]=der_psi[M(whereXrow[i], whereXcol[i],latenty)];
      break;
    default:
      break;
    }

}

