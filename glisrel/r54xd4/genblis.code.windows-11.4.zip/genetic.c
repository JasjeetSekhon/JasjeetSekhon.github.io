/* 

   Much of the code in this file was adapted from an early version of
   GENOCOP I (Zbigniew Michalewicz, zbyszek@uncc.edu).  For information
   about GENOCOP III please see
   http://www.coe.uncc.edu/~gnazhiya/gchome.html.

*/


static char *sccsversion = "@(#)genetic.c	11.4   7/23/98";

#include "data.h"
#include "genoud.h"
#include "genetic.h"


/* of: change_order.c */

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   initialize()                                 */
/*                                                                              */
/*           SYNOPSIS          :   void initialize(mat,rc)                      */
/*                                                                              */
/*           DESCRIPTION       :   This function initializes all the components */
/*                                  of the given matrix to zero                 */
/*                                                                              */
/********************************************************************************/

void initialize(mat,rc)
MATRIX mat;
INDEX rc;
{
  int i,j;

  for(i=1; i<=rc.r; i++)
    for(j=1; j<=rc.c; j++)
      mat[i][j] = 0.0;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_final_mat1()                            */
/*                                                                              */
/*           SYNOPSIS          :   void find_final_mat1(x2,l2,u2,finmat,row,col)*/
/*                                                                              */
/*           DESCRIPTION       :   This function copies the remaining original  */
/*                                  domain constraints on to the final matrix   */
/*                                  to be output                                */
/*                                                                              */
/********************************************************************************/

void find_final_mat1(l2,u2,finmat,row,col)
MATRIX finmat;
VECTOR l2,u2;
int row,col;
{
  int i,j=2;

  for(i=1; i<=row; i++)
    {
      finmat[i][1] = l2[i];
      finmat[i][col] = u2[i];
      finmat[i][j++] = 1.0;
    }
}



/* of: frange_ran.c */
/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   initialize_x2()                              */
/*                                                                              */
/*           SYNOPSIS          :   FLAG initialize_x2(final,rc,x1,x2,x1_vari,   */
/*                                                                      x2_vari)*/
/*                                                                              */
/*           DESCRIPTION       :   This function generates random values for    */
/*                                  each of the x2 variables, in such a way that*/
/*                                  none of the constriants are violated; if no */
/*                                  such values could be found after a          */
/*                                  predetermined number of times, it returns   */
/*                                  FALSE.                                      */
/*                                                                              */
/********************************************************************************/


FLAG initialize_x2(final,rc,x1,x2,x1_vari,X,a1_b)
MATRIX final;        /*The final matrix*/
VECTOR X,a1_b;       /*Vector to hold the values of all the variables to be generated*/
IVECTOR x1,x2;       /*The p-variables eliminated and the remaining variables*/
INDEX rc;            /*Row and column of the final matrix*/
int x1_vari;         /*Number of variables eliminated*/
{
  int i,j,jasj, jasi,           /*counter variables*/
      x2_vari=rc.c-2,/*Total number of existing variables*/
      try=0;         /*Number of tries before getting a value for a variable*/
  FLAG _LOW,         /*Flags to check if the lower bounds are satisfied*/
       _HIGH;        /*Flags to check if the pper bounds are satisfied*/
  VECTOR temp;       /*Temporary vector to hold the random values of the variables*/
  MATRIX trymat;     /*Total after substitution of the generated variable value*/
  double llim,ulim,
        sum = 0;
  FLAG _CHECK = FALSE;


  temp = vector(1,x2_vari);
  trymat = matrix(1,rc.r-x2_vari,0,x2_vari);


  do
    {
      if(try < TRIES)
        /*Increment the number of tries*/
        ++try;
      for(i=1; i<=x2_vari; i++)
        /*For each constraints, generate a value for a variable between the bounds*/
        temp[i] = frange_ran(final[i][1],final[i][rc.c]);

      if(x2_vari != rc.r)
        {
          for(j=x2_vari+1; j<=rc.r; j++)
            {
              sum = 0;
              for(i=1; i<=x2_vari; i++)
                /*Evaluate the equation after a value is generated for a variable*/
                sum  =  sum + temp[i] * final[j][i+1];

              /*Check if the lower and upper bounds are satisfied*/
              _LOW = (sum >= final[j][1]) ? TRUE : FALSE;
              _HIGH = (sum <= final[j][rc.c]) ? TRUE : FALSE;

              if((!_LOW)||(!_HIGH))
                break;
            }
        }
      else
        _LOW = _HIGH = TRUE;
    }while((try<TRIES) && ((!_LOW)||(!_HIGH)));
  if(try >= TRIES)
    {
      fprintf(output,"Please input initial values\n",x1_vari+x2_vari);
      for(i=1; i<=x1_vari+x2_vari; i++)
        {
          fprintf(output,"\nX%d\t",i);
          scanf("%lf",&X[i]);
        }

      for(j=1; j<=rc.r; j++)
        {
          sum = 0;
          for(i=1; i<=x2_vari; i++)
            /*Evaluate the equation after a value is generated for a variable*/
            sum  =  sum + X[x2[i]] * final[j][i+1];

          /*Check if the lower and upper bounds are satisfied*/
          _LOW = (sum >= final[j][1]) ? TRUE : FALSE;
          _HIGH = (sum <= final[j][rc.c]) ? TRUE : FALSE;

          if((!_LOW)||(!_HIGH))
            {
              fprintf(output,"The input values do not satisfy the constraints\n%d\n",j);
	      fprintf(stderr,"The input values do not satisfy the constraints\n%d\n",j);
              exit(1);
            }
          else
            _CHECK = TRUE;
        }
    }
  else
    {
      _CHECK = TRUE;
      if(x1_vari != 0)
        {
          for(i=1; i<=x2_vari; i++)
            X[x2[i]] = temp[i];

          for(j=1; j<=x1_vari; j++)
            {
              X[x1[j]] = a1_b[j];
              for(i=1; i<=x2_vari; i++)
                X[x1[j]] = X[x1[j]] + temp[i] * final[j+x2_vari][i+1];
            }
        }
      else
        for(i=1; i<=x2_vari; i++)
            X[i] = temp[i];
    }

  free_vector(temp,1);
  free_matrix(trymat,1,rc.r-x2_vari,0);
  return(_CHECK);
}



/* of: numerics.c */
/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   nrerror()                                    */
/*                                                                              */
/*           SYNOPSIS          :   void nrerror(error_text)                     */
/*                                                                              */
/*           DESCRIPTION       :   This function gives out an error message on  */
/*                                  to the standard output.                     */
/*                                                                              */
/********************************************************************************/



void nrerror(error_text)
char error_text[];
{
        fprintf(output,"Numerical Recipes run-time error...\n");
        fprintf(output,"%s\n",error_text);
        fprintf(output,"...now exiting to system...\n");
        exit(1);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vector()                                     */
/*                                                                              */
/*           SYNOPSIS          :   double *vector(nl,nh)                         */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a single dimensional   */
/*                                  double array after allocating memory from    */
/*                                  indices nl to nh                            */
/*                                                                              */
/********************************************************************************/



VECTOR vector(nl,nh)
int nl,nh;
{
        VECTOR v;

        if (nh <  nl)
          return(NULL);

        v=(double *)malloc((unsigned) (nh-nl+1)*sizeof(double));
        if (!v) nrerror("allocation failure in vector()");
        return v-nl;
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   ivector()                                    */
/*                                                                              */
/*           SYNOPSIS          :   int *vector(nl,nh)                           */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a single dimensional   */
/*                                  integer array after allocating memory from  */
/*                                  indices nl to nh                            */
/*                                                                              */
/********************************************************************************/

IVECTOR ivector(nl,nh)
int nl,nh;
{
        IVECTOR v;

        if (nh <  nl)
          return(NULL);

        v=(int *)malloc((unsigned) (nh-nl+1)*sizeof(int));
        if (!v) nrerror("allocation failure in ivector()");
        return v-nl;
}



/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   matrix()                                     */
/*                                                                              */
/*           SYNOPSIS          :   double *matrix(nrl,nrh,ncl,nch)               */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a two dimensional      */
/*                                  double array after allocating memory for the */
/*                                  rows from indices nrl to nrh, and for the   */
/*                                  columns from ncl to nch                     */
/*                                                                              */
/********************************************************************************/

MATRIX matrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
        int i;
        MATRIX m;

        if (nrh <  nrl)
          return(NULL);
        if (nch <  ncl)
          return(NULL);

        m=(double **) malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
        if (!m) nrerror("allocation failure 1 in matrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(double *) malloc((unsigned) (nch-ncl+1)*sizeof(double));
                if (!m[i]) nrerror("allocation failure 2 in matrix()");
                m[i] -= ncl;
        }
        return m;
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   imatrix()                                    */
/*                                                                              */
/*           SYNOPSIS          :   int *imatrix(nrl,nrh,ncl,nch)                */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a two dimensional      */
/*                                  integer array after allocating memory for   */
/*                                  the rows from indices nrl to nrh, and for   */
/*                                  the columns from ncl to nch
/*                                                                              */
/********************************************************************************/

IMATRIX imatrix(nrl,nrh,ncl,nch)
int nrl,nrh,ncl,nch;
{
        int i;
        IMATRIX m;

        if (nrh <  nrl)
          return(NULL);
        if (nch <  ncl)
          return(NULL);

        m=(int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));
        if (!m) nrerror("allocation failure 1 in imatrix()");
        m -= nrl;

        for(i=nrl;i<=nrh;i++) {
                m[i]=(int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));
                if (!m[i]) nrerror("allocation failure 2 in imatrix()");
                m[i] -= ncl;
        }
        return m;
}

void free_vector(v,nl)
     double *v;
     int nl;
{
     if (v == NULL)
      return;
     else
      free((double*) (v+nl));
}

void free_ivector(v,nl)
     int *v,nl;
{
     if (v == NULL)
      return;
     else
      free((unsigned int*) (v+nl));
}
void free_matrix(m,nrl,nrh,ncl)
     double **m;
     int nrl,nrh,ncl;
{
     int i;

     if (m == NULL)
      return;
     else
      {
        for(i=nrh;i>=nrl;i--) free((double*) (m[i]+ncl));
          free((double*) (m+nrl));
      }
}
void free_imatrix(m,nrl,nrh,ncl)
     int **m;
     int nrl,nrh,ncl;
{
     int i;

     if (m == NULL)
      return;
     else
      {
        for(i=nrh;i>=nrl;i--) free((unsigned int*) (m[i]+ncl));
          free((unsigned int*) (m+nrl));
      }
}


/* of: print_format.c */
/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   print_domains()                              */
/*                                                                              */
/*           SYNOPSIS          :   void print_domains(equal,t_equ)              */
/*                                                                              */
/*           DESCRIPTION       :   This function prints the matrix passed, on to*/
/*                                  the standard output, in the format of       */
/*                                  domains.                                    */
/*                                                                              */
/********************************************************************************/

void print_domains(equal,t_equ)
MATRIX equal;   /*the domains matrix, with the upper and lower limits*/
int t_equ;       /*the total number of domains*/
{
  int i,j,temp;

  fprintf(output,"\n\nDomains :\n");

  for(i=1; i<=t_equ; i++)
    {
      for(j=1; j<=3; j++)
        {
          if(j == 2)
            fprintf(output,"  <=  X%-2d  <=   ",(int)equal[i][j]);
          else
            fprintf(output," %3.2f ",equal[i][j]);
        }
      fprintf(output,"\n");
    }
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   print_population()                           */
/*                                                                              */
/*           SYNOPSIS          :   void print_population(lr,ur,lc,uc,mat)       */
/*                                                                              */
/*           DESCRIPTION       :   This function prints the initial and final   */
/*                                  population on to the standard output.       */
/*                                                                              */
/********************************************************************************/

void print_population(out,r,c,mat)
FILE *out;
int r,c;
MATRIX mat;
{
  int i,j;

  for(i = 1; i <= r; i++)
    {
      fprintf(out,"%20.8f",mat[i][0]);
      for (j = 1; j <= c-1; j++)
        {
          if (((j-1) % 3 == 0) && ( j != 1))
            fprintf(out,"\n                    ");
          fprintf(out,"%20.8f",mat[i][j]);
        }
      fprintf(out,"\n");
    }
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   print_vector()                               */
/*                                                                              */
/*           SYNOPSIS          :   void print_vector(arr,l,u)                   */
/*                                                                              */
/*           DESCRIPTION       :   This function prints a given double vector,   */
/*                                  on to the standard output                   */
/*                                                                              */
/********************************************************************************/

void print_vector(arr,l,u)
VECTOR arr;
int l,u;
{
  int i;

  for(i=l; i<=u; i++)
    fprintf(output,"%5.2f\t",arr[i]);
}

