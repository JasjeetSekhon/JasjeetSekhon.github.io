/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/


static char *sccsversion = "@(#)unif.c	11.4   7/23/98";

#include <stdio.h>
#include "unif.h"

void ruxorv (integer *iseed, int n, double *rvec, integer *aux)
{
/* the double precision random uniforms in rvec have only 31 random bits
     set *iseed!=0 to reinitialize the sequence, else use *iseed==0
   *iseed always equals 0 on return
   aux points to an integer vector of length > 1279+3
*/
  int i, ibloc, nw;
  static integer wrk[TLPDBSIZ];
  static double fk = 1.0/((double) TLPMOD) ;

  /* if n==0, initialize the TLP seed vector in aux[] and return */
  if (n == 0) {
    /* initialize only if *iseed > 0 */
    if (*iseed != 0) tlpseq (iseed, 0, wrk, aux);
  } else {
    nw = n;
    ibloc = 0;
    while (nw > TLPDBSIZ) {
      tlpseq (iseed, TLPDBSIZ, wrk, aux);
      if (ibloc > 0) {
	for (i=0; i<TLPDBSIZ; i++) rvec[ibloc+i] = wrk[i] * fk ;
      } else {
	for (i=0; i<TLPDBSIZ; i++) rvec[i] = wrk[i] * fk ;
      }
      nw -= TLPDBSIZ;
      ibloc += TLPDBSIZ;
    } ;
    if (nw > 0) {
      tlpseq (iseed, nw, wrk, aux);
      if (ibloc > 0) {
	for (i=0; i<nw; i++) rvec[ibloc+i] = wrk[i] * fk;
      } else {
	for (i=0; i<nw; i++) rvec[i] = wrk[i] * fk;
      }
    }
  }
}

/* Tausworthe-Lewis-Payne generator,
    for primitive trinomial with k=K, q=Q.  Here K=1279, Q=216.
   see Bratley, Fox and Schrage (1983, 190) and Bright and Enison (1979)
*/
void tlpseq (integer *iseed, int n, integer *rvec, integer *aux)
{
  static integer k = 1279, q = 216, k0 = 89, q0 = 38,
    seed = (integer) 524287 ;
  static integer aux0[89+3];
  int i;
  integer seedw;

  /* aux is a vector of length > k+3 */
  /* initialize aux if nonzero *iseed is supplied or
     if aux[k+2] is not set to the magic value */
  if (*iseed != ZEROI || aux[k+2] != k) {
    if (*iseed < ZEROI) *iseed = -(*iseed);
    seedw = (*iseed != seed) ? (*iseed ^ seed) : seed ;
    *iseed = ZEROI;
    for (i=0; i<k0; i++) {
      tauint (&seedw) ;
      aux0[i] = seedw;
    }
    aux0[k0] = k0 - 1;
    aux0[k0+1] = aux0[k0] - q0;
    aux0[k0+2] = k0;
    /* initialize the k=K, q=Q generator using the k=89, q=38 generator */
    tlpcor (k0, k, aux, aux0);
    /* store initial recurrence location indexes and the magic value in aux */
    aux[k] = k - 1;
    aux[k+1] = aux[k] - q;
    aux[k+2] = k;
  }
  if (n > 0) tlpcor (k, n, rvec, aux);
}

/* Tausworthe-Lewis-Payne generator, core recursion.
   assumes aux is valid
   see Bratley, Fox and Schrage (1983, 190) and Bright and Enison (1979)
*/
void tlpcor (integer k, int n, integer *rvec, integer *aux)
{
  /* aux is a vector of length k+2 */
  int ii;
  integer i, j, inew;

  /* get the recursion location indexes out of AUX */
  i = aux[k];
  j = aux[k+1];
  for (ii=0; ii<n; ii++) {
    inew = aux[j] ^ aux[i] ;
    aux[i] = inew;
    rvec[ii] = inew;
    j = j==0 ? k-1 : j - 1;
    i = i==0 ? k-1 : i - 1;    
  }
  /* store the recursion location indexes in aux */
  aux[k] = i;
  aux[k+1] = j;
}

void tauint (integer *ix)
{
/* Tausworthe generator (integer part)
   requires full-word logical operations, 32-bit words, and
     two's complement arithmetic
   from Bratley, Fox and Schrage (1983, 203)
   a recommended initial value for IX is 524287
*/
  integer i, j;

  i = *ix;
  /* do the right shift */
  j = i/8192;
  /* exclusive-or */
  j ^= i;
  /* lower-order bits are done.  now do the rest */
  i = j;
  /* do the left shift */
  j <<= 18;
  /* exclusive-or, handling cases where the left shift makes j negative */
  *ix = j<0 ? i^(-j) : i^j ;
}


/* replacements for random number functions used in genoud's frange_ran() */

double newunif(void)
{
  extern integer genoudseed;
  static integer aux[TLPAUXSIZE], iseed = (integer) -1;
  double wrkout;
  double wrk;

  if (iseed == (integer) -1) iseed = NEWUNIFSEED+genoudseed;

  /* get a random uniform double on (0,1] */
  ruxorv (&iseed, 1, &wrk, aux);
  wrkout = (double) wrk;
  return(wrkout);
}

unsigned int randint (void)
{
  extern integer genoudseed;
  static integer aux[TLPAUXSIZE], iseed = (integer) -1;
  integer wrk;
  int num;

  if (iseed == (integer) -1) iseed = RANDINTSEED+genoudseed;

  /* get a signed 32-bit number from the TLP generator */
  tlpseq (&iseed, 1, &wrk, aux);
  /* truncate to 16 bits */
  num = wrk%65535;
  return (num);
}

unsigned int newrand (void)
{
  return (randint());
}




