/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include <time.h>
#include <string.h>

#include "data.h"
#include "genoud.h"
#include "genetic.h"
#include "unif.h"
#include "inverse.h"
#include "init.h"

static char *sccsversion = "@(#)init.c	11.4   7/23/98";

integer genoudseed = (integer) 0 ;
integer bootseed = (integer) 707070 ;

void readsample(char **fullsamplename, double **fullsampledata, int ngroups,
		int *numobsv, int *novarsv)
{
  int i, j, k, n;
  FILE *fp, *fout;

  n=0;
  for (k=0; k<ngroups; k++) {
    if((fp = fopen(fullsamplename[k], "r")) == NULL) {
      fprintf(output,"cannot open file:  %s\n", fullsamplename[k]);
      fprintf(stderr,"cannot open file:  %s\n", fullsamplename[k]);
      exit(1);
    }
    for (i=0;i<=novarsv[k]*numobsv[k];i++) {
      fscanf(fp,"%lf", fullsampledata[k]+i);
      n++;
    }
    fclose(fp);
  }

#ifdef NEVERDEFINED
  /* test the read in of the sample data */
  if((fout = fopen("fullsample.out", "w")) == NULL) {
    fprintf(output,"cannot open fullsample.out file\n");
    fprintf(stderr,"cannot open fullsample.out file\n");
    exit(1);
  }  

  for (j=0; j<numobs; j+=6) { 
    fprintf(fout, "%10.5lf%10.5lf%10.5lf%10.5lf%10.5lf%10.5lf\n",
	    fullsampledata[j],
	    fullsampledata[j+1], fullsampledata[j+2], fullsampledata[j+3],
	    fullsampledata[j+4], fullsampledata[j+5]); 
  }

  fclose(fout);
#endif
}

void readweights(char **weightname, double **weightdata, int ngroups, int *numobsv)
{
  int i, j, k, n;
  FILE *fp, *fout;

  n=0;
  for (k=0; k<ngroups; k++) {
    if((fp = fopen(weightname[k], "r")) == NULL) {
      fprintf(output,"cannot open file:  %s\n", weightname[k]);
      fprintf(stderr,"cannot open file:  %s\n", weightname[k]);
      exit(1);
    }
    for (i=0;i<=numobsv[k];i++) {
      fscanf(fp,"%lf", weightdata[k]+i);
      n++;
    }
    fclose(fp);
  }
}

void readbootd(unsigned short int *bootdata, int numobs, int nboots)
{
  int end, i;
  FILE *fbootd;

#if WINDOWS_SYS
  extern char redirect_stdout[MAXPATH];
  extern short int redirect_trigger;
#endif

  fprintf(output,"Reading bootd.data\n");
  fflush(output);

#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif

  if((fbootd = fopen("bootd.data", "r")) == NULL) {
    fprintf(output,"cannot open bootd.data file\n");
    fprintf(stderr,"cannot open bootd.data file\n");
    exit(1);
  }

  end=numobs*nboots;
  for (i=0;i<end;i++) {
    fscanf(fbootd,"%u", &bootdata[i]);
  }

  fclose(fbootd);

  fprintf(output,"Finished reading bootd.data\n");
  fflush(output);

#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif

}

void createbootd(unsigned short int **bootdata, int *numobsv, int ngroups,
		 int nboots)
{
  extern integer bootseed;

  static integer aux[TLPAUXSIZE], iseed = (integer) -1;
  double wrk;

  int end, idx, j, k;
  long int i;
  FILE *fbootd;

  if (iseed == (integer) -1) iseed = RANDINTSEED+bootseed;

  /* resample separately for each group, stacking the indices in order in bootdata */

  for (k=0; k<ngroups; k++) {
    for (i=0;i<numobsv[k]*nboots;i++) {
      /* get a random uniform double on (0,1] */
      ruxorv (&iseed, 1, &wrk, aux);
      /* transform it into an integer on [0,numobsv[k]-1] */
      bootdata[k][i] = (short int) (ceil(wrk * numobsv[k]) - 1.0);
    }
  }
}

void samplestats(double **obsdata, int ngroups, int *numobsv, int *novarsv,
		 int weightflag, double **weightdata)
{
  static mflag = 0;
  static double *mean, *var, *skew, *kur;
  static double *rmu, *rvar, *rskew, *rkur;

  int i, j, k, maxnovars, nobs, nvars, nbase=0;
  double sum[4], x1, x2, wsum, iwsum;
  double dinobs;

  if (mflag == 0) {
    for (maxnovars=0, k=0; k<ngroups; k++) {
      if (novarsv[k]>maxnovars) maxnovars = novarsv[k];
    }

    mean = (double *) malloc((size_t) maxnovars*sizeof(double));
    var = (double *) malloc((size_t) maxnovars*sizeof(double));
    skew = (double *) malloc((size_t) maxnovars*sizeof(double));
    kur = (double *) malloc((size_t) maxnovars*sizeof(double));

    rmu = (double *) malloc((size_t) maxnovars*sizeof(double));
    rvar = (double *) malloc((size_t) maxnovars*sizeof(double));
    rskew = (double *) malloc((size_t) maxnovars*sizeof(double));
    rkur = (double *) malloc((size_t) maxnovars*sizeof(double));

    mflag = 1;
  }

  for (k=0; k<ngroups; k++) {
    fprintf(output,"Group %d:\n", k+1);

    nbase += (k==0 ? 0 : numobsv[k-1]*novarsv[k-1]);
    
    nobs = numobsv[k];
    nvars = novarsv[k];
    dinobs = 1.0 / nobs;

    if (weightflag==0) {
      for (j=0; j<nvars; j++) {
	sum[0] = 0.0;
	for (i=0; i<nobs; i++) {
	  sum[0] += obsdata[k][M(i,j,nvars)];
	}
	sum[0] *= dinobs;
	sum[1] = 0.0; sum[2] = 0.0; sum[3] = 0.0;
	for (i=0; i<nobs; i++) {
	  x1 = obsdata[k][M(i,j,nvars)] - sum[0];
	  x2 = x1*x1;
	  sum[1] += x2;
	  x2 *= x1;
	  sum[2] += x2;
	  x2 *= x1;
	  sum[3] += x2;
	}
	rmu[j] = sum[0];
	rvar[j] = sum[1] * dinobs;
	rskew[j] = sum[2] * dinobs;
	rkur[j] = sum[3] * dinobs;
      }

      for (j=0; j<nvars; j++) {
	mean[j] = rmu[j];
	x1 = rvar[j] ;
	var[j] = x1;
	x2 = 1.0 / (x1*x1) ;
	kur[j] = rkur[j] * x2;
	skew[j] = rskew[j] * sqrt(x2/x1);

	fprintf(output,"var %d:\n", j+1);
	fprintf(output,"sample mean = %f\n", mean[j]);
	fprintf(output,"sample var = %f\n", var[j]);
	fprintf(output,"sample skewness = %f\n", skew[j]);
	fprintf(output,"sample kurtosis = %f\n", kur[j]);
      }
    }
    else if (weightflag==1) {
      for (wsum = 0.0, i=0; i<nobs; i++) wsum += wdata[k][i];
      iwsum = 1.0/wsum;

      for (j=0; j<nvars; j++) {
	sum[0] = 0.0;
	for (i=0; i<nobs; i++) {
	  sum[0] += obsdata[k][M(i,j,nvars)] * wdata[k][i];
	}
	sum[0] *= iwsum;
	sum[1] = 0.0; sum[2] = 0.0; sum[3] = 0.0;
	for (i=0; i<nobs; i++) {
	  x1 = obsdata[k][M(i,j,nvars)] - sum[0];
	  x2 = x1*x1;
	  sum[1] += x2 * wdata[k][i];
	  x2 *= x1;
	  sum[2] += x2 * wdata[k][i];
	  x2 *= x1;
	  sum[3] += x2 * wdata[k][i];
	}
	rmu[j] = sum[0];
	rvar[j] = sum[1] * iwsum;
	rskew[j] = sum[2] * iwsum;
	rkur[j] = sum[3] * iwsum;
      }

      for (j=0; j<nvars; j++) {
	mean[j] = rmu[j];
	x1 = rvar[j] ;
	var[j] = x1;
	x2 = 1.0 / (x1*x1) ;
	kur[j] = rkur[j] * x2;
	skew[j] = rskew[j] * sqrt(x2/x1);

	fprintf(output,"var %d:\n", j+1);
	fprintf(output,"sample mean = %f\n", mean[j]);
	fprintf(output,"sample var = %f\n", var[j]);
	fprintf(output,"sample skewness = %f\n", skew[j]);
	fprintf(output,"sample kurtosis = %f\n", kur[j]);
      }
    }
  }

  /* free data and work storage */
  /*
  free(rkur);
  free(rskew);
  free(rvar);
  free(rmu);
  free(kur);
  free(skew);
  free(var);
  free(mean);
  */
}

void record_dump(double *record, int nparms, char *fname, long int number)
{
  int j;
  
  FILE *out_record;
  
  out_record = fopen(fname,"a+");
  if (out_record == NULL) 
    {
      fprintf(output,"open failed, file %s\n", fname);
      fprintf(stderr,"open failed, file %s\n", fname);
      exit(1);
    }

  for (j=0; j<nparms+OFFSET; j++) 
    {
      fprintf(out_record, "%23.16e ", record[M(number,j,nparms+OFFSET)]);
    }
  fprintf(out_record,"\n");
  fclose(out_record);

} /* end of record_dump */

void setup_record(int nparms, int ncases, int nboots)
{
  extern char readrecordfilename[MAXPATH];
  extern char recordfilename[MAXPATH];  
  extern short int readrecordtrigger;
  extern short int record_dumptrigger;

#if WINDOWS_SYS
  extern char redirect_stdout[MAXPATH];
  extern short int redirect_trigger;
#endif

  double tmp, *row_tmp;
  int i,j, row;


  FILE *read_record;
  /* FILE *out_record; */

  for(i=0; i<ncases+nboots+1; i++) {
    record[M(i,nparms+4, nparms+OFFSET)] =0.0;
  }

  if (readrecordtrigger==1)
    {
      read_record = fopen(readrecordfilename, "r");
      if (read_record == NULL) 
	{
	  fprintf(output,"open failed, file %s\n", readrecordfilename);
	  fprintf(stderr,"open failed, file %s\n", readrecordfilename);
	  exit(1);
	}  
      
      fprintf(output,"reading %s\n", readrecordfilename);
      fflush(output);
#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif
      row_tmp = (double *) malloc((nparms+OFFSET)*sizeof(double));
      
      j=0;
      while (fscanf(read_record, "%lf", &tmp) == 1) {
	row_tmp[j] = tmp;
	if (j<nparms+OFFSET-1) j++ ;
	else {
	  j = 0;
	  for (i=0; i<nparms+OFFSET;i++) {
	    row = (int) row_tmp[nparms+4];
	    record[M(row, i, nparms+OFFSET)]= row_tmp[i];
	  }
	}
      }
      fclose(read_record);
    } /* close if */

  if (record_dumptrigger==1) {
    fprintf(output,"\nResetting output record file: \"%s\".\n", recordfilename);
    read_record = fopen(recordfilename, "w");
    if (read_record == NULL) 
      {
	fprintf(output,"open failed, file %s\n", recordfilename);
	fprintf(stderr,"open failed, file %s\n", recordfilename);
	exit(1);
      }
    fclose(read_record);
  }
  fflush(output);

#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif

#ifdef NEVERDEFINED
  out_record = fopen(recordfilename,"w");
  if (out_record == NULL) 
    {
      fprintf(output,"open failed, file %s\n", recordfilename);
      fprintf(stderr,"open failed, file %s\n", recordfilename);
      exit(1);
    }

  fprintf(output,"PRINTING OWN RECORD FILE READ TEST!@@!\n");
  for (i=0; i<1+ncases+nboots; i++) 
    {
      for (j=0; j<nparms+OFFSET; j++) 
	{
	  fprintf(out_record, "%23.16e ", record[M(i,j,nparms+OFFSET)]);
	}
      fprintf(out_record,"\n");
    }

  fclose(out_record);

  fprintf(output,"Record File Printed\n");

/*
  fprintf(output,"TEST OF READING OF RECORD FILE!@@!\n");
  for (i=0; i=574; i++) {
    for (j=0; j<nparms+OFFSET; j++) 
      {
	fprintf(output,"%23.16e ", record[M(number,j,nparms+OFFSET)]);
      }
  fprintf(output,"\n");
  }
*/
#endif NEVERDEFINED
}    

void printspecs(int what, int recordlocation)
{
  extern int latenty, runvars, runfixvars;

  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
  extern double *record;

  extern int *whereXrow, *whereXcol, *fixXrow, *fixXcol;
  extern int *whereXtype, *fixXtype;
  extern int ilambda, itheta, ibeta, ipsi;
  extern FILE *flistfile;

  int i, n;
  double loading;

  if (what == 0) {
    fprintf(output,"\nModel Specifications:\n\n");
    fprintf(flistfile,"\nModel Specifications:\n\n");
  }
  else if (what == 1) {
    fprintf(output,"\n\n*********************************************************************************\n\n");
    fprintf(output,"BOOTSTRAP RESULTS\n\n");
    
    fprintf(flistfile,"\n\n*********************************************************************************\n\n");
    fprintf(flistfile,"BOOTSTRAP RESULTS\n\n");
  }
  else if (what == 2) {
    fprintf(output,"\n\n*********************************************************************************\n\n");
    fprintf(output,"NO BOOTSTRAPS DONE\n\n");
    
    fprintf(flistfile,"\n\n*********************************************************************************\n\n");
    fprintf(flistfile,"NO BOOTSTRAPS DONE\n\n");
  }

  if (what==0) {
    fprintf(output,"specified fixed parameters (other fixed parameters = 0.0)\n");
    fprintf(flistfile,"specified fixed parameters (other fixed parameters = 0.0)\n");  
    for (i=0; i<runfixvars; i++) {
      fprintf(output,"%s %d %d = ", parmsyms[fixXtype[i]], fixXrow[i]+1, fixXcol[i]+1);
      fprintf(flistfile,"%s %d %d = ", parmsyms[fixXtype[i]], fixXrow[i]+1, fixXcol[i]+1);
      switch (fixXtype[i]) {
      case LAMBDAY:
	fprintf(output,"%lf\n", lambda_y[M(fixXrow[i],fixXcol[i],latenty)]);
	fprintf(flistfile,"%lf\n", lambda_y[M(fixXrow[i],fixXcol[i],latenty)]);
	break;
      case THETAEPS:
	fprintf(output,"%lf\n", theta_epsilon[M(fixXrow[i],fixXcol[i],observedy)]);
	fprintf(flistfile,"%lf\n", theta_epsilon[M(fixXrow[i],fixXcol[i],observedy)]);
	break;
      case BETA:
	fprintf(output,"%lf\n", beta[M(fixXrow[i],fixXcol[i],latenty)]);
	fprintf(flistfile,"%lf\n", beta[M(fixXrow[i],fixXcol[i],latenty)]);
	break;
      case PSI:
	fprintf(output,"%lf\n", psi[M(fixXrow[i],fixXcol[i],latenty)]);
	fprintf(flistfile,"%lf\n", psi[M(fixXrow[i],fixXcol[i],latenty)]);
	break;
      default:
	fprintf(output,"\n");
	fprintf(flistfile,"\n");
	break;
      }
    }
  }

  if (what == 0) {
    fprintf(output,"The number of free parameters (to be estimated):\n");
    fprintf(output,"Lambda: %d\n", ilambda);
    fprintf(output,"Theta Epsilon: %d\n", itheta);
    fprintf(output,"Beta: %d\n", ibeta);
    fprintf(output,"Psi: %d\n\n", ipsi);
    fprintf(output,"Matrix elements to be estimated:\n");
    fprintf(flistfile,"The number of free parameters (to be estimated):\n");
    fprintf(flistfile,"Lambda: %d\n", ilambda);
    fprintf(flistfile,"Theta Epsilon: %d\n", itheta);
    fprintf(flistfile,"Beta: %d\n", ibeta);
    fprintf(flistfile,"Psi: %d\n\n", ipsi);
    fprintf(flistfile,"Matrix elements to be estimated:\n");    
    n=1;
    for (i=0; i<runvars; i++) {
      fprintf(output,"%2d) %4s %2d %2d\n", n, parmsyms[whereXtype[i]],
	     whereXrow[i]+1, whereXcol[i]+1);
      fprintf(flistfile,"%2d) %4s %2d %2d\n", n, parmsyms[whereXtype[i]],
	     whereXrow[i]+1, whereXcol[i]+1);
      n++;
    }
  }
  /*
  else {
    fprintf(output,"MLE:  N = %d, fit = %23.16e\n",
	    runcases, record[M(0,0,runvars+OFFSET)]);
    fprintf(flistfile,"MLE:  N = %d, fit = %23.16e\n",
	    runcases, record[M(0,0,runvars+OFFSET)]);
    for (i=0; i<runvars; i++) {
      fprintf(output,"%2d) %4s %2d %2d = %16.10e\n", i+1, parmsyms[whereXtype[i]],
	      whereXrow[i]+1, whereXcol[i]+1, record[M(recordlocation,i+1,
						       runvars+OFFSET)]);
      fprintf(flistfile,"%2d) %4s %2d %2d = %16.10e\n", i+1, parmsyms[whereXtype[i]],
	      whereXrow[i]+1, whereXcol[i]+1, record[M(recordlocation,i+1,
						       runvars+OFFSET)]);
    }
  }
  */
  fprintf(output,"\n");
  fprintf(flistfile,"\n");  
} /* end printspecs */

void definemodel()
{
  extern int
    observedy, latenty, runvars, runcases, runboots,
    run_nochange_lim, run_notdone_lim;
  extern int rungroups, *runcasesv, *observedyv;
  extern int *caseuse;
  extern int runvars_array[MAXBOUNDHITS+1];

  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
  extern double *initial_values;

  extern int *whereXrow, *whereXcol, *fixXrow, *fixXcol;
  extern int *whereXtype, *fixXtype;
  extern int first_set_structures;

  extern char modelfilename[MAXPATH];
  extern char **fullsamplename;
  extern char recordfilename[MAXPATH];
  extern char readrecordfilename[MAXPATH];
  extern char bootdatafilename[MAXPATH];
  extern char listfile[MAXPATH];
  extern short int readrecordtrigger;
  extern short int bootdatatrigger;
  extern short int record_dumptrigger;

  extern int population_size[NUMCONTROLS], 
    oper1_use[NUMCONTROLS], oper2_use[NUMCONTROLS], oper3_use[NUMCONTROLS], 
    oper4_use[NUMCONTROLS], oper5_use[NUMCONTROLS], oper6_use[NUMCONTROLS], 
    oper7_use[NUMCONTROLS], oper8_use[NUMCONTROLS];
  extern double control_gradient_tolerance[NUMCONTROLS];

  extern struct gspecobjs gosvec[NUMOFMODELS];

  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap_array[MAXBOUNDHITS+1];
  extern FILE *flistfile;

  struct gspecobjs *gosp, *gospB;

  int i,j,k,ii,i0, oybase;
  int pcode1, pcode2, counter;
  int intparm;
  long int longparm;
  double doubleparm;
  double loading, initial;
  int boundsflag;
  short int control_t[NUMCONTROLS];

  extern short int sharting_values, use_boundary, jacks, doboots, dobig,
    bootstrapdetails, covmatrix;
  extern double *initial_values;

  char parmident[MAXPATH], **fullsampledummy;
  FILE *fmodel;

  /* read the model specification file */
  if((fmodel = fopen(modelfilename, "r")) == NULL) {
    fprintf(output,"cannot open model specification file: %s\n", modelfilename);
    fprintf(stderr,"cannot open model specification file: %s\n", modelfilename);
    exit(1);
  }
  /* set some defaults */
  run_nochange_lim = 5;  /* number of generations with no change to be converged */
  run_notdone_lim = 100;  /* absolute maximum number of generations */
  runboots = 1000;  /* number of bootstrap resamples */

  /* set a value to check below that a datafile was specified */
  fullsamplename = fullsampledummy;

  strcpy(recordfilename, " ");
  strcpy(bootdatafilename, " ");
  strcpy(listfile, modelfilename);
  strcat(listfile,".lst");

  rungroups=1;  /* use one group by default */
  usecovflag=1;  usecrosspflag=0;  usecorrflag=0;  /* use covariance matrix */
  weightflag = 0;  /* no observation weights */
  observedyv = (int *) malloc(rungroups*sizeof(int));
  runcasesv = (int *) malloc(rungroups*sizeof(int));
  caseuse = (int *) malloc(rungroups*sizeof(int));
  starting_values=0; /* no starting values */
  use_boundary=0; /* do not use out of bounds stuff */
  jacks=1; /* yes, do jacks */
  doboots=1; /* yes, do bootstraps */
  dobig=1; /* yes, use the big control */
  covmatrix=0; /* do not print asymptotic covariance matrix */
  bootstrapdetails=0; /* no bootstrap details by default */
  readrecordtrigger=0; /* no recordfile to read */
  bootdatatrigger=0;  /* don't print the bootdata vector */
  record_dumptrigger=0; /* don't print a record file */
  bhitthreshold=1.0e-9;  /* threshold for THETAEPS diags to be on boundary */

  while (fscanf(fmodel, "%s", parmident) > 0) {
    if (strcmp(parmident,"genconverge")==0) {
      fscanf(fmodel, " %d", &intparm);
      run_nochange_lim = intparm;
    }
    /* The following "else if" statement allows for comments */
    else if (memcmp(parmident,"#",1)==0) {
      fgets(parmident, MAXPATH, fmodel);
    }
    /*
      else if (memcmp(parmident,"/",1)==0) {
      i=1; 
      while (i>0) {
      fgets(parmident, 2, fmodel);
      if (strcmp(parmident,"/")==0) {
      i=0;
      }
      }
      }
    */
    else if (strcmp(parmident,"genoudseed")==0) {
      fscanf(fmodel, " %ld", &longparm);
      genoudseed = (integer) longparm;
    }

    else if (strcmp(parmident,"usecov")==0) {
      usecovflag=1;  usecrosspflag=0;  usecorrflag=0;  /* use covariance matrix */
    }
    else if (strcmp(parmident,"usecrossp")==0) {
      usecovflag=0;  usecrosspflag=1;  usecorrflag=0;  /* use cross-products matrix */
    }
    else if (strcmp(parmident,"usecorr")==0) {
      usecovflag=0;  usecrosspflag=0;  usecorrflag=1;  /* use correlation matrix */
    }
    else if (strcmp(parmident,"use_out_of_bounds")==0) {
      use_boundary=1;
    }
    else if (strcmp(parmident,"bootstrapdetails")==0) {
      bootstrapdetails=1;
    }
    else if (strcmp(parmident,"bootstrap_details")==0) {
      bootstrapdetails=1;
    }
    else if (strcmp(parmident,"nojacks")==0) {
      jacks=0;
    }
    else if (strcmp(parmident,"nobootstraps")==0) {
      doboots=0;
    }
    else if (strcmp(parmident,"covmatrix")==0) {
      covmatrix=1;
    }
    else if (strcmp(parmident,"noboots")==0) {
      doboots=0;
    }
    else if (strcmp(parmident,"nobig")==0) {
      dobig=0;
    }
    else if (strcmp(parmident,"nolarge")==0) {
      dobig=0;
    }
    else if (strcmp(parmident,"ngroups")==0) {
      fscanf(fmodel, " %d", &intparm);
      rungroups = intparm;
      free(caseuse);
      free(runcasesv);
      free(observedyv);
      observedyv = (int *) malloc(rungroups*sizeof(int));
      runcasesv = (int *) malloc(rungroups*sizeof(int));
      caseuse = (int *) malloc(rungroups*sizeof(int));
    }
    else if (strcmp(parmident,"datafile")==0) {
      fullsamplename = (char **) malloc(rungroups*sizeof(char *));
      for (k=0; k<rungroups; k++) {
	fullsamplename[k] = (char *) malloc(MAXPATH*sizeof(char));
	fscanf(fmodel, " %s", fullsamplename[k]);
      }
    }
    else if (strcmp(parmident,"weights")==0) {
      weightflag = 1;
      weightname = (char **) malloc(rungroups*sizeof(char *));
      for (k=0; k<rungroups; k++) {
	weightname[k] = (char *) malloc(MAXPATH*sizeof(char));
	fscanf(fmodel, " %s", weightname[k]);
      }
    }
    else if (strcmp(parmident,"recordfile")==0) {
      fscanf(fmodel, " %s", recordfilename);
      record_dumptrigger=1;
    }
    else if (strcmp(parmident,"readrecordfile")==0) {
      fscanf(fmodel, " %s", readrecordfilename);
      readrecordtrigger=1;
    }
    else if (strcmp(parmident, "listfile")==0) {
      fscanf(fmodel, " %s", listfile);
    }
    /* Genadd is no longer used, but it is read in order to provide
       compatability with older modelspec files */
    else if (strcmp(parmident,"genadd")==0) {
      fscanf(fmodel, " %d", &intparm);
    }
    else if (strcmp(parmident,"genmax")==0) {
      fscanf(fmodel, " %d", &intparm);
      run_notdone_lim = intparm;
    }
    else if (strcmp(parmident,"bootstraps")==0) {
      fscanf(fmodel, " %d", &intparm);
      runboots = intparm;
    }
    else if (strcmp(parmident,"bootseed")==0) {
      fscanf(fmodel, " %ld", &longparm);
      bootseed = (integer) longparm;
    }

    else if (strcmp(parmident,"onboundary")==0) {
      fscanf(fmodel, " %lf", &doubleparm);
      bhitthreshold = doubleparm;
    }

    else if (strcmp(parmident,"observedvars")==0) {
      observedy = 0;
      for (k=0; k<rungroups; k++) {
	fscanf(fmodel, " %d", &intparm);
	observedy += observedyv[k] = intparm;
      }
    }
    /* CASES is no longer required.  Now read by countcases() */
    else if (strcmp(parmident,"cases")==0) {
      fscanf(fmodel, " %d", &intparm);
      /*runcases = intparm;*/
    }
    else if (strcmp(parmident,"bootdatafile")==0) {
      fscanf(fmodel, "%s", bootdatafilename);
      bootdatatrigger=1;
    }
    else if (strcmp(parmident,"latentvars")==0) {
      fscanf(fmodel, " %d", &intparm);
      latenty = intparm;
    }
    else if (strcmp(parmident,"model")==0)
      break;
    else {
      fprintf(output,"parmident=%s.\n", parmident);
      fprintf(output,"unknown argument in the general setup portion of the\n");
      fprintf(output,"model specification file: %s\n", modelfilename);
      fprintf(stderr,"parmident=%s.\n", parmident);
      fprintf(stderr,"unknown argument in the general setup portion of the\n");
      fprintf(stderr,"model specification file: %s\n", modelfilename);
      exit(4);
    }
  }

  if (fullsamplename == fullsampledummy) {
    fprintf(output,"No datafile was specified.  Terminating.\n", fullsamplename);
    fprintf(stderr,"No datafile was specified.  Terminating.\n", fullsamplename);
    exit(1);
  }

  runcases=countcases();

  /* Shall we do any bootstraps or Jackknives? Consistency checks */
  if (jacks==0) doboots=0;
  if (dobig==0) doboots=0; 
  if (doboots==0) {
    jacks=0;
    runboots=0;
  }
  if (runboots==0) {
    doboots=0;
    jacks=0;
  }

  if((flistfile = fopen(listfile, "w")) == NULL) {
    fprintf(output,"cannot open file:  %s\n", listfile);
    fprintf(stderr,"cannot open file:  %s\n", listfile);
    exit(1);
  }

  fprintf(output,"Output produced by GENBLIS-1.11.4\n");
  fprintf(output,
	  "Copyright (C) 1998 Walter R. Mebane Jr. and Jasjeet S. Sekhon.\n");
  fprintf(output,
	  "Program distributed under the GNU General Public License. See documentation for details.\n");
  fprintf(output,
	  "Please see http://data.fas.harvard.edu/jsekhon/ for latest binaries and information.\n\n\n");
  fprintf(flistfile,"Output produced by GENBLIS-1.11.4\n");
  fprintf(flistfile,
	  "Copyright (C) 1998 Walter R. Mebane Jr. and Jasjeet S. Sekhon.\n");
  fprintf(flistfile,
	  "Program distributed under the GNU General Public License. See documentation for details.\n");
  fprintf(flistfile,
	  "Please see http://data.fas.harvard.edu/jsekhon/ for latest binaries and information.\n\n\n");


  fprintf(output,"Basic program, data and model parameters:\n");
  fprintf(output,"model specification file = %s\n\n", modelfilename);
  fprintf(flistfile,"Basic program, data and model parameters:\n");
  fprintf(flistfile,"model specification file = %s\n\n", modelfilename);

  fprintf(output,"type of matrix to analyze = ");
  fprintf(flistfile,"type of matrix to analyze = ");
  if (usecovflag==1) {
    fprintf(output,"covariance matrix\n");
    fprintf(flistfile,"covariance matrix\n");
  }
  else if (usecrosspflag==1) {
    fprintf(output,"mean crossproduct matrix\n");
    fprintf(flistfile,"mean crossproduct matrix\n");
  }
  else if (usecorrflag==1) {
    fprintf(output,"correlation matrix\n");
    fprintf(flistfile,"correlation matrix\n");
  }
  for (k=0; k<rungroups; k++) {
    fprintf(output,"input data file (group %d) = %s\n", k+1, fullsamplename[k]);
    fprintf(flistfile,"input data file (group %d) = %s\n", k+1, fullsamplename[k]);
  }
  if (weightflag==1) {
    for (k=0; k<rungroups; k++) {
      fprintf(output,"weight data file (group %d) = %s\n", k+1, weightname[k]);
      fprintf(flistfile,"weight data file (group %d) = %s\n", k+1, weightname[k]);
    }
  }
  if (doboots==1) {
    fprintf(output,"number of bootstrap resamples = %d\n", runboots);
    fprintf(flistfile,"number of bootstrap resamples = %d\n", runboots);
  }
  else {
    fprintf(output,"no bootraps and no jackknives\n");
    fprintf(flistfile,"no bootraps and no jackknives\n");
  }
  if (record_dumptrigger==1) {
    fprintf(output,"output record file = %s\n", recordfilename);
    fprintf(flistfile,"output record file = %s\n", recordfilename);
  }
  else {
    fprintf(output,"no output record file\n");
    fprintf(flistfile,"no output record file\n");
  }
  if (readrecordtrigger==1) {
    fprintf(output,"input record file = %s\n", readrecordfilename);
    fprintf(flistfile,"input record file = %s\n", readrecordfilename);
  }
  else {
    fprintf(output,"no input record file (default)\n");
    fprintf(flistfile,"no input record file (default)\n");
  }
  if (bootdatatrigger==1) {
    fprintf(output,"bootdata file = %s\n", bootdatafilename);
    fprintf(flistfile,"bootdata file = %s\n", bootdatafilename);
  }
  else {
    fprintf(output,"\n");
    fprintf(flistfile,"\n");
  }

  fprintf(output,"number of cases = %d\n", runcases); 
  fprintf(output,"number of observed variables = %d\n", observedy);
  for (oybase=0, k=0; k<rungroups; k++) {
    fprintf(output,"   number in group %d = %d (variables %d to %d)\n",
	    k+1, observedyv[k], oybase+1, oybase+observedyv[k]);
    oybase += observedyv[k];
  }
  fprintf(output,"number of latent variables = %d\n\n", latenty);
  fprintf(flistfile,"number of cases = %d\n", runcases); 
  fprintf(flistfile,"number of observed variables = %d\n", observedy);
  for (oybase=0, k=0; k<rungroups; k++) {
    fprintf(flistfile,"   number in group %d = %d (variables %d to %d)\n",
	    k+1, observedyv[k], oybase+1, oybase+observedyv[k]);
    oybase += observedyv[k];
  }
  fprintf(flistfile,"number of latent variables = %d\n\n", latenty);  

  fprintf(output,"genoud random seed = %ld\n", genoudseed);
  fprintf(output,"bootstrap random seed = %ld\n", bootseed);
  fprintf(output,"boundary-hit threshold = %17.10e\n\n", bhitthreshold);
  fprintf(flistfile,"genoud random seed = %ld\n", genoudseed);
  fprintf(flistfile,"bootstrap random seed = %ld\n", bootseed);
  fprintf(flistfile,"boundary-hit threshold = %17.10e\n\n", bhitthreshold);

  boundsflag = parsemodel(fmodel);

  /* Initialize with default constraint specifications */
  for (j=0; j<NUMOFMODELS; j++) {
    firsttime_g[j] = 0;
    firsttime_o[j] = 0;
  }

  /* fullsample, BIG, JACK, BOOT */
  runvars_array[0] = runvars;
  for (j=0; j<NUMCONTROLS; j++) {
    gosp = gosvec + j;
    gosp->equalities = matrix(1,0,1,runvars+1);
    gosp->inequalities = matrix(1,0,1,runvars+1);
    gosp->domains = matrix(1,runvars,1,3);
    for(i=1; i<=runvars; i++) {
      gosp->domains[i][1] = MIN;
      gosp->domains[i][2] = (double) i;
      gosp->domains[i][3] = MAX;
    }
  }
  for (i=0; i<runvars; i++) varmap_array[0][i] = i;

  /* specifications for boundary hits */
  /* set maximum number of boundary hits that can trigger constrained estimation */
  for (k=0, i=0; i<runvars; i++)
    if (whereXtype[i]==THETAEPS && whereXrow[i]==whereXcol[i]) {
      k++;
    }
  bhitlimit = k<MAXBOUNDHITS ? k : MAXBOUNDHITS;

  /* allocate storage for domains, etc. */
  for (j=NUMCONTROLS, k=1; k<=bhitlimit; k++, j+=2) {
    runvars_array[k] = runvars-k;
    gosp = gosvec + j;
    gosp->equalities = matrix(1,0,1,runvars+1-k);
    gosp->inequalities = matrix(1,0,1,runvars+1-k);
    gosp->domains = matrix(1,runvars-k,1,3);
    for(i=1; i<=runvars-k; i++) {
      gosp->domains[i][1] = MIN;
      gosp->domains[i][2] = (double) i;
      gosp->domains[i][3] = MAX;
    }
    gospB = gosp + 1;
    gospB->equalities = matrix(1,0,1,runvars+1-k);
    gospB->inequalities = matrix(1,0,1,runvars+1-k);
    gospB->domains = matrix(1,runvars-k,1,3);
    for(i=1; i<=runvars-k; i++) {
      gospB->domains[i][1] = MIN;
      gospB->domains[i][2] = (double) i;
      gospB->domains[i][3] = MAX;
    }
  }

  if (boundsflag>0) {
    int t2;
    double t1, t3;
    for(i=1; i<=runvars; i++) {
      if (fscanf(fmodel," %d %lf %lf",&t2,&t1,&t3) == 3) {
	for (j=0; j<NUMCONTROLS; j++) {
	  gosp = gosvec + j;
	  if (j == 0 || j == 2) {  /* fullsample and JACK populations */
	    gosp->domains[t2][1] = t1;
	    gosp->domains[t2][3] = t3;
	  }
	  else if (j == 1) {  /* BIG population */
	    if (t1 < 0.0)
	      gosp->domains[t2][1] = t1 * 10.0;
	    else
	      gosp->domains[t2][1] = t1 * 0.1;
	    if (t3 > 0.0)
	      gosp->domains[t2][3] = t3 * 10.0;
	    else
	      gosp->domains[t2][3] = t3 * 0.1;
	  }
	  else if (j == 3) {  /* BOOT population */
	    if (t1 < 0.0)
	      gosp->domains[t2][1] = t1 * 10.0;
	    else
	      gosp->domains[t2][1] = t1 * 0.1;
	    if (t3 > 0.0)
	      gosp->domains[t2][3] = t3 * 10.0;
	    else
	      gosp->domains[t2][3] = t3 * 0.1;
	  }
	}
      }
      else {
	fprintf(output,"error reading bounds.  terminating.\n");
	exit(4); 
      }
    }
  }
 
  initial_values = (double *) malloc((runvars)*sizeof(double));
  for (i=0; i<runvars; i++) {
    initial_values[i] = 9999.0; /* default starting values, i.e., none */
  }
  
  /* setting defaults for control stuff */
  for (i=0; i<NUMCONTROLS; i++) {
    population_size[i] = 251;
    oper1_use[i]=oper3_use[i]=oper4_use[i]=oper5_use[i]=oper6_use[i]=oper7_use[i]=50;
    oper2_use[i]=oper8_use[i]= 0;
    control_gradient_tolerance[i] = 0.00002;
    control_t[i]=0;  /* set triggers to off */
  }


    /* Reading the control specs from the modelspec file:
       the population size,
       total number of generations,
       total number of times to apply each of the operators,
       BFGS gradient tolerance parameter
       */
  while (fscanf(fmodel, "%s", parmident) > 0) {

    if (memcmp(parmident,"#",1)==0) {
      fgets(parmident, MAXPATH, fmodel);
    }
    
    else if (strcmp(parmident,"starting_values")==0) {
      starting_values=1;
      while (fscanf(fmodel, " %d %lf",&i, &initial) == 2) {
	initial_values[i-1] = initial;
      }
    }
    else if (strcmp(parmident,"control")==0) {
      fscanf(fmodel,"%d %d %d %d %d %d %d %d",
	     &oper1_use[0], &oper2_use[0], &oper3_use[0], &oper4_use[0], 
	     &oper5_use[0], &oper6_use[0], &oper7_use[0], &oper8_use[0]);
      fscanf(fmodel,"%lf ",&control_gradient_tolerance[0]);
      population_size[0] = oper1_use[0] + oper2_use[0] + oper3_use[0] +
	oper4_use[0] + oper5_use[0] + oper6_use[0] + oper7_use[0] + 
	oper8_use[0] + 1;
      control_t[0]=1;
    } /* end of control */

    else if (strcmp(parmident,"control.big")==0) {
      fscanf(fmodel,"%d %d %d %d %d %d %d %d",
	     &oper1_use[1], &oper2_use[1], &oper3_use[1], &oper4_use[1], 
	     &oper5_use[1], &oper6_use[1], &oper7_use[1], &oper8_use[1]);
      fscanf(fmodel,"%lf ",&control_gradient_tolerance[1]);
      population_size[1] = oper1_use[1] + oper2_use[1] + oper3_use[1] +
	oper4_use[1] + oper5_use[1] + oper6_use[1] + oper7_use[1] + 
	oper8_use[1] + 1;
      control_t[1]=1;
    } /* end of control.big */

    else if (strcmp(parmident,"control.jack")==0) {
      fscanf(fmodel,"%d %d %d %d %d %d %d %d",
	     &oper1_use[2], &oper2_use[2], &oper3_use[2], &oper4_use[2], 
	     &oper5_use[2], &oper6_use[2], &oper7_use[2], &oper8_use[2]);
      fscanf(fmodel,"%lf ",&control_gradient_tolerance[2]);
      population_size[2] = oper1_use[2] + oper2_use[2] + oper3_use[2] +
	oper4_use[2] + oper5_use[2] + oper6_use[2] + oper7_use[2] + 
	oper8_use[2] + 1;
      control_t[2]=1;
    } /* end of control.jack */

    else if (strcmp(parmident,"control.boot")==0) {
      fscanf(fmodel,"%d %d %d %d %d %d %d %d",
	     &oper1_use[3], &oper2_use[3], &oper3_use[3], &oper4_use[3], 
	     &oper5_use[3], &oper6_use[3], &oper7_use[3], &oper8_use[3]);
      fscanf(fmodel,"%lf ",&control_gradient_tolerance[3]);
      population_size[3] = oper1_use[3] + oper2_use[3] + oper3_use[3] +
	oper4_use[3] + oper5_use[3] + oper6_use[3] + oper7_use[3] + 
	oper8_use[3] + 1;
      control_t[3]=1;
    } /* end of control.boot */

    else {
      fprintf(output,"parmident=%s.\n", parmident);
      fprintf(output,"unknown argument in the LISREL model specification or bootstrap setup\n");
      fprintf(output,"portion of model specification file: %s\n", modelfilename);
      fprintf(stderr,"parmident=%s.\n", parmident);
      fprintf(stderr,"unknown argument in the LISREL model specification or bootstrap setup\n");
      fprintf(stderr,"portion of model specification file: %s\n", modelfilename);
      exit(4);
    }
  } /* end of while */
  fclose(fmodel); /* close the modelspec file */

  /* if control has been set, but control.? file has not been set,
     set it equal to the control file */
  if (control_t[0]==1) {
    for(i=1; i<NUMCONTROLS; i++) {
      if (control_t[i]==0) {   
	population_size[i] = population_size[0];
	oper1_use[i] = oper1_use[0];
	oper2_use[i] = oper2_use[0];
	oper3_use[i] = oper3_use[0];
	oper4_use[i] = oper4_use[0];
	oper5_use[i] = oper5_use[0];
	oper6_use[i] = oper6_use[0];
	oper7_use[i] = oper7_use[0];
	oper8_use[i] = oper8_use[0];
	control_gradient_tolerance[i] = control_gradient_tolerance[0];
      }
    } /* end of i loop */
  }

  if (use_boundary==0) {
    fprintf(output,"Out of bounds values are not used (default).\n");
    fprintf(flistfile,"Out of bounds values are not used (default).\n");
  }
  else {
    fprintf(output,"Out of bounds values are used.\n");
    fprintf(flistfile,"Out of bounds values are used.\n");
  }

  if (starting_values==0) {
    fprintf(output,  "There are no user supplied starting values.\n");
    fprintf(flistfile,  "There are no user supplied starting values.\n");
  }
  else {
    fprintf(output,"There are user supplied staring values: \n");
    fprintf(flistfile,"There are user supplied staring values: \n");
    for (i=0; i<runvars; i++) {
      fprintf(output,"%2d) %4s %2d %2d = %17.10e\n", i+1, parmsyms[whereXtype[i]],
	      whereXrow[i]+1, whereXcol[i]+1, initial_values[i]);
      fprintf(flistfile,"%2d) %4s %2d %2d = %17.10e\n", i+1, parmsyms[whereXtype[i]],
	      whereXrow[i]+1, whereXcol[i]+1, initial_values[i]);
    }
  }

} /* end definemodel */


int parsemodel(FILE *fmodel)
{
  extern int
    observedy, latenty, runvars, runcases, runboots, runfixvars,
    run_nochange_lim, run_notdone_lim;
  extern int rungroups, *observedyv;

  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;

  extern int *whereXrow, *whereXcol, *fixXrow, *fixXcol;
  extern int *whereXtype, *fixXtype;
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap_array[MAXBOUNDHITS+1];
  extern int first_set_structures;

  extern char modelfilename[MAXPATH];
  extern char listfile[MAXPATH];
  extern int ilambda, itheta, ibeta, ipsi, ipsi_diag, psizeros;

  extern int start_fcov, end_fcov, start_psi, end_psi, fcov_vars;

  extern int equality_constraints;
  extern int *equal_lambda_row, *equal_lambda_col, *equal_beta_row, *equal_beta_col,
    *equal_psi_row, *equal_psi_col, *equal_theta_row, *equal_theta_col;

  extern int *boundary_hit, *boundary_use;
  extern FILE *flistfile;
  extern int degrees_of_freedom;

  int boundsflag = 0;
  int i,j,k, numx, numfix;
  int pcode1, pcode2, counter;

  double loading;
  int setr1, setr2, setc1, setc2;
  int trigger;

  char parmident[100];

  trigger=0;
  ilambda=itheta=ibeta=ipsi= ipsi_diag= psizeros= 0;


  /* allocate storage for *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi */
  lambda_y = (double *) malloc(((observedy*latenty)+(latenty))*sizeof(double));
  theta_epsilon = (double *)
    malloc(((observedy*observedy)+(observedy))*sizeof(double));
  beta = (double *) malloc(((latenty*latenty)+(latenty))*sizeof(double));
  identity_beta = (double *) malloc(((latenty*latenty)+(latenty))*sizeof(double));
  psi = (double *) malloc(((latenty*latenty)+(latenty))*sizeof(double));

  fixXrow = (int *) malloc((MAXPARMS)*sizeof(int));
  fixXcol = (int *) malloc((MAXPARMS)*sizeof(int));
  fixXtype = (int *) malloc((MAXPARMS)*sizeof(int));
  boundary_hit = (int *) malloc((MAXPARMS)*sizeof(int));
  boundary_use = (int *) malloc((MAXPARMS)*sizeof(int));
  equal_lambda_row = (int *) malloc((observedy)*sizeof(int));
  equal_lambda_col = (int *) malloc((latenty)*sizeof(int));
  equal_beta_row = (int *) malloc((latenty)*sizeof(int));
  equal_beta_col = (int *) malloc((latenty)*sizeof(int));
  equal_psi_row = (int *) malloc((latenty)*sizeof(int));
  equal_psi_col = (int *) malloc((latenty)*sizeof(int));
  equal_theta_row = (int *) malloc((observedy)*sizeof(int));
  equal_theta_col = (int *) malloc((observedy)*sizeof(int));

  for(i=0; i<MAXBOUNDHITS+1; i++) {
    whereXrow_array[i] = (int *) malloc((MAXPARMS)*sizeof(int));
    whereXcol_array[i] = (int *) malloc((MAXPARMS)*sizeof(int));
    whereXtype_array[i] = (int *) malloc((MAXPARMS)*sizeof(int));
    varmap_array[i] = (int *) malloc((MAXPARMS)*sizeof(int));
  }

  for (i=0;i<observedy;i++) {
    for (j=0;j<latenty;j++) {
      lambda_y[M(i,j,latenty)]=0.0;
    }
  }

  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      theta_epsilon[M(i,j,observedy)]=0.0;
    }
  }

  for (i=0;i<latenty;i++) {
    for (j=0;j<latenty;j++) {
      beta[M(i,j,latenty)]=0.0;
      identity_beta[M(i,j,latenty)]=0.0;
      psi[M(i,j,latenty)]=0.0;
    }
  }

  for (i=0;i<latenty;i++) {
    identity_beta[M(i,i,latenty)]=1.0;
  }



  /* setting up equality stuff */
  equality_constraints=0;
  for (i=0; i<observedy; i++) {
    equal_lambda_row[i] = MAXPARMS+1;
    equal_theta_row[i] = MAXPARMS+1;
    equal_theta_col[i] = MAXPARMS+1;
  }
  for (i=0; i<latenty; i++) {
    equal_lambda_col[i] = MAXPARMS+1;
    equal_beta_row[i] = MAXPARMS+1;
    equal_beta_col[i] = MAXPARMS+1;
    equal_psi_row[i] = MAXPARMS+1;
    equal_psi_col[i] = MAXPARMS+1;
  }

  whereXrow = whereXrow_array[0];
  whereXcol = whereXcol_array[0];
  whereXtype = whereXtype_array[0];
  numx = numfix = fcov_vars =0;

  while (fscanf(fmodel, "%s", parmident) != EOF) {

    if (memcmp(parmident,"#",1)==0) {
      fgets(parmident, MAXPATH, fmodel);
    }
    else if (strcmp(parmident,"ly")==0) {
      /* lambda inputs */
      while(fscanf(fmodel, "%d %d %lf", &pcode1, &pcode2, &loading) == 3) {
	if (pcode1 == 0) {
	  /* setting two different parameters to be equal */
	  /* input format:  0 SR1 SC1 R1 C1
	     where SR1,SC1 are row,col of parm that is constrained to equal
	     the value at row,col R1,C1 */
	  /* setr1, setc1:  SR1, SC1 */
	  setr1 = pcode2-1;
	  setc1 = ((int)loading) - 1;
	  if (fscanf(fmodel, "%d %d", &pcode1, &pcode2) == 2) {
	    equality_constraints++;
	    /* R1, C1 */
	    equal_lambda_row[setr1] = pcode1-1;
	    equal_lambda_col[setc1] = pcode2-1;
	  }
	}
	else {
	  pcode1--;
	  pcode2--;
	  if (pcode1<0 || pcode2<0 || pcode1>=observedy || pcode2>=latenty) {
	    fprintf(output,"out of range matrix index for LAMBDAY: %d %d\n",
		   pcode1+1,pcode2+1);
	    fprintf(stderr,"out of range matrix index for LAMBDAY: %d %d\n",
		   pcode1+1,pcode2+1);
	    exit(1);
	  }
	  if (loading==0.0) {
	    lambda_y[M(pcode1,pcode2,latenty)]=0.0;
	    whereXrow[numx]=pcode1;
	    whereXcol[numx]=pcode2;
	    whereXtype[numx] = LAMBDAY;
	    ilambda++;
	    numx++;
	  }
	  else {
	    lambda_y[M(pcode1,pcode2,latenty)]= loading;
	    fixXrow[numfix]=pcode1;
	    fixXcol[numfix]=pcode2;
	    fixXtype[numfix] = LAMBDAY;
	    numfix++;
	  }
	}
      }
    }

    else if (strcmp(parmident,"te")==0) {
      /* theta_epsilon inputs */
      while(fscanf(fmodel, "%d %d %lf", &pcode1, &pcode2, &loading) == 3) {
	if (pcode1 == 0) {
	  /* setting two different parameters to be equal */
	  /* input format:  0 SR1 SC1 R1 C1
	     where SR1,SC1 are row,col of parm that is constrained to equal
	     the value at row,col R1,C1 */
	  /* setr1, setc1:  SR1, SC1 */
	  setr1 = pcode2-1;
	  setc1 = ((int)loading) - 1;
	  if (fscanf(fmodel, "%d %d", &pcode1, &pcode2) == 2) {
	    equality_constraints++;
	    /* R1, C1 */
	    equal_theta_row[setr1] = pcode1-1;
	    equal_theta_col[setc1] = pcode2-1;
	    /* impose symmetry */
	    equal_theta_row[setc1] = pcode1-1;
	    equal_theta_col[setr1] = pcode2-1;
	  }
	}
	else if (pcode1 == -1) {
	  /* input format:  -1 R1 R2
	     if R1 = -1, THETA_EPSILON is free diagonal */
	  if (pcode2 == -1) {
	    /* DIAG THETA_EPSILON*/
	    for (j=0;j<observedy;j++) {
	      theta_epsilon[M(j,j,observedy)]=0.0;
	      whereXrow[numx]=j;
	      whereXcol[numx]=j;
	      whereXtype[numx] = THETAEPS;
	      itheta++;
	      numx++;
	    }
	  }
	}
	else if (pcode1 == -2) {
	  /* input format:  -2 R1 R2
	     if R1 > 0, THETA_EPSILON from row,col R1,R1 thru row,col R2,R2 is
	     fully filled in with free elements */
	  /* fill in full THETA_EPSILON for specified range of rows and cols */
	  pcode1 = pcode2 - 1;
	  pcode2 = ((int)loading) - 1;
	  for (j=pcode1;j<=pcode2;j++) 
	    {
	      theta_epsilon[M(j,j,observedy)]=0.0;
	      whereXrow[numx]=j;
	      whereXcol[numx]=j;
	      whereXtype[numx] = THETAEPS;
	      itheta++;
	      numx++;
	    }
	  for (j=pcode1;j<=pcode2;j++) 
	    {
	      for (k=j+1;k<=pcode2;k++) 
		{
		  theta_epsilon[M(j,k,observedy)]=0.0;
		  theta_epsilon[M(k,j,observedy)]=0.0;
		  whereXrow[numx]=j;
		  whereXcol[numx]=k;
		  whereXtype[numx] = THETAEPS;
		  itheta++;
		  numx++;
		}
	    }
	}
	else {
	  pcode1--;
	  pcode2--;
	  if (pcode1<0 || pcode2<0 || pcode1>=observedy || pcode2>=observedy) {
	    fprintf(output,"out of range matrix index for THETA: %d %d\n",
		   pcode1+1,pcode2+1);
	    fprintf(stderr,"out of range matrix index for THETA: %d %d\n",
		   pcode1+1,pcode2+1);
	    exit(1);
	  }
	  if (loading == 0.0) {
	    theta_epsilon[M(pcode1,pcode2,observedy)]=0.0;
	    theta_epsilon[M(pcode2,pcode1,observedy)]=0.0;
	    whereXrow[numx]=pcode1;
	    whereXcol[numx]=pcode2;
	    whereXtype[numx] = THETAEPS;
	    itheta++;
	    numx++;
	  }
	  else
	    {
	      theta_epsilon[M(pcode1,pcode2,observedy)]= loading;
	      theta_epsilon[M(pcode2,pcode1,observedy)]= loading;
	      fixXrow[numfix]=pcode1;
	      fixXcol[numfix]=pcode2;
	      fixXtype[numfix] = THETAEPS;
	      numfix++;
	    }
	}
      }
    }

    else if (strcmp(parmident,"b")==0) {
      /* beta inputs */
      while(fscanf(fmodel, "%d %d %lf", &pcode1, &pcode2, &loading) == 3) {
	if (pcode1 == 0) {
	  /* setting two different parameters to be equal */
	  /* input format:  0 SR1 SC1 R1 C1
	     where SR1,SC1 are row,col of parm that is constrained to equal
	     the value at row,col R1,C1 */
	  /* setr1, setc1:  SR1, SC1 */
	  setr1 = pcode2-1;
	  setc1 = ((int)loading) - 1;
	  if (fscanf(fmodel, "%d %d", &pcode1, &pcode2) == 2) {
	    equality_constraints++;
	    /* R1, C1 */
	    equal_beta_row[setr1] = pcode1-1;
	    equal_beta_col[setc1] = pcode2-1;
	  }
	}
	else if (pcode1 == -2) {
	  if (pcode2 > 0) {
	    /* setting a rectangular block of parms free */
	    /* input format:  -2 R1 C1 R2 C2
	       where R1,C1 are upper-left corner and R2,C2 are lower-right corner
	       of the rectangle in matrix B that is to be set free (skipping any
	       diagonal elements) */
	    setr1 = pcode2-1;
	    setc1 = ((int)loading) - 1;
	    if (fscanf(fmodel, "%d %d", &setr2, &setc2) == 2) {
	      /* R1, C1 */
	      setr2--;
	      setc2--;
	      for (i=setr1; i<setr2+1; i++) {
		for (j=setc1; j<setc2+1; j++) {
		  if (i != j) {
		    beta[M(i,j,latenty)]=0.0;
		    whereXrow[numx]=i;
		    whereXcol[numx]=j;
		    whereXtype[numx] = BETA;
		    ibeta++;
		    numx++;
		  }
		}
	      }
	    }
	  }
	}
	else {
	  pcode1--;
	  pcode2--;
	  if (pcode1<0 || pcode2<0 || pcode1>=latenty || pcode2>=latenty) {
	    fprintf(output,"out of range matrix index for BETA: %d %d\n",pcode1+1,pcode2+1);
	    fprintf(stderr,"out of range matrix index for BETA: %d %d\n",pcode1+1,pcode2+1);
	    exit(1);
	  }
	  if (loading == 0.0)
	    {
	      beta[M(pcode1,pcode2,latenty)]=0.0;
	      whereXrow[numx]=pcode1;
	      whereXcol[numx]=pcode2;
	      whereXtype[numx] = BETA;
	      ibeta++;
	      numx++;
	    }
	  else 
	    {
	      beta[M(pcode1,pcode2,latenty)]= loading;
	      fixXrow[numfix]=pcode1;
	      fixXcol[numfix]=pcode2;
	      fixXtype[numfix] = BETA;
	      numfix++;
	    }
	}
      }
    }

    else if (strcmp(parmident,"psi")==0) {
      /* psi inputs */
      while(fscanf(fmodel, "%d %d %lf", &pcode1, &pcode2, &loading) == 3) {
	if (pcode1 == 0) {
	  /* setting two different parameters to be equal */
	  /* input format:  0 SR1 SC1 R1 C1
	     where SR1,SC1 are row,col of parm that is constrained to equal
	     the value at row,col R1,C1 */
	  /* setr1, setc1:  SR1, SC1 */
	  setr1 = pcode2-1;
	  setc1 = ((int)loading) - 1;
	  if (fscanf(fmodel, "%d %d", &pcode1, &pcode2) == 2) {
	    equality_constraints++;
	    /* R1, C1 */
	    equal_psi_row[setr1] = pcode1-1;
	    equal_psi_col[setc1] = pcode2-1;
	    /* impose symmetry */
	    equal_psi_row[setc1] = pcode1-1;
	    equal_psi_col[setr1] = pcode2-1;
	  }
	}
	else if (pcode1 == -1) {
	  /* input format:  -1 R1 R2
	     if R1 = -1, PSI is free diagonal,
	     if R1 = -2, PSI is full free */
	  if (pcode2 == -1) {
	    /*DIAG psi */
	    for (j=0;j<latenty;j++) 
	      {
		psi[M(j,j,latenty)]=0.0;
		whereXrow[numx]=j;
		whereXcol[numx]=j;
		whereXtype[numx] = PSI;
		ipsi++;
		ipsi_diag++;
		numx++;
	      }
	  }
	  else if (pcode2 == -2) {
	    /* FULL psi */
	    for (j=0;j<latenty;j++) 
	      {
		psi[M(j,j,latenty)]=0.0;
		whereXrow[numx]=j;
		whereXcol[numx]=j;
		whereXtype[numx] = PSI;
		ipsi++;
		ipsi_diag++;
		numx++;
	      }
	    for (j=1;j<latenty;j++) 
	      {
		for (k=0;k<j;k++) 
		  {
		    psi[M(j,k,latenty)]=0.0;
		    psi[M(k,j,latenty)]=0.0;
		    whereXrow[numx]=j;
		    whereXcol[numx]=k;
		    whereXtype[numx] = PSI;
		    ipsi++;
		    numx++;
		  }
	      }
	  }
	}
	else if (pcode1 == -2) {
	  /* input format:  -2 R1 R2
	     if R1 > 0, PSI from row,col R1,R1 thru row,col R2,R2 is
	     fully filled in with free elements */
	  /* fill in full PSI for specified range of rows and cols */
	  pcode1 = pcode2 - 1;
	  pcode2 = ((int)loading) - 1;
	  for (j=pcode1;j<=pcode2;j++) {
	    psi[M(j,j,latenty)]=0.0;
	    whereXrow[numx]=j;
	    whereXcol[numx]=j;
	    whereXtype[numx] = PSI;
	    ipsi++;
	    ipsi_diag++;
	    numx++;
	  }
	  for (j=pcode1;j<=pcode2;j++) {
	    for (k=j+1;k<=pcode2;k++) {
	      psi[M(j,k,latenty)]=0.0;
	      psi[M(k,j,latenty)]=0.0;
	      whereXrow[numx]=j;
	      whereXcol[numx]=k;
	      whereXtype[numx] = PSI;
	      ipsi++;
	      numx++;
	    }
	  }
	}
	else if (pcode1 == -3) {
	  /* FCOV PSI */
	  /* part of PSI is set directly from the sample covariance matrix */
	  /* input format:  -3 S1 E1 S2 E2
	     where S1,E1 are the starting,ending latent variables and
	     S2,E2 are the starting,ending observed variables */
	  start_psi = pcode2 - 1;
	  end_psi = ((int)loading) - 1;
	  if (fscanf(fmodel, "%d %d", &start_fcov, &end_fcov) == 2) {
	    /* S2, E2 */
	    start_fcov--;
	    end_fcov--;
	    if ((end_psi - start_psi) != (end_fcov - start_fcov)) {
	      fprintf(output,"fcov-PSI range mismatch:\n");
	      fprintf(output,"\tstart_psi=%d end_psi=%d start_fcov=%d end_fcov=%d\n",
		     start_psi,end_psi, start_fcov,end_fcov);
	      fprintf(stderr,"fcov-PSI range mismatch:\n");
	      fprintf(stderr,"\tstart_psi=%d end_psi=%d start_fcov=%d end_fcov=%d\n",
		     start_psi,end_psi, start_fcov,end_fcov);
	      exit(1);
	    }
	    if (start_psi<0 || end_psi<0
		|| start_psi>=latenty || end_psi>=latenty) {
	      fprintf(output,"out of range matrix index for PSI: %d %d\n",
		     start_psi+1,end_psi+1);
	      fprintf(stderr,"out of range matrix index for PSI: %d %d\n",
		     start_psi+1,end_psi+1);
	      exit(1);
	    }
	    if (start_fcov<0 || end_fcov<0
		|| start_fcov>=observedy || end_fcov>=observedy) {
	      fprintf(output,"out of range matrix index for fcov (PSI): %d %d\n",
		     start_fcov+1,end_fcov+1);
	      fprintf(stderr,"out of range matrix index for fcov (PSI): %d %d\n",
		     start_fcov+1,end_fcov+1);
	      exit(1);
	    }

	    /* add total number of elements in submatrix to fcov_vars */
	    j = end_fcov - start_fcov + 1;
	    fcov_vars += (j*(j+1))/2 ;

	    /* increment count of non-zero psi-diag elements */
	    ipsi_diag += j;
	  }
	}
	else {
	  pcode1--;
	  pcode2--;
	  if (pcode1<0 || pcode2<0 || pcode1>=latenty || pcode2>=latenty) {
	    fprintf(output,"out of range matrix index for PSI: %d %d\n",
		   pcode1+1,pcode2+1);
	    fprintf(stderr,"out of range matrix index for PSI: %d %d\n",
		   pcode1+1,pcode2+1);
	    exit(1);
	  }
	  if (loading == 0.0) 
	    {
	      psi[M(pcode1,pcode2,latenty)]=0.0;
	      psi[M(pcode2,pcode1,latenty)]=0.0;
	      whereXrow[numx]=pcode1;
	      whereXcol[numx]=pcode2;
	      whereXtype[numx] = PSI;
	      ipsi++;
	      if (pcode1==pcode2) ipsi_diag++;
	      numx++;
	    }
	  else
	    {
	      psi[M(pcode1,pcode2,latenty)]= loading;
	      psi[M(pcode2,pcode1,latenty)]= loading;
	      fixXrow[numfix]=pcode1;
	      fixXcol[numfix]=pcode2;
	      fixXtype[numfix] = PSI;
	      if (pcode1==pcode2 && loading!=0.0) ipsi_diag++;
	      numfix++;
	    }
	}
      }
    }
    
    else if (strcmp(parmident,"bounds")==0) {
      boundsflag = 1;
      break;
    }
    else {
      fprintf(output,"parmident=%s.\n", parmident);
      fprintf(output, "unknown model parameter in model specification file: %s\n",
	      modelfilename);
      fprintf(stderr, "unknown model parameter in model specification file: %s\n",
	      modelfilename);
      exit(4);
    }
  }


  runvars=numx;  /* record the number of estimated parameters */
  for (degrees_of_freedom=0, k=0; k<rungroups; k++) {
    degrees_of_freedom += (observedyv[k]*(observedyv[k]+1))/2;
  }
  degrees_of_freedom -= runvars+fcov_vars;

  if (fcov_vars == 0) {
    fprintf(output,"number of parameters to estimate = %d\n", runvars);
    fprintf(flistfile,"number of parameters to estimate = %d\n", runvars);
  }
  else {
    fprintf(output,"number of parameters to estimate = %d\n", runvars+fcov_vars);
    fprintf(output,"  number of fcov fixed parameters = %d\n", fcov_vars);
    fprintf(output,"  actual number of parameters to estimate = %d\n", runvars);
    fprintf(flistfile,"number of parameters to estimate = %d\n", runvars+fcov_vars);
    fprintf(flistfile,"  number of fcov fixed parameters = %d\n", fcov_vars);
    fprintf(flistfile,"  actual number of parameters to estimate = %d\n", runvars);
  }
  fprintf(output,"the degrees of freedom = %d\n", degrees_of_freedom);
  fprintf(output,"total information = %d\n", degrees_of_freedom+runvars+fcov_vars);
  fprintf(output,"\n");
  fprintf(output,"the number of equality constraints = %d\n", equality_constraints);
  fprintf(flistfile,"the degrees of freedom = %d\n", degrees_of_freedom);
  fprintf(flistfile,"total information = %d\n", degrees_of_freedom+runvars+fcov_vars);
  fprintf(flistfile,"\n");
  fprintf(flistfile,"the number of equality constraints = %d\n", equality_constraints);

  if (equality_constraints > 0) {
    fprintf(output,"constrained parms.  The second one is actually estimated:\n");
    fprintf(flistfile,"constrained parms.  The second one is actually estimated:\n");
    for (i=0; i<observedy; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_lambda_row[i] != (MAXPARMS+1)
	    && equal_lambda_col[j] != (MAXPARMS+1)) {
	  fprintf(output,"LY(%d,%d) = LY(%d,%d)\n",
		 i+1, j+1, equal_lambda_row[i]+1, equal_lambda_col[j]+1);
	  fprintf(flistfile,"LY(%d,%d) = LY(%d,%d)\n",
		 i+1, j+1, equal_lambda_row[i]+1, equal_lambda_col[j]+1);
	}
      }
    }
    for (i=0; i<latenty; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_beta_row[i] != (MAXPARMS+1)
	    && equal_beta_col[j] != (MAXPARMS+1)) {
	  fprintf(output,"B(%d,%d) = B(%d,%d)\n",
		 i+1, j+1, equal_beta_row[i]+1, equal_beta_col[j]+1);
	  fprintf(flistfile,"B(%d,%d) = B(%d,%d)\n",
		 i+1, j+1, equal_beta_row[i]+1, equal_beta_col[j]+1);
	}
      }
    }
    for (i=0; i<latenty; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_psi_row[i] != (MAXPARMS+1)
	    && equal_psi_col[j] != (MAXPARMS+1)) {
	  fprintf(output,"PSI(%d,%d) = PSI(%d,%d)\n",
		 i+1, j+1, equal_psi_row[i]+1, equal_psi_col[j]+1);
	  fprintf(flistfile,"PSI(%d,%d) = PSI(%d,%d)\n",
		 i+1, j+1, equal_psi_row[i]+1, equal_psi_col[j]+1);
	}
      }
    }
    for (i=0; i<observedy; i++) {
      for (j=0; j<observedy; j++) {
	if (equal_theta_row[i] != (MAXPARMS+1)
	    && equal_theta_col[j] != (MAXPARMS+1)) {
	  fprintf(output,"TE(%d,%d) = TE(%d,%d)\n",
		 i+1, j+1, equal_theta_row[i]+1, equal_theta_col[j]+1);
	  fprintf(flistfile,"TE(%d,%d) = TE(%d,%d)\n",
		 i+1, j+1, equal_theta_row[i]+1, equal_theta_col[j]+1);
	}
      }
    }
  }


  runfixvars=numfix;  /* record the number of specified fixed parameters */
  
  return boundsflag;
} /* end parsemodel */

/* boundchk:  check for psi or theta (diagonal) parameters on boundary */
int boundchk(double *X)
{
  extern int boundary_flag;
  extern int *boundary_hit;
  extern int *varmap;
  extern int runvars;
  extern int runvars_array[MAXBOUNDHITS+1];
  extern int *whereXrow, *whereXcol, *whereXtype;
  extern double bhitthreshold;
  extern int psizeros;

  int i, j;

  for (i=0; i<runvars; i++) {
    if (whereXtype[i]==PSI && whereXrow[i]==whereXcol[i]) {
      if (boundary_hit[varmap[i]]==0 && X[i] < bhitthreshold) {
	boundary_hit[varmap[i]] = 1;
	psizeros++;
      }
    }
    if (whereXtype[i]==THETAEPS && whereXrow[i]==whereXcol[i]) {
      if (boundary_hit[varmap[i]]==0 && X[i] < bhitthreshold) {
	boundary_hit[varmap[i]] = 1;
      }
    }
  }
  boundary_flag = 0;
  for (i=0; i<runvars_array[0]; i++) {
    if (boundary_hit[i]==1) boundary_flag++;
  }
  return(boundary_flag);
}

/* onboundset:  copy indexes and domains for off-boundary parms */
void onboundset(int fromgspec, int togspec, int bhitn, int *bhitvec)
{
  extern int *varmap_array[MAXBOUNDHITS+1];
  extern int runvars_array[MAXBOUNDHITS+1];
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern struct gspecobjs gosvec[NUMOFMODELS];

  int i, k;
  struct gspecobjs *gospf, *gospt;

  /* bhitn should be the number of nonzero values in bhitvec */

  if (fromgspec >=0 && fromgspec < NUMCONTROLS
      && togspec >= NUMCONTROLS && togspec < NUMOFMODELS
      && bhitn > 0 && bhitn <= MAXBOUNDHITS) {
    gospf = gosvec + fromgspec;
    gospt = gosvec + togspec;
    for (k=0, i=0; i<runvars_array[0]; i++) {
      if (bhitvec[i] == 0) {
	gospt->domains[k+1][1] = gospf->domains[i+1][1];
	gospt->domains[k+1][3] = gospf->domains[i+1][3];
	whereXtype_array[bhitn][k] = whereXtype_array[0][i];
	whereXrow_array[bhitn][k] = whereXrow_array[0][i];
	whereXcol_array[bhitn][k] = whereXcol_array[0][i];
	varmap_array[bhitn][k] = i;
	k++;
      }
    }
  }
  else {
    fprintf(output,"onboundset (bad args): %d, %d, %d\n", fromgspec, togspec, bhitn);
    fprintf(stderr,"onboundset (bad args): %d, %d, %d\n", fromgspec, togspec, bhitn);
    exit(4);
  }
}

void dumpbootdata(unsigned short int *bootdata, int *numobsv, int ngroups,
		  int nboots)
{
  extern char bootdatafilename[MAXPATH];
  int k, nsum;
  long int i;
  FILE *out_bootdata;

#if WINDOWS_SYS
  extern char redirect_stdout[MAXPATH];
  extern short int redirect_trigger;
#endif

  fprintf(output,"\nPrinting bootdata vector to file: %s\n\n", bootdatafilename);
  fflush(output);

#if WINDOWS_SYS
  if (redirect_trigger==1) {
    fclose(output);
    if((output = fopen(redirect_stdout, "a+")) == NULL) {
      fprintf(stderr,"cannot reopen file:  %s\n", redirect_stdout);
      exit(1);
    }
  }
#endif

  out_bootdata = fopen(bootdatafilename, "w");
  if (out_bootdata == NULL)
    {
      fprintf(output,"open failed, file %s\n", bootdatafilename);
      fprintf(stderr,"open failed, file %s\n", bootdatafilename);
      exit(1);
    }      

  for (nsum=0, k=0; k<ngroups; k++) nsum += numobsv[k];
  fprintf(out_bootdata, "%d %d\n", nsum, nboots);

  for(i=0;i<nsum*nboots;i++) {
    fprintf(out_bootdata, "%d\n", bootdata[i]);
  }
  
  fclose(out_bootdata);

}

long int countcases()
{
  extern char **fullsamplename;
  extern int rungroups, *runcasesv, *observedyv;

  int k, nw;
  long int totcases = 0;
  double mytmp;

  FILE *fdat;

  for (k=0; k<rungroups; k++) {
    if((fdat = fopen(fullsamplename[k], "r")) == NULL) {
      fprintf(output,"cannot open file:  %s\n", fullsamplename[k]);
      fprintf(stderr,"cannot open file:  %s\n", fullsamplename[k]);
      exit(1);
    }

    nw=0;
    while ((fscanf(fdat, "%lf", &mytmp)) !=EOF) {
      nw++;
    }

    fclose(fdat);

    if (fmod((double)nw, (double)observedyv[k]) != 0) {
      fprintf(output,"ERROR: An error has occured while reading the input dataset file.\nThe file does not appear to be rectangular.\nEvery variable does NOT have the same number of observations.\nThe data set file is: %s\n\n", fullsamplename[k]);
      fprintf(stderr,"ERROR: An error has occured while reading the input dataset file.\nThe file does not appear to be rectangular.\nEvery variable does NOT have the same number of observations.\nThe data set file is: %s\n\n", fullsamplename[k]);
      exit(1);
    }

    runcasesv[k] = nw/observedyv[k];
    totcases += runcasesv[k];
  }
  return totcases;
}
