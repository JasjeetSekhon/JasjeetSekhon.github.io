/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include "data.h"
#include "toplevel.h"
#include "genoud.h"
#include "init.h"
#include "normalse.h"

static char *sccsversion = "@(#)toplevel.c	1.4   7/23/98";

void toplevel(int ngroups, int *numobsv, int numobs, int nboots, int *novarsv,
	      int novars, int nparms)
{
  extern int *caseuse;
  extern double *record;
  extern double **data, **wdata;
  extern double *cov;
  extern char **fullsamplename;
  extern char recordfilename[MAXPATH];
  extern char listfile[MAXPATH];
  extern short int bootdatatrigger;
  extern int weightflag;

  int k;
  unsigned short int **bootdata;
  double **fullsampledata, **weightdata;

  /* allocate storage for global (external) vectors */
  caseuse = (int *) malloc(ngroups*sizeof(int));
  record = (double *) malloc(((numobs+nboots+1)*(nparms+OFFSET))*sizeof(double));
  data = (double **) malloc(ngroups*sizeof(double *));
  for (k=0; k<ngroups; k++)
    data[k] = (double *) malloc(novarsv[k]*numobsv[k]*sizeof(double));
  if (weightflag==1) {
    wdata = (double **) malloc(ngroups*sizeof(double *));
    for (k=0; k<ngroups; k++)
      wdata[k] = (double *) malloc(numobsv[k]*sizeof(double));
  }
  cov = (double *) malloc(((novars*novars)+(novars))*sizeof(double));

  /* allocate storage for main data and bootstrap resampling vectors */
  fullsampledata = (double **) malloc(ngroups*sizeof(double *));
  for (k=0; k<ngroups; k++)
    fullsampledata[k] = (double *) malloc(numobsv[k]*novarsv[k]*sizeof(double));
  if (weightflag==1) {
    weightdata = (double **) malloc(ngroups*sizeof(double *));
    for (k=0; k<ngroups; k++)
      weightdata[k] = (double *) malloc(numobsv[k]*sizeof(double));
  }
  bootdata = (unsigned short int **) malloc(ngroups*sizeof(unsigned short int *));
  for (k=0; k<ngroups; k++)
    bootdata[k] = (unsigned short int *)
      malloc(numobsv[k]*nboots*sizeof(unsigned short int));

  createbootd(bootdata, numobsv, ngroups, nboots);
/*  readbootd(bootdata, numobs, nboots); */

  if (bootdatatrigger==1) {
    dumpbootdata(bootdata, numobsv, ngroups, nboots);
  }

  readsample(fullsamplename, fullsampledata, ngroups, numobsv, novarsv);
  if (weightflag==1) readweights(weightname, weightdata, ngroups, numobsv);
  samplestats(fullsampledata, ngroups, numobsv, novarsv,
	      weightflag, weightdata);

  setup_record(nparms, numobs, nboots);
  glisrelbca(fullsampledata, weightdata, bootdata, numobs, nboots, novars, nparms,
	     ngroups, numobsv, novarsv);

  if((flistfile = fopen(listfile, "a+")) == NULL) {
    fprintf(output,"WARNING: cannot reopen file:  %s\n", listfile);
    fprintf(stderr,"WARNING: cannot reopen file:  %s\n", listfile);
  }
  printspecs(1,0); 
  bca(nparms, numobs, nboots);  /* compute BCa confidence intervals */
/*  record_dump(record, nparms, numobs, nboots, recordfilename); */

  for (k=0; k<ngroups; k++) free(bootdata[k]);
  free(bootdata);
  for (k=0; k<ngroups; k++) free(fullsampledata[k]);
  free(fullsampledata);
  free(cov);
  for (k=0; k<ngroups; k++) free(data[k]);
  free(data);
  free(record);
  free(caseuse);
} /* end toplevel */

void rungen(int binit, int nparms, int resetX, int dumpflag)
{
  extern int boundary_flag;
  extern short int dobig;
  extern long int number;
  extern double *record;
  extern int runvars, runvars_array[MAXBOUNDHITS+1];
  extern int whichcontrol, reset_from_X, converged_flag;
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap, *varmap_array[MAXBOUNDHITS+1];
  extern int bhitlimit;
  extern int *boundary_hit, *boundary_use;
  extern int ibeta, psizeros;

  static struct NormalAsy *NAstruct;    

  int i, j, hflag, holdcontrol;
  int loopflag;

  runvars = runvars_array[0];
  whereXrow = whereXrow_array[0];
  whereXcol = whereXcol_array[0];
  whereXtype = whereXtype_array[0];
  varmap = varmap_array[0];

  psizeros = 0;  /* counter for number of boundary hits on PSI's diagonal */
  boundary_flag = hflag = 0;
  for (i=0; i<runvars; i++) boundary_use[i] = boundary_hit[i] = 0;
  reset_from_X = resetX;
  genoud();
  reset_from_X = 2;
  for (loopflag=0; loopflag<2; loopflag++) {
    holdcontrol = whichcontrol;
    while (boundary_flag > hflag) {
      fprintf(output,"SOLUTION ON BOUNDARY\n");
      hflag = boundary_flag;
      if (boundary_flag <= bhitlimit) {
	fprintf(output,"trying CONSTRAINED(-%d) population\n", boundary_flag);
	/* use a non-BIG boundary-hit control specification */
	whichcontrol = NUMCONTROLS + (hflag-1)*2;
	constrained_flag = 1;
	for (i=0; i<runvars_array[0]; i++) boundary_use[i] = boundary_hit[i];
	runvars = runvars_array[boundary_flag];
	whereXrow = whereXrow_array[boundary_flag];
	whereXcol = whereXcol_array[boundary_flag];
	whereXtype = whereXtype_array[boundary_flag];
	varmap = varmap_array[boundary_flag];
	onboundset(holdcontrol, whichcontrol, boundary_flag, boundary_hit);
	genoud();

	if (boundary_flag==hflag && converged_flag <= 0) {
	  fprintf(output,"trying BIGGER CONSTRAINED(-%d) population\n", boundary_flag);
	  whichcontrol += 1;
	  onboundset(1, whichcontrol, boundary_flag, boundary_hit);
	  genoud();
	  whichcontrol -= 1;
	}

	constrained_flag = 0;
      }
      else {
	fprintf(output,"TOO MANY CONSTRAINTS (%d)\n", boundary_flag);
	break;
      }
    }
    whichcontrol = holdcontrol;
    if (binit==1 || converged_flag <= 0) {
      psizeros = 0;
      boundary_flag = hflag = 0;
      runvars = runvars_array[0];
      whereXrow = whereXrow_array[0];
      whereXcol = whereXcol_array[0];
      whereXtype = whereXtype_array[0];
      varmap = varmap_array[0];
      for (i=0; i<runvars; i++) boundary_use[i] = boundary_hit[i] = 0;
      if (binit==1) {
	if (dobig==0) {
	  return;
	}
	fprintf(output,"initializing BIG population\n");
	binit = 0;
      }
      if (converged_flag <= 0) fprintf(output,"trying BIGGER population\n");
      holdcontrol = whichcontrol;
      whichcontrol = 1;
      genoud();
      whichcontrol = holdcontrol;
    }
    if (boundary_flag == hflag || converged_flag > 0)
      break;
  }
  runvars = runvars_array[0];
  whereXrow = whereXrow_array[0];
  whereXcol = whereXcol_array[0];
  whereXtype = whereXtype_array[0];
  varmap = varmap_array[0];
  if (ibeta==0 && converged_flag>0 && converged_flag < runvars)
    for (i=0; i<runvars; i++)
      if (boundary_hit[i]==1 && whereXtype[i]==PSI) {
	converged_flag *= (-1);
	break;
      }
  if (dumpflag == 1) {
    record[M(number,nparms+3,nparms+OFFSET)]=(double) converged_flag;
    if (converged_flag < 0) {
      fprintf(output,"CONVERGENCE FAILED (%d)\n", number);
    }
    if (converged_flag < -1) {
      fprintf(output,"convergence failed due to psi=0 (%d)\n", number);
    }
  }
}

void glisrelbca(double **fullsampledata, double **weightdata,
		unsigned short int **bootdata,
		int numobs, int nboots, int novars, int nparms,
		int ngroups, int *numobsv, int *novarsv)
{
  extern short int runcovflag, jacks, dobig, covmatrix;
  extern int *caseuse;
  extern long int number;
  extern double *record;
  extern double **data, **wdata;
  extern int whichcontrol, reset_from_X, converged_flag, doing;
  extern long int jacknumber, bootnumber;
  extern char recordfilename[MAXPATH];
  extern char listfile[MAXPATH];
  extern short int record_dumptrigger;
  extern FILE *flistfile;

  static struct NormalAsy *NAstruct;  

  int k, jj;
  int holdwhich;
  long int pointrow, pointcol, i;

  /* initially set the number of cases to use to all cases */
  for (k=0; k<ngroups; k++) caseuse[k] = numobsv[k];

  /* to send the full sample */
  whichcontrol = 0;
  doing=0;
  fprintf(output,"\nTHIS IS THE FULL SAMPLE\n");
  runcovflag=0;
  number=0;
  record[M(number,nparms+1,nparms+OFFSET)]=0.0;
  record[M(number,nparms+2,nparms+OFFSET)]=(double) number;
  record[M(number,nparms+4,nparms+OFFSET)]=(double) number;

  for (k=0; k<ngroups; k++) {
    for (pointrow=0;pointrow<caseuse[k];pointrow++) {
      for (pointcol=0;pointcol<novarsv[k];pointcol++) {
	data[k][M(pointrow, pointcol, novarsv[k])]=
	  fullsampledata[k][M(pointrow,pointcol, novarsv[k])];
      }
    }
    if (weightflag==1) {
      for (pointrow=0;pointrow<caseuse[k];pointrow++) {
	wdata[k][pointrow] = weightdata[k][pointrow];
      }
    }
  }

  /* initialize all the GA populations in the full sample */
  holdwhich = whichcontrol;
  for (i=0; i<NUMCONTROLS; i++) {
    whichcontrol = i; 
    if (i==0) {
      fprintf(output,"Initializing Control Files: %s then %s\n",
	     control_filename[i], control_filename[i+1]);
      rungen(1, nparms, 0, 1);
      fflush(output);
      if (dobig==0) whichcontrol=0;
      if((flistfile = fopen(listfile, "a+")) == NULL) {
	fprintf(output,"WARNING: cannot reopen file:  %s\n", listfile);
	fprintf(stderr,"WARNING: cannot reopen file:  %s\n", listfile);
      }
      NAstruct = Normal_SEs();  /* compute Normal-theory standard errors */
      PrintNormalSEs(NAstruct,output);  /* print MLEs, SEs, confidence ints. */
      PrintNormalSEs(NAstruct,flistfile);  /* print MLEs, SEs, confidence ints. */
      if (covmatrix==1) {
	PrintNormalCovmat(NAstruct,output);  /* print asymptotic covariance matrix */
	PrintNormalCovmat(NAstruct,flistfile);  /* print asymptotic covariance matrix */
      }
      if (dobig==0){
	printspecs(2,0);
	fclose(flistfile);
	fclose(output);
	exit(0);
      }
      if (jacks==0) {
	printspecs(2,0);
	fclose(flistfile);
	fclose(output);
	exit(0);
      }
      fclose(flistfile);
      fprintf(output,"\n\n*********************************************************************************\n\n");
    }
    else if (i>1) {
      fprintf(output,"Initializing Control File: %s\n", control_filename[i]);
      rungen(0, nparms, 2, 0);
    }
  }
  whichcontrol = holdwhich;  /* restore to fullsample population */
  /* end of sending the full sample */

  if (record_dumptrigger==1)
    record_dump(record, nparms, recordfilename, 0);

  if (record[M(0, nparms+3,nparms+OFFSET)]<=-1.0) {
    fprintf(output,"WARNING: Problem with Full Sample Convergence\n");
  }

  /* to run the jackknifes */
  if (jacks==1) {
    jacknumber=0;
    for (k=0; k<ngroups; k++) {
      caseuse[k] -= 1;
      whichcontrol = 2;
      doing=1;
      for (jj=0; jj<caseuse[k]+1; jj++, jacknumber++) {
	runcovflag=0;
	number++;
	if (jacknumber==0) {
	  for (i=0, pointrow=1; pointrow<numobsv[k]; pointrow++) {
	    for (pointcol=0; pointcol<novarsv[k]; pointcol++) {
	      data[k][M(i, pointcol, novarsv[k])]=
		fullsampledata[k][M(pointrow,pointcol, novarsv[k])];
	    }
	    if (weightflag==1) wdata[k][i] = weightdata[k][pointrow];
	    i++;
	  }
	}
	else {
	  i = jj-1;
	  for (pointcol=0; pointcol<novarsv[k]; pointcol++) {
	    data[k][M(i, pointcol, novarsv[k])] =
	      fullsampledata[k][M(i,pointcol, novarsv[k])];
	  }
	  if (weightflag==1) wdata[k][i] = weightdata[k][i];
	}
	if (record[M(number,nparms+4,nparms+OFFSET)]==0.0
	    || record[M(number,nparms+3,nparms+OFFSET)] <= 0.0) {
	  if (record[M(number,nparms+3,nparms+OFFSET)] < -1.0) {
	    fprintf(output,"Jackknife #%d already in Record File and Converged Unidentified\n",
		    jacknumber+1);
	  }
	  else {
	    if (record[M(number,nparms+3,nparms+OFFSET)] == -1.0) {
	      fprintf(output,"Jackknife #%d already in Record File but not Converged\n",
		      jacknumber+1);
	    }
	    record[M(number,nparms+1,nparms+OFFSET)]=1.0;
	    record[M(number,nparms+2,nparms+OFFSET)]=(double) jacknumber;
	    record[M(number,nparms+4,nparms+OFFSET)]=(double) number;
	    fprintf(output,"\nTHIS IS JACKKNIFE NUMBER:%i\n",jacknumber+1);
	    rungen(0, nparms, 2, 1);
	  }
	}
	else {
	  fprintf(output,"Jackknife #%d Already in Record File and Converged\n",jacknumber+1);
	}
	if (record_dumptrigger==1)
	  record_dump(record, nparms, recordfilename, number);
      }
      i = caseuse[k];
      for (pointcol=0; pointcol<novarsv[k]; pointcol++) {
	data[k][M(i, pointcol, novarsv[k])] =
	  fullsampledata[k][M(i,pointcol, novarsv[k])];
      }
      if (weightflag==1) wdata[k][i] = weightdata[k][i];
      caseuse[k] += 1;
      /* end of jackknifes */
    }
  }
  else { fprintf(output,"NO JACKKNIFES TO BE DONE\n"); }

  /* bootstrap */
  whichcontrol = 3;
  doing=2;
  for (bootnumber=0; bootnumber<nboots; bootnumber++) {
    runcovflag=0;
    number++;
    if (record[M(number,nparms+4,nparms+OFFSET)]==0.0
	|| record[M(number,nparms+3,nparms+OFFSET)] <= 0.0) {
      if (record[M(number,nparms+3,nparms+OFFSET)] < -1.0) {
	fprintf(output,"Bootnumber #%d already in Record File and Converged Unidentified\n",
		bootnumber+1);
      }
      else {
	if (record[M(number,nparms+3,nparms+OFFSET)] == -1.0) {
	  fprintf(output,"Bootnumber #%d already in Record File but not Converged\n",
		  bootnumber+1);
	}
	record[M(number,nparms+1,nparms+OFFSET)]=2.0;
	record[M(number,nparms+2,nparms+OFFSET)]=(double) bootnumber;
	record[M(number,nparms+4,nparms+OFFSET)]=(double) number;
	fprintf(output,"\nTHIS IS BOOTSTRAP NUMBER:%i\n",bootnumber+1);

	for (k=0; k<ngroups; k++) {
	  for (pointrow=0;pointrow<caseuse[k];pointrow++) {
	    for (pointcol=0;pointcol<novarsv[k];pointcol++) {
	      data[k][M(pointrow, pointcol, novarsv[k])]=
		fullsampledata[k][M(bootdata[k][bootnumber*caseuse[k]+pointrow],
				 pointcol, novarsv[k])];
	    }
	  }
	  if (weightflag==1) {
	    for (pointrow=0;pointrow<caseuse[k];pointrow++) {
	      wdata[k][pointrow] =
		weightdata[k][bootdata[k][bootnumber*caseuse[k]+pointrow]];
	    }
	  }
	}
	rungen(0, nparms, 2, 1);
      }
    }
    else {
      fprintf(output,"Bootnumber #%d Already in Record File and Converged\n",bootnumber+1);
    }
    if (record_dumptrigger==1)
      record_dump(record, nparms, recordfilename, number);
  }
  /* end of bootstrap runs */

} /*end glisrelbca */
