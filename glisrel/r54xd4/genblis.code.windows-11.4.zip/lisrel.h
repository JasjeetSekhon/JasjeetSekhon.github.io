/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/


/* @(#)lisrel.h	11.4   7/23/98 */

double lisrel(double *X);
void invert_by_block(double *mat, double *imat, double *wrk, int *indx,
		     double *wrkcol, int msize, int nblocks, int *bsizev);
double det_by_block(double *mat, double *wrk, int *indx, int msize, int nblocks,
		    int *bsizev);
void lischolesky (double *psic, double *psi, int nrow, int *nullity);
void lischol2cov(double *psic, double *psi, int nrow, int uplow);
void set_structures(double *X);
double fcov(void);
double fcrossp(void);
double fcorr(void);
double fwcov(void);
double fwcrossp(void);
double fwcorr(void);
