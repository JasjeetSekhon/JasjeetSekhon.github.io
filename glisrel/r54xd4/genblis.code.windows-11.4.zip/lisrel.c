/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/


#include "data.h"
#include "genoud.h"
#include "lisrel.h"
#include "bfgs.h"
#include "multi.h"
#include "inverse.h"

static char *sccsversion = "@(#)lisrel.c	11.4   7/23/98";

#define BAD_FIT_VALUE 9999.9

double lisrel(double *X)
{
  extern short int runcovflag;
  extern int usecovflag, usecrosspflag, usecorrflag, weightflag;
  extern double *cov, *sigma, *inverse_sigma;
  extern short int stepcheck;
  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
  extern int observedy, latenty, runvars, runcases;
  extern int rungroups, *observedyv;
  extern int ipsi_diag, psizeros;

  static int firsttime=0;

  /*
     p=oy          m=ly
     q=ox          n=lx
     */

  static double fml3;

  /* for checking positive definiteness of covariance matrix psi */
  int nullity = 0;

  double fml, fml1, fml2;

  int ink, outrowcol[2], nextinrow, nextincol, sigma1row,
  sigma1col, sigma1arow, sigma1acol, sigma1brow, sigma1bcol;

  int sigma2row, sigma2col, sigma3row, sigma3col, sigma4row, sigma4col;

  int i,j, idx;
  int k, offset, oyk;

  /* read stuff */
  int cases;
  char ch;

/* new variables declarations */
  int
    size1 = runvars*runcases,
    size2 = observedy*observedy+observedy,
    size3 = observedy*latenty,
    size4 = latenty*latenty;

  static int *indx;

  static double
    d, *col, *sigma1, *sigma1a, *sigma1b, *sigma2, *sigma3, *sigma4,
    *trash, *trash2, *trash3, *fmlm2, *psic;

  static double *t_lambda_y, *t_inverse_sub_beta, *sub_beta, *inverse_sub_beta;

  if (firsttime==0) {
    /* start vars */
    indx = (int *) malloc((size3+1)*sizeof(int));
    col = (double *) malloc((size3+1)*sizeof(double));
    sigma = (double *) malloc((size2)*sizeof(double));
    sigma1 = (double *) malloc((size2)*sizeof(double));
    sigma1a = (double *) malloc((size2)*sizeof(double));
    sigma1b = (double *) malloc((size2)*sizeof(double));
    sigma2 = (double *) malloc((size2)*sizeof(double));
    sigma3 = (double *) malloc((size2)*sizeof(double));
    sigma4 = (double *) malloc((size2)*sizeof(double));
    trash = (double *) malloc((size1)*sizeof(double));
    trash2 = (double *) malloc((size1)*sizeof(double));
    trash3 = (double *) malloc((size1)*sizeof(double));
    fmlm2 = (double *) malloc((size2)*sizeof(double));
    inverse_sigma = (double *) malloc((size2)*sizeof(double));
    psic = (double *) malloc(((size4)+(latenty))*sizeof(double));
    t_lambda_y = (double *) malloc(((size3)+(observedy))*sizeof(double));
    t_inverse_sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));
    sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));
    inverse_sub_beta = (double *) malloc(((size4)+(latenty))*sizeof(double));

    for (i=0; i<size2; i++) inverse_sigma[i] = 0.0;

    firsttime=1;
  }

  if (runcovflag!=9) {
    runcovflag=9;
    
    if (weightflag==1) {
      if (usecovflag==1) fwcov();
      else if (usecrosspflag==1) fwcrossp();
      else if (usecorrflag==1) fwcorr();
    }
    else {
      if (usecovflag==1) fcov();
      else if (usecrosspflag==1) fcrossp();
      else if (usecorrflag==1) fcorr();
    }
    
    d = det_by_block(cov,trash,indx,observedy,rungroups,observedyv);
    fml3=log(d);
    
  } 

  set_structures(X);


  /* check variance parameters:
     if any variance parameter is negative, return bad value */
  for (i=0;i<observedy;i++) {
    if (theta_epsilon[M(i,i,observedy)] < 0.0) {
/*      fprintf(output,"variance of theta_epsilon < 0.0 BAD FIT\n"); */
      return(BAD_FIT_VALUE+3);
    }
  }
  for (i=0;i<latenty;i++) {
    if (psi[M(i,i,latenty)] < 0.0)  {
/*      fprintf(output,"variance of psi < 0.0 BAD FIT\n"); */
      return(BAD_FIT_VALUE+2);
    }
  }

/*
  fprintf(output,"printing psi\n");
  for (i=0; i<latenty; i++) {
    for (j=0; j<latenty; j++) {
      fprintf(output,"%6.3f ", psi[M(i,j,latenty)]);
    }
    fprintf(output,"\n");
  }
*/

  /* use cholesky decomposition to check positive semidefiniteness of psi */
  lischolesky(psic, psi, latenty, &nullity);
  if (nullity > latenty-ipsi_diag + psizeros) {
    return(BAD_FIT_VALUE+1);
  }
/*  if (nullity != 0) return(BAD_FIT_VALUE); */

  /* THE SIGMA MATRIX PUT TOGETHER STUFF */
  /* to get inverse beta made */
  subtract(identity_beta, beta, sub_beta, latenty, latenty);
  copy(sub_beta,trash,latenty,latenty);
  ludcmp(trash,latenty,indx,&d);
  for (j=0;j<latenty;j++) {
    for(i=0;i<latenty;i++) col[i]=0.0;
    col[j]=1.0;
    lubksb(trash,indx,col,latenty);
    for(i=0;i<latenty;i++) inverse_sub_beta[M(i,j,latenty)]=col[i];
  } 
  /* inverse beta is made! */

  /* THE TRANSPOSES */
  transpose(lambda_y, t_lambda_y, observedy, latenty);
  transpose(inverse_sub_beta,t_inverse_sub_beta,latenty,latenty); 

  /* BUILD SIGMA1 */
  /* build sigma 1a */
  multi(lambda_y,inverse_sub_beta,sigma1a,observedy,latenty,latenty,latenty,outrowcol);
  sigma1arow=outrowcol[0];
  sigma1acol=outrowcol[1];
  /* sigma 1a built */

  /* build sigma 1b */
  /* sigma 1b built */

  multi(sigma1a, psi, trash, sigma1arow, sigma1acol, latenty,
	latenty, outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  multi(trash, t_inverse_sub_beta, trash2, sigma1row, sigma1col, latenty, latenty,
	outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  multi(trash2, t_lambda_y, trash3, sigma1row, sigma1col, latenty, observedy, outrowcol);
  sigma1row=outrowcol[0];
  sigma1col=outrowcol[1];
  add(trash3, theta_epsilon, sigma, observedy, observedy);
  /* SIGMA 1 IS DONE */


  /* use cholesky decomposition to check positive definiteness of sigma */
  lischolesky(sigma1, sigma, observedy, &nullity);
  if (nullity != 0) { 
    /* fprintf(output,"sigma not positive definite BAD FIT\n"); */
    return(BAD_FIT_VALUE+10); 
  }

  /* DO THE FML THING */
  /* inverse sigma */
  invert_by_block(sigma,inverse_sigma,trash,indx,col,observedy,rungroups,observedyv);

  /* Test for Sigma being having no negative variances */
  for (j=0;j<observedy;j++) {
    if (sigma[M(j,j,observedy)] < 0.0) {
      /*      fprintf(output,"SIGMA HAS ONE OR MORE NEGATIVE VARIANCES\n"); */
      return(BAD_FIT_VALUE+20);
    }
  }

  /* the fml thing */
  d = det_by_block(sigma,trash,indx,observedy,rungroups,observedyv);
  if (d <= 0) {
/*    fprintf(output,"d is <= 0, BAD FIT\n");
    fprintf(output,"d=%lf\n",d); */
    /*  stepcheck=1; */
    return(BAD_FIT_VALUE+30);
  } 
  if (d > 0) {
    fml1=log(d);
    for (offset=0, k=0; k<rungroups; k++) {
      oyk = observedyv[k];
      submulti(cov,inverse_sigma,fmlm2,
	       offset, offset+oyk, offset, offset+oyk, observedy,
	       offset, offset+oyk, offset, offset+oyk, observedy,
	       offset, offset, observedy);
      offset += oyk;
    }
    fml2=trace(fmlm2, observedy);
    fml=fml1+fml2-fml3-observedy;
    /*  fprintf(output,"\nFML1=%10.5fl FML2=%10.5fl FML3=%10.5fl FML=%10.5fl\n",
        fml1, fml2, fml3, fml); */
    
    if (fml <= 0) {
/*      fprintf(output,"\n LISREL STPSIZE FLAG (fmml<=0)\n"); */
      /*    stepcheck=1; */
      return(BAD_FIT_VALUE+40);
    }

    return(fml);
  }

} /* function end */


/* invert block-diagonal matrix mat block-by-block, into imat */
void invert_by_block(double *mat, double *imat, double *wrk, int *indx,
		     double *wrkcol, int msize, int nblocks, int *bsizev)
{
  int i, j, k, bsize, offset;
  double d;

  for (offset=0, k=0; k<nblocks; k++) {
    bsize = bsizev[k];
    copy2(mat, msize, offset, wrk, bsize, bsize);
    ludcmp(wrk,bsize,indx,&d);
    for (j=0;j<bsize;j++) {
      for(i=0;i<bsize;i++) wrkcol[i]=0.0;
      wrkcol[j]=1.0;
      lubksb(wrk,indx,wrkcol,bsize);
      for(i=0;i<bsize;i++) imat[M(i+offset,j+offset,msize)]=wrkcol[i];
    }
    offset += bsize;
  }
}

/* determinant of block-diagonal matrix mat */
double det_by_block(double *mat, double *wrk, int *indx, int msize, int nblocks,
		    int *bsizev)
{
  int j, k, bsize, offset;
  double dk, d=1.0;

  for (offset=0, k=0; k<nblocks; k++) {
    bsize = bsizev[k];
    copy2(mat, msize, offset, wrk, bsize, bsize);
    ludcmp(wrk, bsize, indx, &dk);
    for(j=0;j<bsize;j++) dk*= wrk[M(j,j,bsize)];
    d *= dk;
    offset += bsize;
  }
  return d;
}

#define TOOSMALL ((double) 1.0e-15)
void lischolesky (double *psic, double *psi, int nrow, int *nullity)
{
  int i, j, k, row;
  double sum;

  *nullity = 0;
  for (row=0; row<nrow; row++) {
    /* First compute psic[M(row,row,nrow)] */
    sum = psi[M(row,row,nrow)];
    for (j=0; j<row; j++) sum -= psic[M(j,row,nrow)]*psic[M(j,row,nrow)];
    if (sum > TOOSMALL) {
      psic[M(row,row,nrow)] = sqrt(sum);
      /* Now find elements psic[M(row,k,nrow)], k > row. */
      for (k=(row+1); k<nrow; k++) {
	sum = psi[M(row,k,nrow)];
	for (j=0; j<row; j++) 
	  sum -= psic[M(j,row,nrow)]*psic[M(j,k,nrow)];
	psic[M(row,k,nrow)] = sum/psic[M(row,row,nrow)];
      }
    }
    else {  /* blast off the entire row. */
      for (k=row; k<nrow; k++) psic[M(row,k,nrow)] = 0.0;
      (*nullity)++;
    }
  }
}

void lischol2cov(double *psic, double *psi, int nrow, int uplow)
{
  int i,j,k;

  if (uplow == 0) {  /* cholesky decomposition is in the lower triangle */
    for (i=0; i<nrow; i++)
      for (j=0; j<=i; j++) {
	psi[M(i,j,nrow)] = 0.0;
	for (k=0; k<=j; k++)
	  psi[M(i,j,nrow)] += psic[M(i,k,nrow)] * psic[M(j,k,nrow)];
	if (i != j) psi[M(j,i,nrow)] = psi[M(i,j,nrow)];
      }
  }
  else {
    for (i=0; i<nrow; i++)
      for (j=0; j<=i; j++) {
	psi[M(i,j,nrow)] = 0.0;
	for (k=0; k<=j; k++)
	  psi[M(i,j,nrow)] += psic[M(k,i,nrow)] * psic[M(k,j,nrow)];
	if (i != j) psi[M(j,i,nrow)] = psi[M(i,j,nrow)];
      }
  }
}


void set_structures(double *X)
{
  extern double *lambda_y, *theta_epsilon, *beta, *identity_beta, *psi;
  extern int observedy, latenty, runvars;

  extern int *whereXrow, *whereXcol, *whereXtype;
  extern int runvars_array[MAXBOUNDHITS+1];
  extern int *whereXrow_array[MAXBOUNDHITS+1], *whereXcol_array[MAXBOUNDHITS+1];
  extern int *whereXtype_array[MAXBOUNDHITS+1];
  extern int *varmap, *varmap_array[MAXBOUNDHITS+1];
  extern int *boundary_hit;
  extern int start_fcov, end_fcov, start_psi, end_psi, fcov_vars;
  extern double *cov;
  extern int equality_constraints;
  extern int *equal_lambda_row, *equal_lambda_col, *equal_beta_row, *equal_beta_col,
    *equal_psi_row, *equal_psi_col, *equal_theta_row, *equal_theta_col;

  int m, i, j, i1, i2, j1, j2;

  for (i=0; i<runvars_array[0]; i++)
    if (boundary_hit[i]==1 && whereXrow_array[0][i]==whereXcol_array[0][i]) {
      j = whereXrow_array[0][i];
      switch (whereXtype_array[0][i]) {
      case THETAEPS:
	theta_epsilon[M(j,j,observedy)]=0.0;
	break;
      case PSI:
	psi[M(j,j,latenty)]=0.0;
	break;
      default:
	break;
      }
    }

  for (i=0; i<runvars; i++)
    switch (whereXtype[i]) {
    case LAMBDAY:
      lambda_y[M(whereXrow[i],whereXcol[i],latenty)]=X[i];
      break;
    case THETAEPS:
      theta_epsilon[M(whereXrow[i],whereXcol[i],observedy)]= X[i];
      theta_epsilon[M(whereXcol[i],whereXrow[i],observedy)]= X[i];
      break;
    case BETA:
      beta[M(whereXrow[i],whereXcol[i],latenty)]=X[i];
      break;
    case PSI:
      psi[M(whereXrow[i],whereXcol[i],latenty)]=X[i];
      psi[M(whereXcol[i],whereXrow[i],latenty)]=X[i];	
      break;
    default:
      break;
    }

  if (fcov_vars > 0) {
    m = end_psi - start_psi ;
    for (i=0; i<=m; i++) {
      i1 = start_psi + i;
      i2 = start_fcov + i;
      psi[M(i1,i1,latenty)] = cov[M(i2,i2, observedy)];
      for (j=0; j<i; j++) {
	j1 = start_psi + j;
	j2 = start_fcov + j;
	psi[M(i1,j1,latenty)] = cov[M(i2,j2, observedy)];
	psi[M(j1,i1,latenty)] = cov[M(j2,i2, observedy)];
      }
    }
  }

  if (equality_constraints > 0) {
    for (i=0; i<observedy; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_lambda_row[i] != (MAXPARMS+1)
	    && equal_lambda_col[j] != (MAXPARMS+1)) {
	  lambda_y[M(i, j, latenty)] =
	    lambda_y[M(equal_lambda_row[i],equal_lambda_col[j],latenty)];
	}
      }
      for (j=0; j<observedy; j++) {
	if (equal_theta_row[i] != (MAXPARMS+1)
	    && equal_theta_col[j] != (MAXPARMS+1)) {
	  theta_epsilon[M(i, j, observedy)] =
	    theta_epsilon[M(equal_theta_row[i],equal_theta_col[j],observedy)];
	}
      }
    }
    for (i=0; i<latenty; i++) {
      for (j=0; j<latenty; j++) {
	if (equal_beta_row[i] != (MAXPARMS+1)
	    && equal_beta_col[j] != (MAXPARMS+1)) {
	  beta[M(i, j, latenty)] =
	    beta[M(equal_beta_row[i],equal_beta_col[j],latenty)];
	}
	if (equal_psi_row[i] != (MAXPARMS+1)
	    && equal_psi_col[j] != (MAXPARMS+1)) {
	  psi[M(i, j, latenty)] =
	    psi[M(equal_psi_row[i],equal_psi_col[j],latenty)];
	}
      }
    }
  }


/*
  for (i=0; i<runvars; i++) {
    fprintf(output,"%s %d %d = ", parmsyms[whereXtype[i]], whereXrow[i], whereXcol[i]);
    switch (whereXtype[i]) {
    case LAMBDAY:
      fprintf(output,"%lf\n", lambda_y[M(whereXrow[i],whereXcol[i],latenty)]);
      break;
    case THETAEPS:
      fprintf(output,"%lf\n", theta_epsilon[M(whereXrow[i],whereXcol[i],observedy)]);
      break;
    case BETA:
      fprintf(output,"%lf\n", beta[M(whereXrow[i],whereXcol[i],latenty)]);
      break;
    case PSI:
      fprintf(output,"%lf\n", psi[M(whereXrow[i],whereXcol[i],latenty)]);
      break;
    default:
      fprintf(output,"\n");
      break;
    }
  }
*/

 
}


/* compute the covariance matrix for the current dataset, using observation
   count set in external variable caseuse */

double fcov(void)
{
  extern int *caseuse;
  extern double **data;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;

  static double *s, *ave; 
  static int firsttime=0;

  if (firsttime==0) {
    s = (double *) malloc((observedy)*sizeof(double));
    ave = (double *) malloc((observedy)*sizeof(double));
    firsttime=1;
  }

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    for (i=0;i<oyk;i++) {         /* the variable loop */
      s[i]=0.0;
      for (j=0; j<cuse;j++) s[i] += data[k][M(j,i,oyk)];
    } 

    for (i=0;i<oyk;i++) {
      ave[i]=s[i]/cuse;
    }

    /* to figure out the covariance */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)]-ave[i])*(data[k][M(h,j,oyk)]-ave[j]);
	}
      }
    }

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=
	  cov[M(i+offset,j+offset,observedy)]/(cuse-1);
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    fprintf(output,"Group %d variable, average, sum\n",k+1);
    for (i=0; i<oyk;i++) {
      fprintf(output,"var:%2i%15.5f%15.5f\n", i, ave[i], s[i]);
    }
    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n COVARIANCES\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fcov end */

/* compute the (mean) cross-products matrix for the current dataset,
   using observation count set in external variable caseuse */

double fcrossp(void)
{
  extern int *caseuse;
  extern double **data;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;

  static int firsttime=0;

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    /* compute the cross-products */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)])*(data[k][M(h,j,oyk)]);
	}
      }
    }

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=
	  cov[M(i+offset,j+offset,observedy)]/(cuse-1);
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n MEAN CROSS-PRODUCTS\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fcrossp end */

/* compute the covariance matrix for the current dataset, using observation
   count set in external variable caseuse */

double fcorr(void)
{
  extern int *caseuse;
  extern double **data;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;

  static double *s, *ave; 
  static int firsttime=0;

  /* compute the covariance matrix, then convert to correlation matrix */

  if (firsttime==0) {
    s = (double *) malloc((observedy)*sizeof(double));
    ave = (double *) malloc((observedy)*sizeof(double));
    firsttime=1;
  }

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    for (i=0;i<oyk;i++) {         /* the variable loop */
      s[i]=0.0;
      for (j=0; j<cuse;j++) s[i] += data[k][M(j,i,oyk)];
    } 

    for (i=0;i<oyk;i++) {
      ave[i]=s[i]/cuse;
    }

    /* to figure out the covariance */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)]-ave[i])*(data[k][M(h,j,oyk)]-ave[j]);
	}
      }
    }

    /* note:  does lower-triangle only */
    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=cov[M(i+offset,j+offset,observedy)]/(cuse-1);
      }
    }

    fprintf(output,"Group %d variable, average, sum\n",k+1);
    for (i=0; i<oyk;i++) {
      fprintf(output,"var:%2i%15.5f%15.5f\n", i, ave[i], s[i]);
    }
    offset += oyk;  /* update offset to shift to next block of the covariance matrix */
  }

  /* covariance matrix has been computed.  now compute correlation matrix */

  /* get inverse standard deviations from *cov */
  for (i=0;i<observedy;i++) {
    s[i] = 1.0/sqrt(cov[M(i,i,observedy)]);
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    /* convert *cov to correlation matrix in place */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)] *= s[i+offset]*s[j+offset];
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n CORRELATIONS\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fcorr end */

/* compute the covariance matrix for the current dataset, using observation
   count set in external variable caseuse -- weighted */

double fwcov(void)
{
  extern int *caseuse;
  extern double **data, **wdata;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;
  double wsum, iwsum;

  static double *s, *ave; 
  static int firsttime=0;

  if (firsttime==0) {
    s = (double *) malloc((observedy)*sizeof(double));
    ave = (double *) malloc((observedy)*sizeof(double));
    firsttime=1;
  }

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    for (i=0;i<oyk;i++) {         /* the variable loop */
      s[i]=0.0;
      for (j=0; j<cuse;j++) s[i] += data[k][M(j,i,oyk)] * wdata[k][j];
    } 
    for (wsum = 0.0, j=0; j<cuse;j++) wsum += wdata[k][j];
    iwsum = 1.0/wsum;

    for (i=0;i<oyk;i++) {
      ave[i]=s[i]*iwsum;
    }

    /* to figure out the covariance */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)]-ave[i])*(data[k][M(h,j,oyk)]-ave[j]) * wdata[k][h];
	}
      }
    }

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=
	  cov[M(i+offset,j+offset,observedy)]*iwsum;
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    fprintf(output,"Group %d variable, average, sum\n",k+1);
    for (i=0; i<oyk;i++) {
      fprintf(output,"var:%2i%15.5f%15.5f\n", i, ave[i], s[i]);
    }
    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n COVARIANCES\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fwcov end */

/* compute the (mean) cross-products matrix for the current dataset,
   using observation count set in external variable caseuse -- weighted */

double fwcrossp(void)
{
  extern int *caseuse;
  extern double **data, **wdata;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;
  double wsum, iwsum;

  static int firsttime=0;

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    /* compute the cross-products */

    for (wsum = 0.0, j=0; j<cuse;j++) wsum += wdata[k][j];
    iwsum = 1.0/wsum;

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)])*(data[k][M(h,j,oyk)]) * wdata[k][h];
	}
      }
    }

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=
	  cov[M(i+offset,j+offset,observedy)]*iwsum;
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n MEAN CROSS-PRODUCTS\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fwcrossp end */

/* compute the covariance matrix for the current dataset, using observation
   count set in external variable caseuse -- weighted */

double fwcorr(void)
{
  extern int *caseuse;
  extern double **data, **wdata;
  extern double *cov;
  extern int rungroups;
  extern int observedy;
  extern int *observedyv;
  int j, i, h, k, jtop, cuse, oyk, offset;
  double wsum, iwsum;

  static double *s, *ave; 
  static int firsttime=0;

  /* compute the covariance matrix, then convert to correlation matrix */

  if (firsttime==0) {
    s = (double *) malloc((observedy)*sizeof(double));
    ave = (double *) malloc((observedy)*sizeof(double));
    firsttime=1;
  }

  /* set sum and cov to 0 */
  for (i=0;i<observedy;i++) {
    for (j=0;j<observedy;j++) {
      cov[M(i,j,observedy)]=0.0;
    }
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    for (i=0;i<oyk;i++) {         /* the variable loop */
      s[i]=0.0;
      for (j=0; j<cuse;j++) s[i] += data[k][M(j,i,oyk)] * wdata[k][j];
    } 

    for (wsum = 0.0, j=0; j<cuse;j++) wsum += wdata[k][j];
    iwsum = 1.0/wsum;

    for (i=0;i<oyk;i++) {
      ave[i]=s[i]*iwsum;
    }

    /* to figure out the covariance */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	for (h=0;h<cuse;h++) {
	  cov[M(i+offset,j+offset,observedy)] +=
	    (data[k][M(h,i,oyk)]-ave[i])*(data[k][M(h,j,oyk)]-ave[j]) * wdata[k][h];
	}
      }
    }

    /* note:  does lower-triangle only */
    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)]=
	  cov[M(i+offset,j+offset,observedy)]*iwsum;
      }
    }

    fprintf(output,"Group %d variable, average, sum\n",k+1);
    for (i=0; i<oyk;i++) {
      fprintf(output,"var:%2i%15.5f%15.5f\n", i, ave[i], s[i]);
    }
    offset += oyk;  /* update offset to shift to next block of the covariance matrix */
  }

  /* covariance matrix has been computed.  now compute correlation matrix */

  /* get inverse standard deviations from *cov */
  for (i=0;i<observedy;i++) {
    s[i] = 1.0/sqrt(cov[M(i,i,observedy)]);
  }

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    cuse = caseuse[k];

    /* convert *cov to correlation matrix in place */

    for (i=0;i<oyk;i++) {
      jtop=i;
      for (j=0;j<=jtop;j++) {
	cov[M(i+offset,j+offset,observedy)] *= s[i+offset]*s[j+offset];
	cov[M(j+offset,i+offset,observedy)]=cov[M(i+offset,j+offset,observedy)];
      }
    }

    offset += oyk;  /* update offset to shift to next block of the matrix */
  }

  fprintf(output,"\n CORRELATIONS\n");

  offset=0;
  for (k=0; k<rungroups; k++) {
    oyk = observedyv[k];
    fprintf(output,"Group %d\n",k+1);
    for (i=0; i<oyk;i++) {
      for (j=0; j<oyk;j++) {
	fprintf(output,"%6.3f ", cov[M(i+offset,j+offset,observedy)]);
      }
      fprintf(output,"\n");
    }
    offset += oyk;
  }

} /* fwcorr end */
