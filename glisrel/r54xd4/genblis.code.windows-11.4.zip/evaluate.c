/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html


   Some of the code in this file was adapted from an early version of
   GENOCOP I (Zbigniew Michalewicz, zbyszek@uncc.edu).  For information
   about GENOCOP III please see
   http://www.coe.uncc.edu/~gnazhiya/gchome.html.
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



#include "data.h"
#include "genoud.h"
#include "genetic.h"
#include "init.h"
#include "lisrel.h"
#include "gradient.h"
#include "bfgs.h"
#include "operators.h"
#include "evaluate.h"

static char *sccsversion = "@(#)evaluate.c	11.4   7/23/98";

#if DOS_SYS
extern FILE *input,*output;
#endif

/* Cummulative probability on crossover */
/* Random probability on mutation       */


void optimization(VECTOR X, IVECTOR x1, IVECTOR x2, MATRIX fin_mat, INDEX rc,
	 int tot_eq, VECTOR a1_b, MATRIX domains)
{
  extern struct optcontrol *octrl;  /* ptr to values read from control file */

  extern int observedy, latenty, runvars, runcases, runboots,
    run_nochange_lim, run_notdone_lim;

  extern double *record;
  extern long int number;
  extern int reset_from_X;
  extern int converged_flag;

  extern struct optimobjs objs[NUMOFMODELS];
  extern int firsttime_o[NUMOFMODELS];
  extern int whichcontrol;
  extern long int jacknumber, bootnumber;
  extern doing;
  

  /* this structure is used to avoid reallocating storage for each resample */
  struct optimobjs *objsp;

  MATRIX new_genera,   /*Temporary storage for the new generation*/
         population,   /*Population of x2 variables*/
         print_pop,
         temp;

  VECTOR probab,       /*Probability of agents to die or live*/
         cum_probab,   /*Cumilative probability of agents*/
         t_vec;

  IVECTOR
    live,
    parents;     /*Indexes of the x2_vari parents for crossover*/

  unsigned long generations;    /*Total number of Generations (changed in run)*/
  unsigned long count_gener= 1; /*Counter to keep track of the number of generations*/
  unsigned long peak_cnt;

  int pop_size,              /*Population size*/
    MinMax,                /*Minimization or Maximization problem 0 or 1 */
    P,                     /*Total number of agents chosen to reproduce*/
    P1,                    /*Number of parents for each of the 8 operators*/
    P2,
    P3,
    P4,
    P5,
    P6,
    P7,
    P8,
    j1,
    j2,
    j3,
    j4,
    j5,
    j6,
    j7,
    j8,
    oper,
    ocnt,
    B,                     /*Parameter for the 3rd operator - nonuniform mutation*/
    STEP,                  /*Parameter for the 5th operator - simple arithmetical crossover*/
    x2_vari = rc.c-2,
    first,                 /*Index of the parent to mutate*/
    first_live,            /*Index of the two parents for crossover parents*/
    second_live,
    first_die,             /*Index of the two parents for crossover death*/
    second_die,
    die_now,               /*index of agent to replace in current operation*/
    tot,                   /*total number of chosen parents not used*/
    p2use,
    i,
    j,
    k;

  double Q,                   /*Probability of the best agent*/
        A,                   /*Parameter for the 4th operator - whole arithmetical cross over*/
        Teval,               /*Evaluation of the best agent*/
        initial_val;         /*Initial value of the population */
  double peak_val;
  int x,y;

  FLAG  same;
  double**new;

  int modi;
  double diff = 0.0;
  int nochange_gen;
  double oldfitvalue;

  int gradient_tolerance;
  double gradtol, mgradtol;

  int evaliter, hflag, btest, ii, boundary, runvars0;
  double bfgsfit, evalgtol, bfgs_portion, portion;

  extern short int starting_values, use_boundary;
  extern double *initial_values;

  static double *grad, *evalX, *finalhessin, *bfgsoutX, *work;
  static int firsttime = 0;

  if (firsttime==0) {
    grad = (double *) malloc((runvars)*sizeof(double));
    evalX = (double *) malloc((runvars)*sizeof(double));
    finalhessin = (double *) malloc(((runvars*runvars)+(runvars))*sizeof(double));
    bfgsoutX = (double *) malloc((runvars+1)*sizeof(double));
    work = (double *) malloc((runvars+1)*sizeof(double));
    firsttime =1;
  }

  nochange_gen=0;

#define MODISTEP 19
  modi=MODISTEP;
  
  /* get the population configuration information in *octrl */
  pop_size = octrl->pop_size;
  generations = octrl->genbound;
  P1 = octrl->P1;
  P2 = octrl->P2;
  P3 = octrl->P3;
  P4 = octrl->P4;
  P5 = octrl->P5;
  P6 = octrl->P6;
  P7 = octrl->P7;
  P8 = octrl->P8;
  Q = octrl->Q;
  MinMax = octrl->MinMax;
  B = octrl->B;
  STEP = octrl->STEP;
  portion = octrl->portion;
  gradtol = octrl->gradtol;
  mgradtol = -gradtol;

  /* make sure P4, P5, P7 are even numbers */
  i = P4 / 2;
  if (P4 != i*2) P4++;
  i = P5 / 2;
  if (P5 != i*2) P5++;
  i = P7 / 2;
  if (P7 != i*2) P7++;

  /*P is the total number of parents needed for applying all the operators*/
  P = P1 + P2 + P3 + P4 + P5 + P6 + P7 + P8;
  if(P >= pop_size) pop_size = P + 1;

  peak_val = 0;
  peak_cnt = 0;

  /*Space allocation for all the vectors and matrices involved*/
  objsp = objs + whichcontrol;  /* choose structure for specified control parms */
  if (firsttime_o[whichcontrol] == 0) {
    objsp->population = matrix(1,pop_size,0,x2_vari+1);
    objsp->print_pop  = matrix(1,pop_size,0,x2_vari+tot_eq+1);
    objsp->new_genera = matrix(1,pop_size,0,x2_vari+1);
    objsp->temp       = matrix(1,x2_vari>2?x2_vari:2,1,x2_vari);
    objsp->probab     = vector(1,pop_size);
    objsp->t_vec      = vector(1,x2_vari);
    objsp->cum_probab = vector(1,pop_size);
    objsp->live       = ivector(1,pop_size);
    objsp->parents    = ivector(1,x2_vari);

    firsttime_o[whichcontrol] = 1;
  }
  /* get local objects from values saved in structure objs */
  population = objsp->population;
  print_pop  = objsp->print_pop;
  new_genera = objsp->new_genera;
  temp       = objsp->temp;
  probab     = objsp->probab;
  t_vec      = objsp->t_vec;
  cum_probab = objsp->cum_probab;
  live       = objsp->live;
  parents    = objsp->parents;

  /* save on-entry on-boundary indicator vector */
  hflag = boundary_flag;
  /* save number of parms in no-boundary-hit problem */
  runvars0 = runvars_array[0];

  /* The new initial value matrix: set a new initial value for every individual */
  if (constrained_flag == 1) {
    /* use starting values or record[number] for 3/4 population, others random */
    k = 1 + pop_size - pop_size/4;

    for (ii=0, i=1; i<= x2_vari; i++, ii++) {
      while (boundary_use[varmap[ii]]==1) ii++;
      population[1][i] = record[M(number,varmap[ii]+1,runvars0+OFFSET)];
    }
    population[1][x2_vari+1] = 1.0;
    for(j=2; j<k; j++) {
      if (starting_values == 1 && j % 2 == 0)
	for(i=1; i<=x2_vari; i++) { 
	  population[j][i] = initial_values[i-1];
	}
      else
	for (i=1; i<=x2_vari; i++) {
	  population[j][i] = population[1][i];
	}
      population[j][x2_vari+1] = 1.0;
    }
    for(j=k; j<=pop_size; j++) {
      for(i=1; i<=x2_vari; i++) { 
	population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
      }
      population[j][x2_vari+1] = 1.0;
    }
  }
  else if (reset_from_X == 0) {
    if (starting_values == 1 ) 
      {    /* if there are starting values */
	/* use the values in X and full sample 1/2 pop, set other 1/2 randomly */
	k = 1 + pop_size/2;
	for(j=1; j<k; j++) 
	  {
	    for(i=1; i<=x2_vari; i++) 
	      { 
		if (initial_values[i-1] != 9999.0) 
		  {
		    population[j][i] = initial_values[i-1];
		  }
		else 
		  {
		    population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
		  }
		population[j][x2_vari+1] = 1.0;
	      }
	  }
	for(j=k; j<=pop_size; j++) 
	  {
	    for(i=1; i<=x2_vari; i++) 
	      { 
		population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
		population[j][x2_vari+1] = 1.0;
	      }
	  }
	reset_from_X = 1;
      }
    else 
      {    /* if there are no starting values */
	for(j=1; j<=pop_size; j++) 
	  {
	  for(i=1; i<=x2_vari; i++) 
	    { 
	      population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
	      population[j][x2_vari+1] = 1.0;
	    }
	}
	reset_from_X = 1;
      }
  }
  else if (reset_from_X == 2) {
    /* use the values in X and full sample 1/2 pop, set other 1/2 randomly */
    k = 1 + pop_size/2;
    for(j=1; j<k; j++) {
      if (j % 2 == 0)
	for(i=1; i<=x2_vari; i++) { 
	  population[j][i] = X[i];
	  population[j][x2_vari+1] = 1.0;
	}
      else
	for(i=1; i<=x2_vari; i++) {
	  population[j][i] = record[M(0,i,runvars0+OFFSET)];
	  population[j][x2_vari+1] = 1.0;
	}
    }
    if (record[M(number,runvars0+3,runvars0+OFFSET)] < 0.0) {
      for(j=k; j<pop_size; j++) {
	for(i=1; i<=x2_vari; i++) {
	  population[j][i] = record[M(number,i,runvars0+OFFSET)];
	  population[j][x2_vari+1] = 1.0;
	}
      }
    }
    else
      for(j=k; j<=pop_size; j++) {
	for(i=1; i<=x2_vari; i++) { 
	  population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
	  population[j][x2_vari+1] = 1.0;
	}
      }
    reset_from_X = 1;
  }
  else {
    /* use values in X or record[0] for 3/4 the population, set others randomly */
    k = 1 + pop_size - pop_size/4;
    for(j=1; j<k; j++) {
      if (j % 2 == 0)
	for(i=1; i<=x2_vari; i++) { 
	  population[j][i] = X[i];
	  population[j][x2_vari+1] = 1.0;
	}
      else
	for(i=1; i<=x2_vari; i++) {
	  population[j][i] = record[M(0,i,runvars0+OFFSET)];
	  population[j][x2_vari+1] = 1.0;
	}
    }
    for(j=k; j<=pop_size; j++) {
      for(i=1; i<=x2_vari; i++) { 
	population[j][i] = frange_ran(domains[i][1], domains[i][3]); 
	population[j][x2_vari+1] = 1.0;
      }
    }
  }

  /*Evaluate each of the agents in the new population*/
  for(i=1; i<=pop_size; i++) {
    for(j=1; j<=x2_vari; j++)
      X[j] = population[i][j];
    population[i][0] = evaluate(X);
  }

  /*Sort the initial individuals based on their evaluation function*/
  sort(MinMax,population,pop_size);

  switch(MinMax) {
  case 0:
    Teval = population[1][0];
    /* fprintf(output,"%7lu \t%18.9f\n",count_gener,population[1][0]); */
    peak_cnt = count_gener;
    peak_val = population[1][0];
    break;
  case 1:
    Teval = population[1][0];
    /* fprintf(output,"%7lu \t%18.9f\n",count_gener,population[1][0]); */
    peak_cnt = count_gener;
    peak_val = population[1][0];
    break;
  }

  fprintf(output,"\nThe 2 best initial individuals are\n");
  for(i=1; i<3; i++) {
    print_vector(population[i],1,tot_eq+x2_vari);
    fprintf(output,"\nfitness = %f", population[i][0]);
    fprintf(output,"\n\n");
  }

  fprintf(output,"\nThe worst fit of the population is:%f\n", 
      population[pop_size][0]);
  fprintf(output,"\n\n");

  fprintf(output,"\n\nGeneration#\t    Solution Value\n");
  fprintf(output,"\n%7d \t%18.9f\n", 0, population[1][0]);

  /*Assigning probability of survival for each of the agent, with the*/
  /*probability provided by the user for the best agent*/
  assign_probab(probab,pop_size,Q); 

  /*Finding the cumulative probability of the agents*/
  find_cum_probab(cum_probab,probab,pop_size);

  /*Reproducing and evaluating for the total number of generations times*/
  do
    {
      /*Initializing the live vector*/
      for(j=1; j<=pop_size; j++)
        {
          live[j] = 0;
          for(i=0; i<=x2_vari + 1; i++)
            new_genera[j][i] = population[j][i];
        }

      /*Finding the agents that will die and the agents that will reproduce*/
      find_live(cum_probab,live,pop_size,P);
      /* set die_now counter to start replacements with the worst agent.
         use of die_now is okay if the entire population (except the previous
         best) is to be replaced in each generation */
      die_now = pop_size;

      j1=j2=j3=j4=j5=j6=j7=j8=0;

      /* main operator loop */
      while(j1+j2+j3+j4+j4+j5+j5+j6+j7+j7+j8 < P)
        {
          oper = irange_ran(1,8);
          switch (oper)
            {
              case 1:
                     /*Applying the first operator, uniform mutation*/
                    if (j1 < P1)
                      {
			/*Find one parent for mutation operator 1*/
			first_live  = find_parent(live,pop_size);
			/* check that agent to replace is in range */
			if (die_now < 2) {
			  fprintf(output,"No agents to be replaced\n");
			  fprintf(stderr,"No agents to be replaced\n");
			  exit(1);
			}

			new_genera[die_now][x2_vari+1] = 1.0;
			for(i=1; i<=x2_vari; i++)
			  t_vec[i] = population[first_live][i];
			for (ocnt = irange_ran(1,x2_vari); ocnt>0; ocnt--)
			  oper1(t_vec,fin_mat,rc);
			for(i=1; i<=x2_vari; i++)
			  new_genera[die_now][i] = t_vec[i];
			die_now--;
			j1++;
		      }
                    break;
              case 2:
                    /*Applying the second operator, boundary mutation*/
                    if (j2 < P2)
                      {
                        /*Find one parent for mutation operator 2*/
                        first_live  = find_parent(live,pop_size);
			/* check that agent to replace is in range */
			if (die_now < 2) {
			  fprintf(output,"No agents to be replaced\n");
			  fprintf(stderr,"No agents to be replaced\n");
			  exit(1);
			}

                        new_genera[die_now][x2_vari+1] = 2.0;
                        for(i=1; i<=x2_vari; i++)
                          t_vec[i] = population[first_live][i];
			oper2(t_vec,fin_mat,rc);
                        for(i=1; i<=x2_vari; i++)
                          new_genera[die_now][i] = t_vec[i];
			die_now--;
                        j2++;
                      }
                    break;
              case 3:
                    /*Applying the third operator, non-uniform mutation*/
                    if (j3 < P3)
                      {
                        /*Find one parent for mutation operator 3*/
                        first_live  = find_parent(live,pop_size);
			/* check that agent to replace is in range */
			if (die_now < 2) {
			  fprintf(output,"No agents to be replaced\n");
			  fprintf(stderr,"No agents to be replaced\n");
			  exit(1);
			}

                        new_genera[die_now][x2_vari+1] = 3.0;
                        for(i=1; i<=x2_vari; i++)
                          t_vec[i] = population[first_live][i];
			for (ocnt = irange_ran(1,x2_vari); ocnt>0; ocnt--)
			  oper3(t_vec,fin_mat,rc,generations,count_gener,B);
                        for(i=1; i<=x2_vari; i++)
                          new_genera[die_now][i] = t_vec[i];
			die_now--;
                        j3++;
                      }
                    break;

              case 4:
                    /*Applying the fourth operator, GENOUD Polytope Crossover */
                    if (j4 < (int) P4)
                      {
                        /*Find max(2,x2_vari) parents for crossover operator 4*/
			p2use = x2_vari > 2 ? x2_vari : 2;
			for (i=1; i<p2use; i++) {
			  parents[i] = find_parent(live,pop_size);
			  live[parents[i]]++;  /* no decr. first p2use-1 parents */
			}
			parents[p2use] = find_parent(live,pop_size);
			/* check that agents to replace are in range */
			if (die_now < 2) {
			  printf("No agents to be replaced\n");
			  exit(1);
			}
			new_genera[die_now][x2_vari+1]  = 4.0;
			for(k=1; k<=p2use; k++)
			  for(i=1; i<=x2_vari; i++)
			    temp[k][i] = population[parents[k]][i];
			oper4(temp,p2use,x2_vari);
			for(i=1; i<=x2_vari; i++)
			  new_genera[die_now][i]  = temp[1][i];
			die_now--;
                        j4++;
                      }
                    break;
              case 5:
                    /*Applying the fifth operator, simple arithmetical crossover*/
                    if (j5 < (int) P5/2)
                      {
                        /*Find two distinct parents for crossover operator 5*/
                        first_live  = find_parent(live,pop_size);
                        second_live = find_parent(live,pop_size);
                        same = TRUE;
                        for(i=1; i<=x2_vari; i++)
                          if (population[first_live][i] != population[second_live][i])
                            same = FALSE;
			/* check that agents to replace are in range */
			if (die_now < 3) {
			  fprintf(output,"Not enough agents to be replaced\n");
			  fprintf(stderr,"Not enough agents to be replaced\n");
			  exit(1);
			}
			first_die   = die_now-- ;
			second_die  = die_now-- ;
			new_genera[first_die][x2_vari+1]  = 5.0;
			new_genera[second_die][x2_vari+1] = 5.0;
                        if (!same)
                          {
                            for(i=1; i<=x2_vari; i++)
                              {
                                temp[1][i] = population[first_live][i];
                                temp[2][i] = population[second_live][i];
                              }
                            oper5(temp[1],temp[2],STEP,rc,fin_mat);
                            for(i=1; i<=x2_vari; i++)
                              {
                                new_genera[first_die][i]  = temp[1][i];
                                new_genera[second_die][i] = temp[2][i];
                              }
                          }
			else {
			  /* copy agent chosen twice into two new indivs */
			  for(i=1; i<=x2_vari; i++) {
			    new_genera[first_die][i]  = 
			      population[first_live][i];
			    new_genera[second_die][i] = 
			      population[second_live][i];
			  }
			}
                        j5++;
                      }
                    break;
              case 6:
                    /*Applying the sixth operator, whole non-uniform mutation*/
                    if (j6 < P6)
                      {
                        /*Find one parent for mutation operator 6*/
                        first_live  = find_parent(live,pop_size);
			/* check that agent to replace is in range */
			if (die_now < 2) {
			  fprintf(output,"No agents to be replaced\n");
			  fprintf(stderr,"No agents to be replaced\n");
			  exit(1);
			}

                        new_genera[die_now][x2_vari+1] = 6.0;
                        for(i=1; i<=x2_vari; i++)
                          t_vec[i] = population[first_live][i];
                        oper6(t_vec,fin_mat,rc,generations,count_gener,B);
                        for(i=1; i<=x2_vari; i++)
                          new_genera[die_now][i] = t_vec[i];
			die_now--;
                        j6++;
                      }
                    break;
              case 7:
                    /*Applying the seventh operator*/
                    if (j7 < (int) P7/2)
                      {
                        /*Find two distinct parents for operator 7*/
                        first_live  = find_parent(live,pop_size);
                        second_live = find_parent(live,pop_size);
                        same = TRUE;
                        for(i=1; i<=x2_vari; i++)
                          if (population[first_live][i] != population[second_live][i])
                            same = FALSE;
			/* check that agents to replace are in range */
			if (die_now < 3) {
			  fprintf(output,"Not enough agents to be replaced\n");
			  fprintf(stderr,"Not enough agents to be replaced\n");
			  exit(1);
			}
			first_die   = die_now-- ;
			second_die  = die_now-- ;
			new_genera[first_die][x2_vari+1]  = 7.0;
			new_genera[second_die][x2_vari+1] = 7.0;
                        if (!same) {
			  if (first_live < second_live)
			    /* first agent is better agent */
			    for(i=1; i<=x2_vari; i++) {
			      temp[2][i] = population[first_live][i];
			      temp[1][i] = population[second_live][i];
			    }
			  else
			    /* second agent is better agent */
			    for(i=1; i<=x2_vari; i++) {
			      temp[2][i] = population[second_live][i];
			      temp[1][i] = population[first_live][i];
			    }
			  oper7(temp[1],temp[2],rc,fin_mat);
			  for(i=1; i<=x2_vari; i++)
			    new_genera[first_die][i]  = temp[1][i];
			  if (first_live < second_live)
			    /* first agent is better agent */
			    for(i=1; i<=x2_vari; i++) {
			      temp[2][i] = population[first_live][i];
			      temp[1][i] = population[second_live][i];
			    }
			  else
			    /* second agent is better agent */
			    for(i=1; i<=x2_vari; i++) {
			      temp[2][i] = population[second_live][i];
			      temp[1][i] = population[first_live][i];
			    }
			  oper7(temp[1],temp[2],rc,fin_mat);
			  for(i=1; i<=x2_vari; i++)
			    new_genera[second_die][i]  = temp[1][i];
			}
			else {
			  /* copy agent chosen twice into two new indivs */
			  for(i=1; i<=x2_vari; i++) {
			    new_genera[first_die][i]  = 
			      population[first_live][i];
			    new_genera[second_die][i] = 
			      population[second_live][i];
			  }
			}
                        j7++;
                      }
              case 8:
                     /*Applying the eighth operator, BFGS*/
                    if (j8 < P8)
                      {
                        /*Find one parent for BFGS operator 1*/
                        first_live  = find_parent(live,pop_size);
			/* check that agent to replace is in range */
			if (die_now < 2) {
			  fprintf(output,"No agents to be replaced\n");
			  fprintf(stderr,"No agents to be replaced\n");
			  exit(1);
			}

                        new_genera[die_now][x2_vari+1] = 8.0;
                        for(i=1; i<=x2_vari; i++)
                          t_vec[i] = population[first_live][i];
                        oper8(t_vec,fin_mat,rc,domains);
                        for(i=1; i<=x2_vari; i++)
                          new_genera[die_now][i] = t_vec[i];
			die_now--;
                        j8++;
                      }
                    break;
            }
        }


      /*Replace the population with the new generation */
      new = new_genera;
      new_genera = population;
      population = new;

      /*Evaluate each of the agents in the new population*/
      for(i=1; i<=pop_size; i++) {
	/* do not reevaluate if no changes were made */
	if (population[i][x2_vari+1] != 0) {
	  if (tot_eq != 0) {
	    for(j=1; j<=x2_vari + tot_eq; j++)
	      X[j] = 0.0;

	    find_X(fin_mat,population[i],X,x2_vari,tot_eq,x1,x2,a1_b);
	  }
	  else
	    for(j=1; j<=x2_vari; j++)
	      X[j] = population[i][j];

	  population[i][0] = evaluate(X);
	}
      }

      /*Sort the new population based on their evaluation function*/
      sort(MinMax,population,pop_size);

      /* print non-improving generations */
      /* if (Teval == population[1][0]) {
	 fprintf(output,"%7lu . \t%18.9f\n",count_gener,population[1][0]); 
	 } */

      diff = 0.0;
      switch(MinMax)
        {
	case 0:
	  if(Teval > population[1][0])
	    {
	      diff=Teval-population[1][0];
	      Teval = population[1][0];
	      fprintf(output,"%7lu \t%18.9f\n",count_gener,population[1][0]); 
	      peak_cnt = count_gener;
	      peak_val = population[1][0];
	    }
	  break;
	case 1:
	  if(Teval < population[1][0])
	    {
	      diff=population[1][0]-Teval;
	      Teval = population[1][0];
	      fprintf(output,"%7lu \t%18.9f\n",count_gener,population[1][0]);
	      peak_cnt = count_gener;
	      peak_val = population[1][0];
	    }
	  break;
        }

      if (diff < 0.000000001)
	nochange_gen++;
      else
	nochange_gen = 0;

      if (nochange_gen > (run_nochange_lim-1) || count_gener >= run_notdone_lim) {
	gradient_tolerance=0;
	for (j=0; j<runvars; j++) 
	  {
	    evalX[j]=population[1][j+1];
	  }
	gradient(evalX, grad);
	for (j=0;j<runvars;j++)
	  {
	    if (grad[j]>gradtol || grad[j]<mgradtol) gradient_tolerance=1;
	  }
	if (gradient_tolerance==1) nochange_gen=0;
      } /* end of gradient check for nochange_gen */

      if (nochange_gen > (run_nochange_lim-1)) {
	fprintf(output,"NO REAL IMPROVEMENT IN %d GENERATIONS\n", nochange_gen);
	if (generations>NOCHANGE_SHRINK)
	  generations -= NOCHANGE_SHRINK;
	else {
	  generations = 0;
	  converged_flag = x2_vari;
	}
	nochange_gen=0;
      }

      if (count_gener >= run_notdone_lim) {
	if (gradient_tolerance==1) {
	  if (whichcontrol==0) 
	    fprintf(output,"LIMIT IN CONTROL (OF %d) REACHED\n", 
		   run_notdone_lim);
	  else if (whichcontrol==1 && doing==0) 
	    fprintf(output,"LIMIT IN CONTROL.BIG (OF %d) REACHED IN BASE\n", 
		   run_notdone_lim);
	  else if (whichcontrol==1 && doing==1) 
	    fprintf(output,"LIMIT IN CONTROL.BIG (OF %d) REACHED IN JK %d\n", 
		   run_notdone_lim,jacknumber+1);
	  else if (whichcontrol==1 && doing==2) 
	    fprintf(output,"LIMIT IN CONTROL.BIG (OF %d) REACHED IN BOOT %d\n", 
		   run_notdone_lim,bootnumber+1);
	  else if (whichcontrol==2) 
	    fprintf(output,"LIMIT IN CONTROL.JACK (OF %d) REACHED IN JK %d\n", 
		   run_notdone_lim,jacknumber+1);
	  else if (whichcontrol==3) 
	    fprintf(output,"LIMIT IN CONTROL.BOOT (OF %d) REACHED IN BOOT %d\n", 
		   run_notdone_lim,bootnumber+1);
	  else
	    fprintf(output,"LIMIT IN CONTROL(%d) (OF %d) REACHED\n", 
		   whichcontrol,run_notdone_lim);
	  converged_flag = -1;
	}
	else
	  converged_flag = x2_vari;
        generations = 0;
      }

      bfgs_portion=Teval*portion;
/*      if (count_gener<2) bfgs_portion=-1.0; */

      if (diff<bfgs_portion)
	{
/*	  fprintf(output,"In bfgs land\n"); */
	  if (P2>0) 
	    {
	      P2--;
	      P8++;
	    }
	  /* apply the bfgs to the best individual */
	  for (i=1; i<=runvars; i++)
	    {
	      bfgsoutX[i-1]=population[1][i];
	    }
	  
	  boundary=0;
	  evalgtol=0.0000000001;
	  dfgsmin(bfgsoutX, runvars, evalgtol, &evaliter, &bfgsfit, finalhessin);

	  for (ii=1; ii<=runvars; ii++) {
	    if (bfgsoutX[ii-1]<domains[ii][1] || bfgsoutX[ii-1]>domains[ii][3]) {
	      if (use_boundary==1) { /* use out of boundary cases */
		fprintf(output,"optimization: USING BOUNDARY. parm=%d value=%17.10e fit=%17.10e\n",
		       ii, bfgsoutX[ii-1], bfgsfit); 
	      }
	      else {
		boundary=1;  
		fprintf(output,"optimization: NOT USING BOUNDARY. parm=%d value=%17.10e fit=%17.10e\n",
		       ii, bfgsoutX[ii-1], bfgsfit); 
	      }
	    }
	  }

	  if (boundary==0) {
	    if (bfgsfit<population[1][0])
	      {
		for(i=1;i<=runvars;i++) 
		  {
		    population[1][i]=bfgsoutX[i-1];
		  }
		population[1][0]=bfgsfit;
	      }
	  } /* end of bfgs stuff */
	}

      /*  fflush(output); */
      /* check for solutions on boundary as determined by boundchk() */
      find_X(fin_mat,population[1],X,x2_vari,tot_eq,x1,x2,a1_b);
      for (j=0; j<x2_vari; j++) {
	evalX[j]=X[j+1];
      }
      if (boundchk(evalX) > hflag) break;
    }
  /*Increment iteration count and test whether all generations are done*/
  while (++count_gener <= generations);

  fprintf(output,"\nBest solution was found at generation %lu (solution value = %.8f)\n",peak_cnt,population[1][0]);
  fprintf(output,"There were %lu generations.\n", count_gener);
  fprintf(output,"\n\nBest solution found:\n\n");

  /* print best solution */
  find_X(fin_mat,population[1],X,x2_vari,tot_eq,x1,x2,a1_b);

  for (j=0; j<runvars; j++) {
    evalX[j]=X[j+1];
  }
  for (j=0; j<runvars; j++) boundary_hit[varmap[j]] = boundary_use[varmap[j]];
  gradient(evalX, grad);
  boundchk(evalX);  /* reset boundary_flag and boundary_hit */

  fprintf(output,"\n");
  fprintf(output,"Fit value: %17.10e\n", population[1][0]);
  /*  for(j = 1; j <= x2_vari+tot_eq; j++)
    fprintf(output," X[%2d] =\t%12.9lf \t %12.9lf\n",j,X[j], grad[j-1]); */

  /* copied from printspecs else part */
  fprintf(output,"                  MLEs,  \t Gradients\n");
  for (i=0; i<runvars; i++) {
    fprintf(output,"%2d) %4s %2d %2d = %17.10e \t %17.10e\n", i+1,
	    parmsyms[whereXtype[i]], whereXrow[i]+1, whereXcol[i]+1,
	    X[i+1], grad[i]);
  }

  record[M(number,0,runvars0+OFFSET)]=population[1][0];
  if (constrained_flag == 0) {
    for (i=1;i<= x2_vari; i++)
      record[M(number,i,runvars0+OFFSET)]=X[i];
  }
  else {
    for (i=1; i<= x2_vari; i++) {
      record[M(number,varmap[i-1]+1,runvars0+OFFSET)]= X[i] ;
    }
    for (i=0; i<runvars0; i++) {  /* fill-in zeroes for boundary hits */
      if (boundary_use[i]==1) {
	record[M(number,i+1,runvars0+OFFSET)]= 0.0 ;
      }
    }
  }
  
/* DATA DUMP!
  if (number==9) 
    {
      fprintf(output,"This is a data dump from record\n");
      for (j=0; j<10; j++) 
	{
	for (i=0; i<runvars0+OFFSET; i++) 
	   fprintf(output,"%10.8lf", record[M(j,i,runvars0+OFFSET)]);
	   fprintf(output,"\n");
	}
      exit(0);
    }
*/

  /* free allocated objects in reverse order of allocation, to try to
     minimize fragmentation (hopefully free() can recombine all the blocks */
  /*
  free_ivector(objsp->live,1);
  free_vector(objsp->cum_probab,1);
  free_vector(objsp->t_vec,1);
  free_vector(objsp->probab,1);
  free_matrix(objsp->temp,1,2,1);
  free_matrix(objsp->new_genera,1,pop_size,1);
  free_matrix(objsp->print_pop,1,pop_size,0);
  free_matrix(objsp->population,1,pop_size,0);
  */
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   sort()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void sort(MinMax, population,pop_size)       */
/*                                                                              */
/*           DESCRIPTION       :   This function sorts the population, in the   */
/*                                  ascending or the descending order of the    */
/*                                  evaluation function, depending on whether   */
/*                                  it is a maximization or a minimization      */
/*                                  function, respectively.                     */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void sort(int MinMax, MATRIX population, int pop_size)
{
  int i,j,k;


  /*If MinMax is 0 sorts in the descending order, and*/
  /*if it is 1 sorts in the ascending order*/
  /*Sorted in ascending or descending order, based on*/
  /*the evaluated values of each of the agents*/
  switch(MinMax)
    {
    case 0 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] > population[j][0])
            swap(&population[i],&population[j]);
      break;

    case 1 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] < population[j][0])
            swap(&population[i],&population[j]);
      break;
    default:
      fprintf(output,"Incorrect data: Must be a 0 or 1");
      exit(1);
    }
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   swap()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void swap(x,y)                               */
/*                                                                              */
/*           DESCRIPTION       :   This function interchanges the values of     */
/*                                  x and y.                                    */
/*                                                                              */
/********************************************************************************/

void swap(double **x, double **y)
{
  double *temp;

  temp = *x;
  *x = *y;
  *y = temp;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_parent()                                */
/*                                                                              */
/*           SYNOPSIS          :   int find_parent(live,pop_size)               */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the index of the       */
/*                                  agent in the population, which is to be     */
/*                                  chosen for reproduction.                    */
/*                                                                              */
/********************************************************************************/

int find_parent(IVECTOR live, int pop_size)
{
  int i,temp,t1,tot=0;

  /*Finding the total number of parents to reproduce*/
  for(i=1; i<=pop_size; i++)
    tot = tot + live[i];
  if(tot==0)
    {
      fprintf(output,"No agents to select\n");
      fprintf(stderr,"No agents to select\n");
      exit(1);
    }

  /*Choosing one of them randomly*/
  temp = irange_ran(1,tot);

  tot = 0;
  i = 1;
  do{
    if(live[i]!=0)
      t1 = i;
    tot = tot + live[i++];
  }while(tot<temp);

  /*Decrementing the number of times the parent chosen is going to reproduce*/
  live[t1]--;
  return(t1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   assign_probab()                              */
/*                                                                              */
/*           SYNOPSIS          :   void assign_probab(probab,pop_size,Q)        */
/*                                                                              */
/*           DESCRIPTION       :   This function assigns probability of survival*/
/*                                  to each of the agents determined by the     */
/*                                  value provided by the user for the          */
/*                                  probability of the best agent.              */
/*                                                                              */
/*                               Q is probability of survival of the best agent */
/*                                                                              */
/********************************************************************************/

void assign_probab(VECTOR probab, int pop_size, double Q)
{
  int i;

  /* Q, Q(1-Q)^1, Q(1-Q)^2 ... Q(1-Q)^n */
  for(i=1; i<=pop_size; i++)
    probab[i] = Q * x_pow_y(1-Q,i-1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   x_pow_y()                                    */
/*                                                                              */
/*           SYNOPSIS          :   double x_pow_y(x,y)                           */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the value of x to the  */
/*                                  power of y.                                 */
/*                                                                              */
/********************************************************************************/

double x_pow_y(double x, int y)
{
  int i;
  double tot = 1.0;

  for(i=0; i < y; i++)
    tot = tot * x;
  return(tot);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_cum__probab()                           */
/*                                                                              */
/*           SYNOPSIS          :   void find_cum__probab(cum_probab,probab,     */
/*                                                                     pop_size)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the cumulative           */
/*                                  probability of each of the agents, from the */
/*                                  individual probability found earlier.       */
/*                                                                              */
/********************************************************************************/

void find_cum_probab(VECTOR cum_probab, VECTOR probab, int pop_size)
{
  int i;

  cum_probab[1] = probab[1];

  for(i=2; i<=pop_size; i++)
    cum_probab[i] = cum_probab[i-1] + probab[i];

}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_live()                                  */
/*                                                                              */
/*           SYNOPSIS          :   void find_live(cum_probab,live,pop_size,P4+P5*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the agents from the      */
/*                                  population, who are going to live - those   */
/*                                  who are going to reproduce, which is done   */
/*                                  based on the cumulative probability of      */
/*                                  survival of each of the agents.             */
/*                                                                              */
/********************************************************************************/

void find_live(VECTOR cum_probab, IVECTOR live, int pop_size, int P)
{
  double random;
  int count=0,/*Count of the number of agents chosen to live*/
      i;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the parent with that probability to reproduce*/
      if(count < P)
        {
          live[i]++;
          count++;
        }
    }while(count < P);
}


/*   This function finds the agents from the population, who are going to die.    */

int find_die(VECTOR cum_probab, IVECTOR die, int pop_size)
{
  double random;
  int i;
  int done = FALSE;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }
      while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the agent to die*/
      if ((die[pop_size+1-i] == 0) && (i < pop_size))
        done = TRUE;
    }
  while(!done);
  return(pop_size+1-i);
}


/*   This function finds the value of all the variables in the original problem,  */
/*   with the values of the remaining variables.                                  */

void find_X(MATRIX final, VECTOR agent, VECTOR X, int x2_vari, int tot_eq,
	    IVECTOR x1, IVECTOR x2, VECTOR a1_b)
{
  int i,j;

  for(j=1; j<=x2_vari; j++)
    X[x2[j]] = agent[j];

  for(j = 1; j<=tot_eq; j++)
    {
      X[x1[j]] = a1_b[j];
      for(i=1; i<=x2_vari; i++)
        X[x1[j]] = X[x1[j]] + agent[i] * final[j+x2_vari][i+1];
    }
}

/* This function returns the value of the LISREL function evaluated     */
/* for a given set of parameters (X)                                    */
double evaluate(VECTOR X)
{
  return(lisrel(X+1));
}
