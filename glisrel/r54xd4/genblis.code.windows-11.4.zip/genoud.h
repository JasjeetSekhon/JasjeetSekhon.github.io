/* 

   Copyright (C) 1998  by Walter R. Mebane Jr. and Jasjeet S. Sekhon

   Please see http://data.fas.harvard.edu/jsekhon/ for the latest binaries,
   documentation and links to related academic articles.
   
   Author Contact information:
   
   Jasjeet S. Sekhon
   jsekhon@latte.harvard.edu
   http://data.fas.harvard.edu/jsekhon/
   
   and
   
   Walter R. Mebane Jr.
   wrm1@cornell.edu
   http://macht.arts.cornell.edu/wrm1/wrm1.html


   Some of the code in this file was adapted from an early version of
   GENOCOP I (Zbigniew Michalewicz, zbyszek@uncc.edu).  For information
   about GENOCOP III please see
   http://www.coe.uncc.edu/~gnazhiya/gchome.html.
   
   
   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2 of the License, or (at your option)
   any later version.
   
   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.
   
   You should have received a copy of the GNU General Public License along
   with this program---see file "gpl.txt"; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

*/



/* @(#)genoud.h	11.4   7/23/98 */

#include "parms.h"

#define flip()  ((int) ((newrand()*(long)2)/(long) 65535))
#define MIN -32768
#define MAX 32768
/*#define HEAD 1*/
#define TAIL 0
#define TRIES 1000
#define MAX_VAR MAXPARMS
#define EST_OFFSET 0  /* offset in hours from Eastern Standard Time zone)  */

typedef double **MATRIX;
typedef double *VECTOR;
typedef int **IMATRIX;
typedef int *IVECTOR;
typedef int FLAG;
typedef struct {int r; int c;}INDEX;

struct optcontrol {  /* structure to hold values read from control file */
  int
    pop_size,   /*Population size*/
    MinMax,     /*Minimization or Maximization problem 0 or 1 */
    P1,         /*Number of parents for each of the 8 operators*/
    P2,
    P3,
    P4,
    P5,
    P6,
    P7,
    P8,
    B,          /*Parameter for 3rd operator - nonuniform mutation*/
    STEP;       /*Parameter for 5th operator - simple arithmetical crossover*/

  unsigned long genbound;       /*Total number of Generations*/

  double
    Q,                   /*Probability of the best agent*/
    portion,
    gradtol;
};

/* this structure is used to avoid reallocating storage for each resample */
struct optimobjs {
  MATRIX population;   /*Population of x2 variables*/
  MATRIX print_pop;
  MATRIX new_genera;   /*Temporary storage for the new generation*/
  MATRIX temp;
  VECTOR probab;       /*Probability of agents to die or live*/
  VECTOR t_vec;
  VECTOR cum_probab;   /*Cumulative probability of agents*/
  IVECTOR live;
  IVECTOR parents;
};

/* this structure is used to avoid reallocating storage for each resample */
static struct gspecobjs {
  int cart_count;      /*Get a different combination of x2 variables*/
  int tot_combi;       /*Total combinations of x2 variables*/
  int tot_var;         /*Total number of variables in the problem*/
  int tot_equ;         /*Total number of equalities, also p-equalities*/
  int x2_vari;         /*Remaining variables after p-variables were eliminated*/

  INDEX fin;    /*Size of final matrix*/

  MATRIX final_mat;

  MATRIX equalities;
  IVECTOR eq_co;
  VECTOR eq_rhs;
  MATRIX a1;
  MATRIX a2;
  MATRIX inv_a1;
  MATRIX inva1_a2;
  VECTOR inva1_b;
  MATRIX new_in_eq;

  MATRIX inequalities;
  IVECTOR ineq_co;
  VECTOR ineq_rhs;
  MATRIX c1;
  MATRIX c2;
  MATRIX org_ineq;

  MATRIX domains;
  VECTOR ldomain;
  VECTOR udomain;

  VECTOR l1;
  VECTOR u1;
  IVECTOR x1;

  VECTOR l2;
  VECTOR u2;
  IVECTOR x2;

  VECTOR X;
  IMATRIX var_order;
  IVECTOR cart;
} ;

/* values read from control file */
extern struct optcontrol *octrl;
extern struct optcontrol ctrlvals[NUMOFMODELS];

extern struct gspecobjs gosvec[NUMOFMODELS];
extern int firsttime_g[NUMOFMODELS];
extern struct optimobjs objs[NUMOFMODELS];
extern int firsttime_o[NUMOFMODELS];

void genoud(void);
double frange_ran(double llim, double ulim);
