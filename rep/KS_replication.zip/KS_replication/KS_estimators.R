# August 5, 2011
# Susan Gruber, Kristin Porter, Jasjeet Sekhon, Mark van der Laan
# Software supplement for The Relative Performance of Targeted Maximum
# Likelihood Estimators,International Journal of Biostatistics, 2011.

# KS, modification 1, and modification 2:
# ols, wls, IPW, AIPW, PBS, PRC BHT, Cao, Tan.WLS, Tan.RV TMLEY*
# Estimators not included below: C-TMLEY*, TMLEs + Super Learner

# requires tmle and alabama packages, available on sCRAN

library(tmle)
niter <- 250
n <- 1000

# load ksdat, mod1dat (mod2 is generated from mod1 datafile)
load("KS_SimData.Rdata")

Q.cor4 <- as.formula(y~z1+z2+z3+z4)
Q.mis4 <- as.formula(y~x1+x2+x3+x4)

g.cor4 <- as.formula(t~z1+z2+z3+z4)
g.mis4 <- as.formula(t~x1+x2+x3+x4)

bound <- function(x, bounds){
	x[x < min(bounds)] <- min(bounds)
	x[x > max(bounds)] <- max(bounds)
	x
}

#---------------------------------
# Implement estimator in Cao, Tsaitis, Tan, Biometrika 2010
# from SAS code provided by Cao
library(alabama)

pscore.enhanced <- function(theta,X,...){
	pi <- as.vector(1-exp(cbind(1,X) %*% theta)/(1+exp(X %*% theta[-1])))
	pi[pi==Inf] <- 10^9
	pi[pi== -Inf] <- -(10^9)
	return(pi)
}

constrain <- function(theta,X,gbd=0.01,...){
	pi <- pscore.enhanced(theta,X)
	c1 <- ifelse(is.nan(pi), 0,  pi-gbd)
	c2 <- ifelse(is.nan(pi), 0,  1-pi-gbd)
	return(c(c1, c2))
}

cao.ll <- function(theta,X,Delta,...){
	pi <- pscore.enhanced(theta,X)
	ll <- sum(Delta*log(pi) + (1-Delta)*(log(1-pi)))
	return(ll)
}

cao.grad <- function(theta,X,Delta,...){
	pi <- pscore.enhanced(theta,X)
	g <- matrix(NA,nrow=nrow(X), ncol= ncol(X)+1)
	g[,1] <- 1-Delta/pi
	denom <- as.vector(1 + exp(X %*% theta[-1, drop=FALSE]))
	g[,-1] <- -X/denom * (Delta-pi)
	return(colMeans(g))
}

estEY1 <- function(d, Delta, Qform, pi, param){
	m <- glm(Qform, data=data.frame(d, Delta),subset=Delta==1)
	Q1W <- predict(m, newdata=d)
	mu.DR <- mean(Delta * d$y / pi - (Delta-pi)/pi * Q1W)
	return(mu.DR)
}

calc_Cao <- function(dat, gbound=0, Q.cor, Q.mis){
	X.cor <- cbind(1, dat$z1, dat$z2, dat$z3, dat$z4)
	X.mis <- cbind(1, dat$x1, dat$x2, dat$x3, dat$x4)
	colnames(X.cor) <- c("intercept", "z1", "z2", "z3", "z4")
	colnames(X.mis) <- c("intercept", "x1", "x2", "x3", "x4")
	par.gc <- c(log(2-2*(gbound+10^-5)), rep(0,5))
	opt.gc <- constrOptim.nl(par=par.gc, 
		fn=cao.ll,  hin=constrain, 
		gr = cao.grad,
		control.optim = list(fnscale= -1, trace=0), # maximize
		control.outer = list(methd="BFGS"),
		X= X.cor,
		Delta=dat$t,
		gbd=gbound
	)
	par.gm <- c(log(2-2*(gbound+10^-5)), rep(0,5))
	opt.gm <- constrOptim.nl(par=par.gm,
		fn=cao.ll,  hin=constrain, 
		gr = cao.grad,
		control.optim = list(fnscale= -1, trace=0), # maximize
		control.outer = list(methd="BFGS"),
		X= X.mis,
		Delta=dat$t,
		gbd=gbound
	)
	pi.gc <- pscore.enhanced(opt.gc$par,X.cor )
	mu.Qcgc <- estEY1(data.frame(y=dat$y,X.cor[,-1]), Delta=dat$t, Qform=Q.cor, pi.gc, opt.gc$par)
	mu.Qmgc <- estEY1(data.frame(y=dat$y,X.mis[,-1]), Delta=dat$t, Qform=Q.mis, pi.gc, opt.gc$par)

	pi.gm <- pscore.enhanced(opt.gm$par,X.mis )
	mu.Qcgm <- estEY1(data.frame(y=dat$y,X.cor[,-1]), Delta=dat$t, Qform=Q.cor, pi.gm, opt.gm$par)
	mu.Qmgm <- estEY1(data.frame(y=dat$y,X.mis[,-1]), Delta=dat$t, Qform=Q.mis, pi.gm, opt.gm$par)

   return(c(Qcgc=mu.Qcgc, Qcgm = mu.Qcgm, Qmgc = mu.Qmgc, Qmgm = mu.Qmgm)) 
}
#------------------------------------------

#--------------- TAN -----------------
# loglik.g1 and ps.likeeNULL courtesy of Tan
library(trust)
loglik.g1 <- function(lam, tr, hh, pr,g1) {
   n <- length(tr)
   k <- dim(g1)[2]

   w <- rep(1/2,n)
   w[tr==1] <- hh[tr==1,]%*%c(1,lam)

   if (sum(w[tr==1]>0)+sum(tr==0)==n & !any(is.na(lam))) {
     val <- -sum(log(w[tr==1])/(1-pr[tr==1]))/n + sum(g1%*%lam)/n

     mgrad <- matrix(0,n,k)
     mgrad[tr==1,1:k] <- g1[tr==1, ,drop=F]/w[tr==1]
     #mgrad <- tr/w*g1

     grad <- mgrad-g1

     gradient <- -apply(grad,2,sum)/n
     hessian <- t((1-pr)*mgrad)%*%(mgrad)/n
   }else {
     val <- Inf

     gradient <- rep(NA, k)
     hessian <- matrix(NA, k,k)
   }
   list(value=val, gradient=gradient, hessian=hessian)
}

ps.likeeNULL <- function(y, t, p, g1) {
   #y: outcome
   #t: non-missing indicator
   #p: fitted propensity score
   #g1: control variate matrix

   n <- length(t)
  # m <- dim(X)[2]
   k <- dim(g1)[2]

   gp1 <- t==1

   #substitute
   h.subst <- cbind(p, (1-p)*g1)
   lam.subst <- rep(0,k)

   solv.subst <- trust(loglik.g1, lam.subst, rinit=1, rmax=100, iterlim=1000,
                         tr=t, hh=h.subst, pr=p, g1=g1)
   lam.subst <- solv.subst$argument
   val1.subst <- sum(solv.subst$gradient^2)
   conv1.subst <- solv.subst$converged
   w.subst <- as.vector(h.subst%*%c(1,lam.subst))

   mu1.subst <- sum(y[gp1]/w.subst[gp1])/n

   list(mu=mu1.subst,
        val=val1.subst, 
        conv=conv1.subst)
}

calc_Tan <- function(dat, Q.cor, Q.mis, g1W.cor, g1W.mis, Qmeth){
	W.cor <- 1:4
	W.mis <- 5:8
	if(Qmeth == "WLS"){
		wts.cor <- 1/g1W.cor
		wts.mis <- 1/g1W.mis
	} else if (Qmeth == "RV") {
		wts.cor <- (1-g1W.cor)/g1W.cor^2
		wts.mis <- (1-g1W.mis)/g1W.mis^2
	}		
	m.Qcgc <- glm(Q.cor, data=data.frame(dat,wts.cor), subset= t==1, weights=wts.cor)
	m.Qcgm <- glm(Q.cor, data=data.frame(dat,wts.mis), subset= t==1, weights=wts.mis)
	m.Qmgc <- glm(Q.mis, data=data.frame(dat,wts.cor), subset= t==1, weights=wts.cor)
	m.Qmgm <- glm(Q.mis, data=data.frame(dat,wts.mis), subset= t==1, weights=wts.mis)
	
	QAW <- cbind(predict(m.Qcgc, newdata=dat), predict(m.Qcgm, newdata=dat),
				predict(m.Qmgc, newdata=dat), predict(m.Qmgm, newdata=dat))
	colnames(QAW) <- c("Qcgc", "Qcgm", "Qmgc", "Qmgm")

	g1.Qcgc <-  cbind(1, QAW[,"Qcgc"], g1W.cor, as.matrix(g1W.cor*dat[,W.cor]))
   	g1.Qcgm <-  cbind(1, QAW[,"Qcgm"], g1W.mis, as.matrix(g1W.mis*dat[,W.mis]))
	g1.Qmgc <-  cbind(1, QAW[,"Qmgc"], g1W.cor, as.matrix(g1W.cor*dat[,W.cor]))
   	g1.Qmgm <-  cbind(1, QAW[,"Qmgm"], g1W.mis, as.matrix(g1W.mis*dat[,W.mis]))
	
    return(c(Qcgc = ps.likeeNULL(dat$y, dat$t, p=g1W.cor, g1.Qcgc)$mu,
    		Qcgm = ps.likeeNULL(dat$y, dat$t, p=g1W.mis, g1.Qcgm)$mu,
 			Qmgc = ps.likeeNULL(dat$y, dat$t, p=g1W.cor, g1.Qmgc)$mu,
 			Qmgm = ps.likeeNULL(dat$y, dat$t, p=g1W.mis, g1.Qmgm)$mu))
 }
#-----------------------------------------

calc_EY1_augIPTW <- function(d, Qform, g1W, Qfamily="gaussian") {
    wts <- 1/g1W 
    Q <- glm(Qform, data=d, family=Qfamily, subset=(t==1))
    Q1W.pred <- predict(Q, newdata=d, type="response")
    psi <- mean(Q1W.pred) + mean(d$t*wts*(d$y-Q1W.pred))  
	return(psi)
}

#gbd <- c(0, .01, .025, .05)
gbd <- 0.025
estimators <- c("OLS", "WLS",  "AIPW", "BHT", "PRC", "Cao", "Tan.WLS", "Tan.RV","TMLE.Ystar")
for(sim in c("ks", "mod1", "mod2")){
 psi<- matrix(NA, nrow=niter, ncol=length(estimators) * length(gbd) * 4)
 colnames(psi) <- paste(rep(rep(estimators, each=4),length(gbd)),
 		paste(rep(gbd, each=4*length(estimators)), c("Qcgc", "Qcgm", "Qmgc", "Qmgm"), sep="."), sep=".")
 									
 Q.cor <- Q.cor4
 Q.mis <- Q.mis4
 g.cor <- g.cor4
 g.mis <- g.mis4
 if (sim=="ks"){
		d <- ksdat
 } else {
		d <- mod1dat
		Q.cor <- Q.cor4
		Q.mis <- Q.mis4
		if(sim=="mod2"){
			Q.cor <- as.formula(y~z1+z2+z3)
			Q.mis <- as.formula(y~x1+x2+x3)
			g.cor <- as.formula(t~z1+z2+z3+z4)
			g.mis <- as.formula(t~x1+x2+x3+z4)
 		}
 }
 for (gb in 1:length(gbd)){
	gbound <- c(gbd[gb], 1)
	for (i in 1:niter){
		start_row <- (i-1)*n+ 1
		end_row <- start_row+n-1
		dat <- d[start_row:end_row,]

		if(sim == "mod2"){
			dat$y <- dat$y - 25*dat$z4
		}

#----- ols -----
	m.cor <- glm(Q.cor, data=dat, subset=t==1)
	m.mis <- glm(Q.mis, data=dat, subset=t==1)
	
	Q1W.cor <-predict(m.cor, newdata=dat, type="response")
	Q1W.mis <- predict(m.mis, newdata=dat, type="response")

	ols <- rep(c(mean(Q1W.cor), mean(Q1W.mis)),each=2)

#----- calculate weights g1W.cor, g1W.mis -----
	mg.cor <- glm(g.cor, data=dat, family="binomial")
	g1W.cor <- bound(predict(mg.cor, type="response"), gbound)
	wts.cor <- 1/g1W.cor

	mg.mis <- glm(g.mis, data=dat, family="binomial")
	g1W.mis <- bound(predict(mg.mis, type="response"), gbound)
	wts.mis <- 1/g1W.mis

#----- wls -----
	m.Qcgc <- glm(Q.cor, data=data.frame(dat,wts.cor), weights=wts.cor, subset=t==1)
	m.Qcgm <- glm(Q.cor, data=data.frame(dat,wts.mis), weights=wts.mis, subset=t==1)
	m.Qmgc <- glm(Q.mis, data=data.frame(dat,wts.cor), weights=wts.cor, subset=t==1)
	m.Qmgm <- glm(Q.mis, data=data.frame(dat,wts.mis), weights=wts.mis, subset=t==1)

	wls <- c(mean(predict(m.Qcgc, newdata=dat, type="response")), 
		 mean(predict(m.Qcgm, newdata=dat, type="response")), 
		 mean(predict(m.Qmgc, newdata=dat, type="response")), 
		 mean(predict(m.Qmgm, newdata=dat, type="response")))

	
#----- aug_IPW -----
	aug_IPW <- c(calc_EY1_augIPTW(dat, Q.cor, g1W.cor),
			     calc_EY1_augIPTW(dat, Q.cor, g1W.mis),
			     calc_EY1_augIPTW(dat, Q.mis, g1W.cor),
			     calc_EY1_augIPTW(dat, Q.mis, g1W.mis))
			     
#----- PRC -----
	Qc.form <- update(Q.cor, .~. + wts)
	Qm.form <- update(Q.mis, .~. + wts)

	mPRC.Qcgc <- glm(Qc.form, data=data.frame(dat, wts=wts.cor), subset=t==1)
	mPRC.Qcgm <- glm(Qc.form, data=data.frame(dat, wts=wts.mis), subset=t==1)
	mPRC.Qmgc <- glm(Qm.form, data=data.frame(dat, wts=wts.cor), subset=t==1)
	mPRC.Qmgm <- glm(Qm.form, data=data.frame(dat, wts=wts.mis), subset=t==1)

	PRC <- c(mean(predict(mPRC.Qcgc, newdata=data.frame(dat, wts=wts.cor),type="response")), 
		  mean(predict(mPRC.Qcgm, newdata=data.frame(dat, wts=wts.mis),type="response")),
		  mean(predict(mPRC.Qmgc, newdata=data.frame(dat, wts=wts.cor),type="response")),
		  mean(predict(mPRC.Qmgm, newdata=data.frame(dat, wts=wts.mis),type="response")))
		  
#----- bounded Horvitz-Thompson -----

	h.cor <- Q1W.cor - mean(Q1W.cor)
	h.mis <- Q1W.mis - mean(Q1W.mis)
	Qcgcform <-  update(g.cor, ~. + h.cor)
	Qcgmform <- update(g.mis, ~. + h.cor)
	Qmgcform <-  update(g.cor, ~. + h.mis)
	Qmgmform <- update(g.mis, ~. + h.mis)

	pi.Qcgc <- bound(predict(glm(Qcgcform, data=data.frame(dat, h.cor), family="binomial"), 				type="response"), gbound)
	pi.Qcgm <- bound(predict(glm(Qcgmform, data=data.frame(dat, h.cor), family="binomial"), 				type="response"),  gbound)
	pi.Qmgc <- bound(predict(glm(Qmgcform, data=data.frame(dat, h.mis), family="binomial"), 			type="response"),  gbound)
	pi.Qmgm <- bound(predict(glm(Qmgmform, data=data.frame(dat, h.mis), family="binomial"), 			type="response"),  gbound)

	BHT <- c(mean(Q1W.cor) + mean(dat$t/pi.Qcgc * (dat$y-Q1W.cor))/mean(dat$t/pi.Qcgc),
		 mean(Q1W.cor) + mean(dat$t/pi.Qcgm * (dat$y-Q1W.cor))/mean(dat$t/pi.Qcgm),
		 mean(Q1W.mis) + mean(dat$t/pi.Qmgc * (dat$y-Q1W.mis))/mean(dat$t/pi.Qmgc),
		 mean(Q1W.mis) + mean(dat$t/pi.Qmgm * (dat$y-Q1W.mis))/mean(dat$t/pi.Qmgm))
		 
#----- Cao -----
	Cao <- calc_Cao(dat, gbound[1], Q.cor, Q.mis)
	
#----- Tan -----
	Tan.WLS <- calc_Tan(dat, Q.cor, Q.mis, g1W.cor, g1W.mis, Qmeth="WLS")
	Tan.RV  <- calc_Tan(dat, Q.cor, Q.mis, g1W.cor, g1W.mis, Qmeth="RV")

#----- tmle -----
	Qbounds <- range(dat$y[dat$t==1]) * c(0.9, 1.1)
	tmle.Ystar <- c(tmle(Y=dat$y, A=NULL, W=dat[,1:8], Delta=dat$t, Qform=update(Q.cor, Y~.), 
						Qbounds=Qbounds, pDelta1=cbind(g1W.cor, g1W.cor), gbound=gbound)$estimates$EY1$psi,
					tmle(Y=dat$y, A=NULL, W=dat[,1:8], Delta=dat$t, Qform=update(Q.cor, Y~.), 
						Qbounds=Qbounds, pDelta1=cbind(g1W.mis, g1W.mis), gbound=gbound)$estimates$EY1$psi,
					tmle(Y=dat$y, A=NULL, W=dat[,1:8], Delta=dat$t, Qform=update(Q.mis, Y~.), 
						Qbounds=Qbounds, pDelta1=cbind(g1W.cor, g1W.cor), gbound=gbound)$estimates$EY1$psi,
					 tmle(Y=dat$y, A=NULL, W=dat[,1:8], Delta=dat$t, Qform=update(Q.mis, Y~.), 
						Qbounds=Qbounds, pDelta1=cbind(g1W.mis, g1W.mis), gbound=gbound)$estimates$EY1$psi)
		

######
# Save estimates in matrix: niter x (#estimators * # specifications * # bounds on g)
	psi[i,((gb-1)*36+ 1):(gb*36)] <-  c(ols=ols, wls=wls, aug_IPW=aug_IPW, BHT=BHT, PRC=PRC, Cao=Cao, Tan.WLS=Tan.WLS, Tan.RV=Tan.RV, tmle.Ystar=tmle.Ystar) 
	}
	
 }
 if(sim=="ks"){
 	ks.psi <- psi
 } else if (sim=="mod1") {
 	mod1.psi <- psi
 } else {
 	mod2.psi <- psi
 }
}

# Calculate bias, variance, MSE
calc_results <- function(psi, psi0=210){
	return(list(bias=colMeans(psi - psi0),
			var = apply(psi, 2, var),
			MSE = colMeans((psi - psi0)^2)))
}
	
ks <- calc_results(ks.psi) 
mod1 <- calc_results(mod1.psi)
mod2 <- calc_results(mod2.psi)
#save(ks.psi, mod1.psi, mod2.psi, ks, mod1, mod2,
#     file="KSestimates.Rdata")
save(ks.psi, mod1.psi, mod2.psi, ks, mod1, mod2, file="KSestimates2.Rdata")
