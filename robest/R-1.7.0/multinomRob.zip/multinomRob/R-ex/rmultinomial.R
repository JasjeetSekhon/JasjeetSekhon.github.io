### Name: rmultinomial
### Title: Random Number Generator for the Multinomial Distribution
### Aliases: rmultinomial
### Keywords: distribution multivariate

### ** Examples

 rmultinomial(10, c(.3, .3, .4));



