
function MatchWarapper(ddir)
%
% Jasjeet S. Sekhon
% <jasjeet_sekhnon@harvard.edu>
% http://jsekhon.fas.harvard.edu/
% 2004-06-08
%

%ddir = 'tmp123'
%Sample=1;
%All=0;
%M=1;
%BiasAdj=1
%Weight=3
%Var_calc=0
%K=2
%exact=0
%extra_output=0
%ccc=0.00001
%cdd=0.00001

parms = dataread('file', strcat(ddir, '/parms.tmp'));
Sample = parms(1,1);
All = parms(1,2);
M = parms(1,3);
BiasAdj = parms(1,4);
Weight = parms(1,5);
Var_calc = parms(1,6);
K = parms(1,7);
exact = parms(1,8);
extra_output = parms(1,9);
ccc = parms(1,10);
cdd = parms(1,11);

mat1 = dataread('file', strcat(ddir, '/mat1.tmp'));
Y = mat1(:,1)
T = mat1(:,2)

X = dataread('file', strcat(ddir,'/X.tmp'))
Z = dataread('file', strcat(ddir,'/Z.tmp'))
V = dataread('file', strcat(ddir,'/V.tmp'))

weight = dataread('file', strcat(ddir,'/weight.tmp'))

if Weight==3,
  Weight_matrix = dataread('file', strcat(ddir,'/Weight_matrix.tmp'));
  else
  Weight_matrix = eye(K);
  end,   

[est,se,se_cond,em,W,art_data,aug_data]=match(Y,T,X,Z,V,All,M,BiasAdj,Weight,Weight_matrix,Var_calc,weight,Sample,exact,ccc,cdd);
est_se=[est,se];

Sample
All
M
BiasAdj
Weight
Var_calc
K
exact
extra_output
ccc
cdd

est_se

indx = [art_data(:,1) art_data(:,2) W];

csvwrite(strcat(ddir,'/match1.est.tmp'), est);

csvwrite(strcat(ddir,'/match1.se.tmp'), se);

csvwrite(strcat(ddir,'/match1.se_cond.tmp'), se_cond);

csvwrite(strcat(ddir,'/match1.em.tmp'), em);

csvwrite(strcat(ddir,'/match1.indx.tmp'), indx);

if extra_output==1,
  csvwrite(strcat(ddir,'/match1.art_data.tmp'), art_data);
  csvwrite(strcat(ddir,'/match1.aug_data.tmp'), aug_data);
  end

