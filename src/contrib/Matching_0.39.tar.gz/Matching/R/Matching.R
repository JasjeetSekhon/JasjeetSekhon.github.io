# Jasjeet S. Sekhon <jasjeet_sekhon@harvard.edu>
# HTTP://jsekhon.fas.harvard.edu
# Harvard University

# Match() relies on a compiled C/C++ modified version of Guido
# Imbens's Matlab function (http://elsa.berkeley.edu/~imbens/).  It
# implements the algorithm described in the following working paper:
# Alberto Abadie and Guido Imbens. "Large Sample Properties of
# Matching Estimators for Average Treatment Effects."
# http://ksghome.harvard.edu/~.aabadie.academic.ksg/sme.pdf

# The R and C portions of the code and the Matlab function
# (MatchWrapper.m) for match.m are written by Sekhon.  See the
# following working paper for an application: Jasjeet
# S. Sekhon. "Updating Voters: How voters act as if they are
# informed."
# http://jsekhon.fas.harvard.edu/papers/SekhonUpdatingVoters.pdf

# Match(): function to estimate treatments using a matching estimator.
# Currently only the ability to estimate average treatment effects
# using the approach of Abadie and Imbens is implemented.  In the
# future, quantile treatment effects will be implemented along with
# the ability to use robust estimation when estimating the propensity
# score. MatchBalance(), balanceMV() and balanceUV() test for balance.

Match  <- function(Y,Tr,X,Z=X,V=rep(1,length(Y)),
                   estimand="ATT",M=1,BiasAdj=FALSE,Weight=1,Weight.matrix=NULL,
                   Var.calc=0,weights=rep(1,length(Y)), 
                   caliper=FALSE, exact=FALSE, sample=FALSE,
                   tmpdir=NULL, extra.output=FALSE, tolerance=0.00001)
  {
    isna  <- sum(is.na(Y)) + sum(is.na(Tr)) + sum(is.na(X)) + sum(is.na(Z))
    if (isna!=0)
      {
        stop("Match(): input includes NAs")
        return(NULL)
      }

    Y  <- as.real(Y)
    Tr <- as.real(Tr)
    X  <- as.matrix(X)
    Z  <- as.matrix(Z)
    V  <- as.matrix(V)
    BiasAdj  <- as.real(BiasAdj)
    exact  <- as.real(exact)
    sample  <- as.real(sample)

    ccc  <- tolerance
    cdd  <- tolerance

    if (estimand=="ATT")
      {
        estimand  <- 0
      } else if(estimand=="ATE") {
        estimand  <- 1
      } else if(estimand=="ATC") {
        estimand  <- 2
      } else {
        estimand  <- 0
        warning("estimand is not valid.  Defaulting to 'ATT'")
      }

    if (!is.null(Weight.matrix))
      {
        if (Weight!=3)
          {
            warning("User supplied 'Weight.matrix' is being used even though 'Weight' is not set equal to 3")
          }
        Weight  <- 3
      }

    orig.nobs  <- length(Y)
    nobs  <- orig.nobs
    orig.treated.nobs  <- sum(Tr==1)
    orig.wnobs  <- sum(weights)
    weights.orig  <- weights
    K  <- dim(X)[2]

    if (is.null(tmpdir))
      {
        tmpdir  <- tempdir()
      }

    parms  <- matrix(nrow=1,ncol=11)
    parms[1,1]  <- sample
    parms[1,2]  <- estimand
    parms[1,3]  <- M
    parms[1,4]  <- BiasAdj
    parms[1,5]  <- Weight
    parms[1,6]  <- Var.calc
    parms[1,7]  <- K
    parms[1,8]  <- exact
    parms[1,9]  <- extra.output
    parms[1,10]  <- ccc
    parms[1,11]  <- cdd

    linux  <- Sys.getenv("OSTYPE")=="linux"
    path  <- .path.package("Matching")

    if (linux)
      {
        write.table(NA,file=paste(tmpdir,"/match1.est.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"/match1.se.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"/match1.se_cond.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"/match1.em.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"/match1.indx.tmp",sep=""),
                    row.names=F,col.names=F)
                
        write.table(parms,file=paste(tmpdir,"/parms.tmp",sep=""), sep="\t", row.names=F, col.names=F)    

        mat1  <- as.data.frame(cbind(Y, Tr))
        write.table(mat1,file=paste(tmpdir,"/mat1.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(X,file=paste(tmpdir,"/X.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(Z,file=paste(tmpdir,"/Z.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(V,file=paste(tmpdir,"/V.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(weights,file=paste(tmpdir,"/weight.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        
        if (!is.null(Weight.matrix))
          {
            write.table(Weight.matrix, file=paste(tmpdir,"/Weight_matrix.tmp",sep=""), sep="\t",
                        row.names=F, col.names=F)
          }
        tfoo  <- paste("export LD_LIBRARY_PATH=",path,"/glnx86; ",path,"/exec/MatchWrapper '",tmpdir,"' > ",tmpdir,"/Match.out","\n",sep="")
        system(tfoo)

        est <- as.real(read.table(file=paste(tmpdir,"/match1.est.tmp",sep="")))
        se  <- as.real(read.table(file=paste(tmpdir,"/match1.se.tmp",sep="")))
        se.cond  <- as.real(read.table(file=paste(tmpdir,"/match1.se_cond.tmp",sep="")))
        em  <- as.matrix(read.table(file=paste(tmpdir,"/match1.em.tmp",sep="")))
        indx  <- as.matrix(read.table(file=paste(tmpdir,"/match1.indx.tmp",sep=""), sep=","))
      } else {
        path  <- gsub("/", "\\\\", path)

        write.table(NA,file=paste(tmpdir,"\\match1.est.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"\\match1.se.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"\\match1.se_cond.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"\\match1.em.tmp",sep=""),
                    row.names=F,col.names=F)
        
        write.table(NA,file=paste(tmpdir,"\\match1.indx.tmp",sep=""),
                    row.names=F,col.names=F)        
        
        write.table(parms,file=paste(tmpdir,"\\parms.tmp",sep=""), sep="\t", row.names=F, col.names=F)

        mat1  <- as.data.frame(cbind(Y, Tr))
        write.table(mat1,file=paste(tmpdir,"\\mat1.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(X,file=paste(tmpdir,"\\X.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(Z,file=paste(tmpdir,"\\Z.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(V,file=paste(tmpdir,"\\V.tmp",sep=""), sep="\t", row.names=F, col.names=F)
        write.table(weights,file=paste(tmpdir,"\\weight.tmp",sep=""), sep="\t", row.names=F, col.names=F)

        if (!is.null(Weight.matrix))
          {
            write.table(Weight.matrix, file=paste(tmpdir,"\\Weight_matrix.tmp",sep=""), sep="\t",
                        row.names=F, col.names=F)
          }

        tfoo <- paste(path,"\\v70\\bin\\win32\\MatchWrapper.bat ",
                       path,"\\v70\\bin\\win32 ",
                       tmpdir," ",
                       tmpdir,"\\Match.out",sep="")

        system(tfoo, invisible=TRUE)        
        
        est <- as.real(read.table(file=paste(tmpdir,"\\match1.est.tmp",sep="")))
        se  <- as.real(read.table(file=paste(tmpdir,"\\match1.se.tmp",sep="")))
        se.cond  <- as.real(read.table(file=paste(tmpdir,"\\match1.se_cond.tmp",sep="")))
        em  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.em.tmp",sep="")))
        indx  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.indx.tmp",sep=""), sep=","))        
      } #else linux

    index.treated  <- indx[,1]
    index.control  <- indx[,2]
    index.treated.indata  <- index.treated
    index.control.indata  <- index.control
    weights        <- indx[,3]

    index.treated.nocaliper  <- index.treated
    index.control.nocaliper  <- index.control
    index.caliper  <- rep(TRUE,length(index.treated))
    index.drop  <- NULL

    if (caliper!=FALSE)
      {
        n  <- ncol(X)
        for (i in 1:n)
          {
            sweights  <- sum(weights.orig)
            meanX  <- sum( X[,i]*weights.orig )/sweights
            sdX  <- sqrt(sum( (X[,i]-meanX)^2 )/sweights)
            ecaliper  <- caliper*sdX

            index.caliper  <- (abs(X[index.treated,i]-X[index.control,i]) < ecaliper) & index.caliper
          }
#        index.drop.treated  <- as.vector(-1*(index.treated.nocaliper[!index.caliper]))
#        index.drop.control  <- as.vector(-1*(index.control.nocaliper[!index.caliper]))
#        index.drop  <- unique(c(index.drop.treated,index.drop.control))        
        index.drop  <- -1*(unique(index.treated.nocaliper[!index.caliper]))
        sum.caliper.drops  <- length(index.drop)


        if( estimand <= 1 ) {
          #ATT or ATE
          valid.matches  <- sum(mat1[index.drop,2]==1)
        } else {
          #ATC
          valid.matches  <- sum(mat1[index.drop,2]==0)
        }
          
        if (sum.caliper.drops > 0 & valid.matches < 1)
          {
            sum.caliper.drops  <- -9999
            indx  <- as.matrix(NA)
          }
        
        if (sum.caliper.drops > 0)
          {
            #reestimate with dropped observations
            
            cmat1 <- as.matrix(mat1[index.drop,])
            cweights <- weights.orig[index.drop]
            cX  <- as.matrix(X[index.drop,])
            cZ  <- as.matrix(Z[index.drop,])
            cV  <- as.matrix(V[index.drop,])

            if (linux)
              {
                write.table(NA,file=paste(tmpdir,"/match1.est.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"/match1.se.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"/match1.se_cond.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"/match1.em.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"/match1.indx.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(cmat1,file=paste(tmpdir,"/mat1.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cX,file=paste(tmpdir,"/X.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cZ,file=paste(tmpdir,"/Z.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cV,file=paste(tmpdir,"/V.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cweights,file=paste(tmpdir,"/weight.tmp",sep=""), sep="\t", row.names=F,
                            col.names=F)

                tfoo  <- paste("export LD_LIBRARY_PATH=",path,"/glnx86; ",path,"/exec/MatchWrapper '",tmpdir,"' > ",tmpdir,"/Match.out","\n",sep="")
                system(tfoo)

                est <- as.real(read.table(file=paste(tmpdir,"/match1.est.tmp",sep="")))
                se  <- as.real(read.table(file=paste(tmpdir,"/match1.se.tmp",sep="")))
                se.cond  <- as.real(read.table(file=paste(tmpdir,"/match1.se_cond.tmp",sep="")))
                em  <- as.matrix(read.table(file=paste(tmpdir,"/match1.em.tmp",sep="")))
                indx  <- as.matrix(read.table(file=paste(tmpdir,"/match1.indx.tmp",sep=""), sep=","))
              } else {
                
                write.table(NA,file=paste(tmpdir,"\\match1.est.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"\\match1.se.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"\\match1.se_cond.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"\\match1.em.tmp",sep=""),
                            row.names=F,col.names=F)
                
                write.table(NA,file=paste(tmpdir,"\\match1.indx.tmp",sep=""),
                            row.names=F,col.names=F)

                write.table(cmat1,file=paste(tmpdir,"\\mat1.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cX,file=paste(tmpdir,"\\X.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cZ,file=paste(tmpdir,"\\Z.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cV,file=paste(tmpdir,"\\V.tmp",sep=""), sep="\t", row.names=F, col.names=F)
                write.table(cweights,file=paste(tmpdir,"\\weight.tmp",sep=""), sep="\t", row.names=F,
                            col.names=F)

                tfoo <- paste(path,"\\v70\\bin\\win32\\MatchWrapper.bat ",
                              path,"\\v70\\bin\\win32 ",
                              tmpdir," ",
                              tmpdir,"\\Match.out",sep="")

                system(tfoo, invisible=TRUE)
                
                est <- as.real(read.table(file=paste(tmpdir,"\\match1.est.tmp",sep="")))
                se  <- as.real(read.table(file=paste(tmpdir,"\\match1.se.tmp",sep="")))
                se.cond  <- as.real(read.table(file=paste(tmpdir,"\\match1.se_cond.tmp",sep="")))
                em  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.em.tmp",sep="")))
                indx  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.indx.tmp",sep=""), sep=","))
              } #end of else linux


            if(!is.na(indx[1,1]))
              {
                index.treated.indata  <- indx[,1]
                index.control.indata  <- indx[,2]
                weights        <- indx[,3]

                #lookup table
                vdrop  <- abs(index.drop)
                vdrop.tmp  <- vdrop
                ndrops  <- length(vdrop)
                nobs  <- orig.nobs-ndrops
                lu  <- matrix(0, nrow=nobs,ncol=1)
                d  <- 1
                count  <- 0
                i  <- 1 
                while (i <= nobs)
                  {
#                cat("i:",i,"d:",d,"vdrop.tmp[d]",vdrop.tmp[d],"\n")
                    if (d <= ndrops)
                      {
                        if (vdrop.tmp[d]==i)
                          {
                            count  <- count+2
                            lu[i]  <- count
                                        #            vdrop.tmp[d+1]  <- vdrop.tmp[d+1]-d
                            vdrop.tmp[(d+1):ndrops]  <- vdrop.tmp[(d+1):ndrops]-1
#                        cat("**IN d:",d,"\n")
#                        print(vdrop.tmp)
                            d  <- d+1
                            if (d<=ndrops)
                              {
                                if (vdrop.tmp[d]==vdrop.tmp[d-1])
                                  {
                                    i  <- i - 1
                                    count  <- count-1
#                                cat("reset i:",i,"\n")
                                  }
                              }
                          } else {
                            count  <- count+1
                            lu[i]  <- count;
                          }
                      } else {
                        count  <- count+1
                        lu[i]  <- count;        
                      }
                    i  <- i + 1
                  }
                index.treated  <- lu[index.treated.indata]
                index.control  <- lu[index.control.indata]                        
                
              }#end of !is.na(indx[1,1])
          }#end of restimate for caliper portion of code
      }#end of caliper loop

    if (is.na(indx[1,1]))
      {
        if (sum.caliper.drops < 0) {
          warning("'Match' object contains no valid matches (probably because of the caliper).") 
        } else {
          warning("'Match' object contains no valid matches")
        }
      }#is.na(indx[1,1])
    

    if (!is.na(indx[1,1]))
      {
        if (extra.output)
          {
            if (linux)
              {
                art.data  <- as.matrix(read.table(file=paste(tmpdir,"/match1.art_data.tmp",sep=""), sep=","))
                aug.data  <- as.matrix(read.table(file=paste(tmpdir,"/match1.aug_data.tmp",sep=""), sep=","))
              } else {
                art.data  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.art_data.tmp",sep=""), sep=","))
                aug.data  <- as.matrix(read.table(file=paste(tmpdir,"\\match1.aug_data.tmp",sep=""), sep=","))
              } #end of else linux
          } else {
            art.data  <- NULL
            aug.data  <- NULL
          }

        #RESET INDEX.TREATED        
        indx  <- as.matrix(cbind(index.treated,index.control))
        if (estimand==0) {
          #"ATT"
          index.treated  <- indx[,1]
          index.control  <- indx[,2]
        } else if(estimand==1) {
          #"ATE"
          tmp.index.treated  <- indx[,1]
          tmp.index.control  <- indx[,2]

          tl  <- length(tmp.index.treated)
          index.treated <- vector(length=tl, mode="numeric")
          index.control <- vector(length=tl, mode="numeric")
          trt  <- Tr[tmp.index.treated]==1
          for (i in 1:tl)
            {
              if (trt[i]) {
                index.treated[i]  <- tmp.index.treated[i]
                index.control[i]  <- tmp.index.control[i]
              } else {
                index.treated[i]  <- tmp.index.control[i]
                index.control[i]  <- tmp.index.treated[i]
              }
            }
        } else if(estimand==2) {
          #"ATC"
          index.treated  <- indx[,2]
          index.control  <- indx[,1]
        }        

        mdata  <- list()
        mdata$Y  <- c(Y[index.treated],Y[index.control])
        mdata$Tr <- c(Tr[index.treated],Tr[index.control])
        mdata$X  <- rbind(X[index.treated,],X[index.control,])
        
        #naive standard errors
        mest  <- sum((Y[index.treated]-Y[index.control])*weights)/sum(weights)
        v1  <- Y[index.treated] - Y[index.control]
        varest  <- sum( ((v1-mest)^2)*weights)/(sum(weights)*sum(weights))
        se.naive  <- sqrt(varest)
        
        z  <- list(est=est, se=se, est.noadj=mest, se.naive=se.naive, se.cond=se.cond, 
                   mdata=mdata, em=em,
                   index.treated=index.treated, index.control=index.control,
                   weights=weights, orig.nobs=orig.nobs, orig.wnobs=orig.wnobs,
                   orig.treated.nobs=orig.treated.nobs,
                   nobs=nobs, wnobs=sum(weights),
                   caliper=caliper, index.caliper.drop=index.drop, 
                   index.treated.nocaliper = index.treated.nocaliper,
                   index.control.nocaliper = index.control.nocaliper,
                   index.treated.indata=index.treated.indata,
                   index.control.indata=index.control.indata,
                   art.data=art.data, aug.data=aug.data)
      } else  {
        z  <- NA
      }
    class(z)  <- "Match"
    
    return(z)
  } #end of Match

summary.Match  <- function(object, ..., full=FALSE, digits=5)
  {
    if(!is.list(object)) {
      warning("'Match' object contains no valid matches")
      return()
    }
    
    if (class(object) != "Match") {
      warning("Object not of class 'Match'")
      return()
    }

    cat("\n")
    cat("Estimate... ",format(object$est,digits=digits),"\n")
    cat("SE......... ",format(object$se,digits=digits),"\n")
    cat("T-stat..... ",format(object$est/object$se,digits=digits),"\n")
    cat("p.val...... ",format.pval((1-pnorm(abs(object$est/object$se)))*2,digits=digits),"\n")
    cat("\n")

    if(full)
      {
        cat("Est noAdj.. ",format(object$est.noadj,digits=digits),"\n")        
        cat("Naive SE... ",format(object$se.naive,digits=digits),"\n")
        cat("Naive T-st. ",format(object$est.noadj/object$se.naive,digits=digits),"\n")
        cat("Naive p.val ",format.pval((1-pnorm(abs(object$est.noadj/object$se.naive)))*2,digits=digits),"\n")
        cat("\n")
      }

    
    cat("Original number of observations (weighted)... ", object$orig.wnobs,"\n")
    cat("Original number of observations (unweighted). ", object$orig.nobs,"\n")
    cat("Original number of treated obs  (unweighted). ", object$orig.treated.nobs,"\n")    
    cat("Matched number of observations  (weighted)... ", signif(object$wnobs),"\n")
    cat("Matched number of observations  (unweighted). ", length(object$index.treated),"\n")

    cat("\n")
    if(object$caliper!=FALSE)
      {
        cat("Caliper (SDs)..............  ",object$caliper,"\n")
        cat("Matches dropped by caliper.. ",length(object$index.caliper.drop),"\n")
        cat("\n\n")
      } else {
        cat("\n")
      }
  } #end of summary.Match



#
# See Rosenbaum and Rubin (1985) and Smith and Todd Rejoinder (JofEconometrics) p.9
#
sdiff  <- function(Tr, Co, weights=rep(1,length(Co)))
  {
    equal  <- FALSE
    if (length(Tr)==length(Co))
      equal  <- TRUE

    if (!equal)
      {
        diff  <- mean(Tr)-mean(Co)
        sdiff <- 100*diff/sqrt( (var(Tr)+var(Co))/2 )
      } else{
        diff  <- sum( (Tr-Co)*weights ) /sum(weights)
        mean.Tr <- sum(Tr*weights)/sum(weights)
        mean.Co <- sum(Co*weights)/sum(weights)
        var.Tr  <- sum( ( (Tr - mean.Tr)^2 )*weights)/sum(weights)
        var.Co  <- sum( ( (Co - mean.Co)^2 )*weights)/sum(weights)
        sdiff  <- 100*diff/sqrt( (var.Tr+var.Co)/2 )
      }

    return(sdiff)
  }

# function runs sdiff and t.test
#
balanceUV  <- function(Tr, Co, weights=rep(1,length(Co)), exact=FALSE)
  {
    try.McNemar <- FALSE
    equal  <- FALSE
    if (length(Tr)==length(Co))
      equal  <- TRUE

    categorical  <- is.factor(Tr)

    if (categorical & equal)
      {
        x <- factor(Tr)
        y <- factor(Co)
        r <- nlevels(x)
        if ((r < 2) || (nlevels(y) != r))
          {
            cat("reverting to wilcox.test: x and y must have the same number of levels (minimum 2)\n")
            try.McNemar  <- FALSE
          } else {
            efoo  <- sum(levels(x)==levels(y))
            if (efoo != r)
              {
                cat("reverting to wilcox.test: Level sets of factors are different\n")
                try.McNemar  <- FALSE            
              }
          }
      }    

    if (equal & categorical & try.McNemar)
      {
        use.McNemar  <- TRUE
      } else {
        use.McNemar  <- FALSE
        Tr  <- as.real(Tr)
        Co  <- as.real(Co)
      }

    if (!equal)
      {
        sbalance  <- sdiff(Tr, Co, weights)
        
        mean.Tr  <- mean(Tr);
        mean.Co  <- mean(Co);
        var.Tr  <- var(Tr)
        var.Co  <- var(Co)
        var.ratio  <- var.Tr/var.Co

        wc  <- wilcox.test(Tr,Co, exact=exact)
        tt  <- t.test(Tr, Co)

        pdiscordant  <- NA
      } else {

        if (categorical & use.McNemar)
          {
            sbalance  <- NULL
            
            x  <- as.real(Tr)
            y  <- as.real(Co)
            mean.Tr  <- sum(x*weights)/sum(weights);
            mean.Co  <- sum(y*weights)/sum(weights);
            var.Tr  <- sum( ( (x - mean.Tr)^2 )*weights)/sum(weights);
            var.Co  <- sum( ( (y - mean.Co)^2 )*weights)/sum(weights);
            var.ratio  <- var.Tr/var.Co


            mc  <- McNemar2(Tr, Co, weights=weights)
            wc  <- wilcox.test( (as.real(Tr)-as.real(Co))*weights, exact=exact )

          } else {
            sbalance  <- sdiff(Tr, Co, weights)
            
            mean.Tr  <- sum(Tr*weights)/sum(weights);
            mean.Co  <- sum(Co*weights)/sum(weights);
            var.Tr  <- sum( ( (Tr - mean.Tr)^2 )*weights)/sum(weights);
            var.Co  <- sum( ( (Co - mean.Co)^2 )*weights)/sum(weights);
            var.ratio  <- var.Tr/var.Co

            wc  <- wilcox.test( (Tr-Co)*weights, exact=exact )

#            tt  <- t.test((Tr-Co)*weights)
            tt  <- Mt.test(Tr, Co, weights)
          }        
      }


    if (use.McNemar)
      {
        ret  <- list(sdiff=sbalance,mean.Tr=mean.Tr,mean.Co=mean.Co,
                     var.Tr=var.Tr,var.Co=var.Co, p.value=mc$p.value,
                     var.ratio=var.ratio,
                     pdiscordant=mc$pdiscordant, wc=NULL, mc=mc, tt=NULL)        
      } else {
        ret  <- list(sdiff=sbalance,mean.Tr=mean.Tr,mean.Co=mean.Co,
                     var.Tr=var.Tr,var.Co=var.Co, p.value=tt$p.value,
                     var.ratio=var.ratio,
                     pdiscordant=NULL, wc=wc, mc=NULL, tt=tt)
      }

    class(ret) <-  "balanceUV"
    return(ret)
  } #balanceUV

summary.balanceUV  <- function(object, ..., digits=5)
  {

    if (class(object) != "balanceUV") {
      warning("Object not of class 'balanceUV'")
      return(NULL)
    }

    use.McNemar <- FALSE
    if (is.list(object$mc))
      use.McNemar <- TRUE

    if (use.McNemar)
      {
        cat("mean treatment......", format(object$mean.Tr, digits=digits),"\n")
        cat("mean control........", format(object$mean.Co, digits=digits),"\n")            
#       cat("Wilcoxon pval.......", format.pval(wc$p.value,digits=digits), "\n")
        cat("var ratio (Tr/Co)...", format(object$var.ratio, digits=digits),"\n")
        cat("Discordant prop.....", format(object$pdiscordant,digits=digits),"\n")
        cat("McNemar pval........", format.pval(object$p.value,digits=digits), "\n")
      } else {
        cat("mean treatment......", format(object$mean.Tr, digits=digits),"\n")
        cat("mean control........", format(object$mean.Co, digits=digits),"\n")
        cat("sdiff...............", format(object$sdiff, digits=digits),"\n")            
#       cat("Wilcoxon pval.......", format.pval(wc$p.value,digits=digits), "\n")
        cat("T-test pval.........", format.pval(object$tt$p.value,digits=digits), "\n")            
        cat("var ratio (Tr/Co)...", format(object$var.ratio, digits=digits),"\n")                
      }
    
    cat("\n")        
  } #end of summary.balanceUV




McNemar  <- function(Tr, Co, weights=rep(1,length(Tr)))
{
#SEE MCNEMAR2 FOR GENERAL FUNCTION  
#McNemar's test
#mcnemar.test(x, y = NULL, correct = TRUE)
#McNemar's test of symmetry is appropriate for parallel measures from
#matched cases as well as for repeated measures on a single set of
#cases. In this case, McNemar's test of symmetry is equivalent to
#Cochran's Q.
#
#Siegel, S. Nonparametric Methods for the Behavioral Sciences. New
#York: McGraw-Hill, 1956. p. 63 (when both variables are two-point
#scales, McNemar's test of symmetry and McNemar's test for the
#significance of changes are equivalent); Bowker, A. H., A test for
#symmetry in contingency tables. Journal of the American Statistical
#Association 43 (1948): 572-574.

#page 148ff Argesti
  
  obs  <- sum(weights);
  p1.  <- sum(Tr*weights)/obs;
  p.1  <- sum(Co*weights)/obs;
  p1  <- p1.;
  p2  <- p.1;
  mc.table.obs  <-  as.matrix(table(Tr, Co));
  mc.table  <-  mc.table.obs/obs;
  p11  <- mc.table[1,1];
  p12  <- mc.table[1,2];
  p21  <- mc.table[2,1];
  p22  <- mc.table[2,2];
  
  #Vd  <- (p1.*(1-p1.) + p.1*(1-p.1) - 2*(p11*p22-p12*p21))/obs;
  #Sd  <- sqrt(Vd);
  #d   <- p1-p2;

  #
  #cat("Mcnemar 10.2 test: ", d/Sd, (1-pnorm(abs(d/Sd)))*2,"\n");

  n11.indx  <- Tr==TRUE  & Co==TRUE
  n12.indx  <- Tr==TRUE  & Co==FALSE
  n21.indx  <- Tr==FALSE & Co==TRUE
  n22.indx  <- Tr==FALSE & Co==FALSE
    
  n11  <- sum(n11.indx*weights)
  n12  <- sum(n12.indx*weights)
  n21  <- sum(n21.indx*weights)
  n22  <- sum(n22.indx*weights)
  
  mc  <- (n12-n21)/sqrt(n12 + n21);
  pdiscordant= (n12+n21)/obs

  #this matches the results of mcnemar.test without the continuity correction
  #cat("Mcnemar 10.3 test: ", mc, ,"\n");
  
  # mcnemar  <- mcnemar.test(Tr, Co,correct = FALSE);
  p.value  <- (1-pnorm(abs(mc)))*2;
  return(list(statistic=mc,p.value=p.value,pdiscordant=pdiscordant))
}


McNemar2 <- function (Tr, Co, correct = TRUE, weights=rep(1,length(Tr)))
{
  x  <- Tr
  y  <- Co
  if (is.matrix(x)) {
    stop("this version of McNemar cannot handle x being a matrix")
  } else {
    if (is.null(y)) 
      stop("if x is not a matrix, y must be given")
    if (length(x) != length(y)) 
      stop("x and y must have the same length")
    DNAME <- paste(deparse(substitute(x)), "and", deparse(substitute(y)))
    OK <- complete.cases(x, y)
    x <- factor(x[OK])
    y <- factor(y[OK])
    r <- nlevels(x)
    if ((r < 2) || (nlevels(y) != r))
      {
        stop("x and y must have the same number of levels (minimum 2)")
      }
  }
  tx <- table(x, y)
  facs  <- levels(x)
  txw  <- tx
  for(i in 1:r)
    {
      for(j in 1:r)
        {
          indx  <- x==facs[i] & y==facs[j]
          txw[i,j]  <- sum(weights[indx]);
        }
    }
  pdiscordant  <- sum( ( (x!=y)*weights )/sum(weights) )
  x  <- txw
  
  PARAMETER <- r * (r - 1)/2
  METHOD <- "McNemar's Chi-squared test"
  if (correct && (r == 2) && any(x - t(x))) {
    y <- (abs(x - t(x)) - 1)
    METHOD <- paste(METHOD, "with continuity correction")
  } else y <- x - t(x)
  x <- x + t(x)
  STATISTIC <- sum(y[upper.tri(x)]^2/x[upper.tri(x)])
  PVAL <- pchisq(STATISTIC, PARAMETER, lower = FALSE)
  names(STATISTIC) <- "McNemar's chi-squared"
  names(PARAMETER) <- "df"

  RVAL <- list(statistic = STATISTIC, parameter = PARAMETER, 
               p.value = PVAL, method = METHOD, data.name = DNAME,
               pdiscordant=pdiscordant)
  class(RVAL) <- "htest"
  return(RVAL)
}

ks<-function(x,y,w=F,sig=T){
#  Compute the Kolmogorov-Smirnov test statistic
#
# Code for the Kolmogorov-Smirnov test is adopted from the Splus code
# written by Rand R. Wilcox for his book titled "Introduction to
# Robust Estimation and Hypothesis Testing." Academic Press, 1997.
#
#  Also see 
#@book( knuth1998,
#  author=       {Knuth, Donald E.},
#  title=        {The Art of Computer Programming, Vol. 2: Seminumerical Algorithms},
#  edition=      "3rd",
#  publisher=    "Addison-Wesley", address= "Reading: MA", 
#  year=         1998
#)
# and Wilcox 1997 
#
#  w=T computes the weighted version instead. 
#  sig=T indicates that the exact significance level is to be computed.
#  If there are ties, the reported significance level is exact when
#  using the unweighted test, but for the weighted test the reported
#  level is too high.
#
#  This function uses the functions ecdf, kstiesig, kssig and kswsig
#
#  This function returns the value of the test statistic, the approximate .05
#  critical value, and the exact significance level if sig=T.
#
#  Missing values are automatically removed
#
x<-x[!is.na(x)]
y<-y[!is.na(y)]
w<-as.logical(w)
sig<-as.logical(sig)
tie<-logical(1)
tie<-F
siglevel<-NA
z<-sort(c(x,y))  # Pool and sort the observations
for (i in 2:length(z))if(z[i-1]==z[i])tie<-T #check for ties
v<-1   # Initializes v
for (i in 1:length(z))v[i]<-abs(ecdf(x,z[i])-ecdf(y,z[i]))
ks<-max(v)
crit<-1.36*sqrt((length(x)+length(y))/(length(x)*length(y))) # Approximate
#                                                       .05 critical value
if(!w && sig && !tie)siglevel<-kssig(length(x),length(y),ks)
if(!w && sig && tie)siglevel<-kstiesig(x,y,ks)
if(w){
crit<-(max(length(x),length(y))-5)*.48/95+2.58+abs(length(x)-length(y))*.44/95
if(length(x)>100 || length(y)>100){
print("When either sample size is greater than 100,")
print("the approximate critical value can be inaccurate.")
print("It is recommended that the exact significance level be computed.")
}
for (i in 1:length(z)){
temp<-(length(x)*ecdf(x,z[i])+length(y)*ecdf(y,z[i]))/length(z)
temp<-temp*(1.-temp)
v[i]<-v[i]/sqrt(temp)
}
v<-v[!is.na(v)]
ks<-max(v)*sqrt(length(x)*length(y)/length(z))
if(sig)siglevel<-kswsig(length(x),length(y),ks)
if(tie && sig){
print("Ties were detected. The reported significance level")
print("of the weighted Kolmogorov-Smirnov test statistic is not exact.")
}}
#round off siglevel in a nicer way
if(is.real(ks) & is.real(crit) & !is.na(ks) & !is.na(crit))
  {
    if (is.na(siglevel) & ks < crit)
      {
        siglevel  <- 0.99999837212332
      }
    if (is.real(siglevel) & !is.na(siglevel))
      {
        if (siglevel < 0)
          siglevel  <- 0
      }
  }

list(test=ks,critval=crit,pval=siglevel)
}


kssig<-function(m,n,val){
#
#    Compute significance level of the  Kolmogorov-Smirnov test statistic
#    m=sample size of first group
#    n=sample size of second group
#    val=observed value of test statistic
#
  cmat<-matrix(0,m+1,n+1)
  umat<-matrix(0,m+1,n+1)
  for (i in 0:m){
    for (j in 0:n)cmat[i+1,j+1]<-abs(i/m-j/n)
  }
  cmat<-ifelse(cmat<=val,1e0,0e0)
  for (i in 0:m){
    for (j in 0:n)if(i*j==0)umat[i+1,j+1]<-cmat[i+1,j+1]
    else umat[i+1,j+1]<-cmat[i+1,j+1]*(umat[i+1,j]+umat[i,j+1])
  }
  term<-lgamma(m+n+1)-lgamma(m+1)-lgamma(n+1)
  kssig<-1.-umat[m+1,n+1]/exp(term)
  return(kssig)
}

kstiesig<-function(x,y,val){
#
#    Compute significance level of the  Kolmogorov-Smirnov test statistic
#    for the data in x and y.
#    This function allows ties among the  values.
#    val=observed value of test statistic
#
m<-length(x)
n<-length(y)
z<-c(x,y)
z<-sort(z)
cmat<-matrix(0,m+1,n+1)
umat<-matrix(0,m+1,n+1)
for (i in 0:m){
for (j in 0:n){
if(abs(i/m-j/n)<=val)cmat[i+1,j+1]<-1e0
k<-i+j
if(k > 0 && k<length(z) && z[k]==z[k+1])cmat[i+1,j+1]<-1
}
}
for (i in 0:m){
for (j in 0:n)if(i*j==0)umat[i+1,j+1]<-cmat[i+1,j+1]
else umat[i+1,j+1]<-cmat[i+1,j+1]*(umat[i+1,j]+umat[i,j+1])
}
term<-lgamma(m+n+1)-lgamma(m+1)-lgamma(n+1)
kstiesig<-1.-umat[m+1,n+1]/exp(term)
kstiesig
}

ecdf<-function(x,val){
#  compute empirical cdf for data in x evaluated at val
#  That is, estimate P(X <= val)
#
ecdf<-length(x[x<=val])/length(x)
ecdf
}

kswsig<-function(m,n,val){
#
#    Compute significance level of the weighted
#    Kolmogorov-Smirnov test statistic
#
#    m=sample size of first group
#    n=sample size of second group
#    val=observed value of test statistic
#
mpn<-m+n
cmat<-matrix(0,m+1,n+1)
umat<-matrix(0,m+1,n+1)
for (i in 1:m-1){
for (j in 1:n-1)cmat[i+1,j+1]<-abs(i/m-j/n)*sqrt(m*n/((i+j)*(1-(i+j)/mpn)))
}
cmat<-ifelse(cmat<=val,1,0)
for (i in 0:m){
for (j in 0:n)if(i*j==0)umat[i+1,j+1]<-cmat[i+1,j+1]
else umat[i+1,j+1]<-cmat[i+1,j+1]*(umat[i+1,j]+umat[i,j+1])
}
term<-lgamma(m+n+1)-lgamma(m+1)-lgamma(n+1)
kswsig<-1.-umat[m+1,n+1]/exp(term)
kswsig
}

Mks.test  <- function (x, y, ..., alternative = c("two.sided", "less", "greater"), 
                       exact = NULL) 
{
  package  <- "ctest"
  if ( (as.real(R.Version()$major) > 0) & (as.real(R.Version()$minor) >= 9) )
    {
      package  <- "stats"
    }

  alternative <- match.arg(alternative)
  DNAME <- deparse(substitute(x))
  x <- x[!is.na(x)]
  n <- length(x)
  if (n < 1) 
    stop("Not enough x data")
  PVAL <- NULL
  if (is.numeric(y)) {
    DNAME <- paste(DNAME, "and", deparse(substitute(y)))
    y <- y[!is.na(y)]
    n.x <- as.double(n)
    n.y <- length(y)
    if (n.y < 1) 
      stop("Not enough y data")
    if (is.null(exact)) 
      exact <- (n.x * n.y < 10000)
    METHOD <- "Two-sample Kolmogorov-Smirnov test"
    TIES <- FALSE
    n <- n.x * n.y/(n.x + n.y)
    w <- c(x, y)
    z <- cumsum(ifelse(order(w) <= n.x, 1/n.x, -1/n.y))
    if (length(unique(w)) < (n.x + n.y)) {
      z <- z[c(which(diff(sort(w)) != 0), n.x + n.y)]
      TIES <- TRUE
    }
    STATISTIC <- switch(alternative, two.sided = max(abs(z)), 
                        greater = max(z), less = -min(z))
    if (exact && alternative == "two.sided" && !TIES) 
      PVAL <- 1 - .C("psmirnov2x", p = as.double(STATISTIC), 
                     as.integer(n.x), as.integer(n.y), PACKAGE = package)$p
  }  else {
    if (is.character(y)) 
      y <- get(y, mode = "function")
    if (mode(y) != "function") 
      stop("y must be numeric or a string naming a valid function")
    METHOD <- "One-sample Kolmogorov-Smirnov test"
    x <- y(sort(x), ...) - (0:(n - 1))/n
    STATISTIC <- switch(alternative, two.sided = max(c(x, 
                                       1/n - x)), greater = max(1/n - x), less = max(x))
  }
  names(STATISTIC) <- switch(alternative, two.sided = "D", 
                             greater = "D^+", less = "D^-")
  pkstwo <- function(x, tol = 1e-06) {
    if (is.numeric(x)) 
      x <- as.vector(x)
    else stop("Argument x must be numeric")
    p <- rep(0, length(x))
    p[is.na(x)] <- NA
    IND <- which(!is.na(x) & (x > 0))
    if (length(IND) > 0) {
      p[IND] <- .C("pkstwo", as.integer(length(x)), p = as.double(x[IND]), 
                   as.double(tol), PACKAGE = package)$p
    }
    return(p)
  }
  if (is.null(PVAL)) {
    PVAL <- ifelse(alternative == "two.sided", 1 - pkstwo(sqrt(n) * 
                     STATISTIC), exp(-2 * n * STATISTIC^2))
  }
  RVAL <- list(statistic = STATISTIC, p.value = PVAL, alternative = alternative, 
               method = METHOD, data.name = DNAME)
  class(RVAL) <- "htest"
  return(RVAL)
} #end of Mks.test

Mt.test  <- function(Tr, Co, weights)
  {
    v1  <- Tr-Co
    estimate  <- sum(v1*weights)/sum(weights)
    var1  <- sum( ((v1-estimate)^2)*weights )/( sum(weights)*sum(weights) )

    statistic  <- estimate/sqrt(var1)
    parameter  <- Inf
    p.value    <- (1-pnorm(abs(statistic)))*2

    z  <- list(statistic=statistic, parameter=parameter, p.value=p.value,
               estimate=estimate)
    return(z)
  } #end of Mt.test



MatchBalance <- function(formul, data=NULL, match.out=NULL, MV=TRUE, maxit=1000, weights=rep(1,nrow(data)),
                         nboots=0, digits=5, verbose=1, ...)
  {

    if(!is.list(match.out) & !is.null(match.out)) {
      warning("'Match' object contains no valid matches")
      match.out  <- NULL
    }

    if ( (class(match.out) != "Match") & (!is.null(match.out)) ) {
      warning("Object not of class 'Match'")
      match.out  <- NULL
    }

    if (is.null(data))
      {
        datain <- NULL
        xdata <- as.data.frame(get.xdata(formul,datafr=environment(formul)))
        ydata <- as.data.frame(get.ydata(formul,datafr=environment(formul)))
        Tr    <- ydata
        data  <- cbind(ydata,xdata)        
      } else {
        data  <- as.data.frame(data)
        datain <- data
        xdata  <- as.data.frame(get.xdata(formul, data))
        Tr  <- get.ydata(formul, data)        
      }

    if (sum(is.na(data)!=0))
      stop("MatchBalance: NAs found in data input")

    if (nboots!=0 & nboots < 10)
      {
        nboots <- 10
        warning("at least 10 nboots must be run")
      }    
    
    nvars  <- ncol(xdata)
    names.xdata  <- names(xdata)


    if (verbose > 0)
      {
        for( i in 2:nvars)
          {
            cat("\n***** (V",i-1,") ", names.xdata[i]," *****\n",sep="")
            
            cat("before matching:\n")
            foo  <-  balanceUV(xdata[,i][Tr==1],xdata[,i][Tr==0], weights=weights)
            summary(foo, digits=digits)
            
            if (!is.null(match.out))
              {
                cat("after  matching:\n")    
                foo  <- balanceUV(xdata[,i][match.out$index.treated],xdata[,i][match.out$index.control],
                                  weights=match.out$weights)
                summary(foo, digits=digits)                
              }
          }
        
        if (MV)  {
          cat("...estimating Kolmogorov-Smirnov and Chi-square tests...\n")
          if (nboots > 0)
            cat("  ",nboots,"bootstraps being run\n")
          cat("\n")
          
          ml  <- balanceMV(formul=formul, data=datain, match.out=match.out,
                           maxit=maxit, weights=weights, nboots=nboots, verbose=verbose, ...)
          summary.balanceMV(ml, digits=digits)
        }  else  {
          ml  <- NULL
        }
      } else {
        for( i in 2:nvars)
          {
            foo  <-  balanceUV(xdata[,i][Tr==1],xdata[,i][Tr==0], weights=weights)
            
            if (!is.null(match.out))
              {
                foo  <- balanceUV(xdata[,i][match.out$index.treated],xdata[,i][match.out$index.control],
                                  weights=match.out$weights)
              }
          }
        
        if (MV)  {
          ml  <- balanceMV(formul=formul, data=datain, match.out=match.out,
                           maxit=maxit, weights=weights, nboots=nboots, verbose=verbose, ...)
        }  else  {
          ml  <- NULL
        }        
      }#verbose end
    
    return(list(mv=ml,uv=foo))
  } #end of MatchBalance


balanceMV  <- function(formul, data=NULL, match.out=NULL, maxit=1000, weights=rep(1,nrow(data)), nboots=0,
                       verbose=0, ...)
  {

    if(!is.list(match.out) & (!is.null(match.out))) {
      warning("'Match' object contains no valid matches")
      match.out  <- NULL
    }

    if ( (class(match.out) != "Match") & (!is.null(match.out)) ) {
      warning("Object not of class 'Match'")
      match.out  <- NULL
    }

    if (is.null(data))
      {
        data  <- as.data.frame(model.frame(formul))
        xdata <- get.xdata(formul,datafr=environment(formul))
        Tr    <- get.ydata(formul,datafr=environment(formul))
      } else {
        data  <- as.data.frame(data)
        xdata <- get.xdata(formul, data)
        Tr <- get.ydata(formul, data)
      }

    if (sum(is.na(data)!=0))
      stop("MatchBalance: NAs found in data input")

    if (nboots!=0 & nboots < 10)
      {
        nboots <- 10
        warning("at least 10 nboots must be run")
      }

    
    if (!is.null(data$weight37172))
      stop("balanceMV(): data$weight37172 cannot exist")

    data$weight37172  <- weights

    ddata  <- list()
    ddata$Tr <- Tr
    ddata$nboots <- nboots
    ddata$weights.unmatched <- data$weight37172        

    #FULL SAMPLE RUN
    t1  <- glm(formul, family=binomial(link=logit), weights=weight37172,
               control=glm.control(maxit=maxit, ...), data=data)

    t1$df <- t1$df.null-t1$df.residual
    t1$stat <-  (t1$null.deviance-t1$deviance)
    t1$p.value  <- 1-pchisq((t1$null.deviance-t1$deviance),t1$df)

    t1$treated.fitted  <- t1$fitted.values[Tr==1]
    t1$control.fitted  <- t1$fitted.values[Tr==0]

    bm.ks  <- Mks.test(t1$treated.fitted, t1$control.fitted)

    #BOOTSTRAP SAMPLE RUN
    if (nboots > 0)
      {
        obs <- nrow(data)
        sindx <- 1:obs
        dev.stats.unmatched <- matrix(0, nrow=nboots, ncol=2)
        p.boot <- 0
        k.boot <- 0

        if (verbose > 1)
          cat("unmatched bootstraps:\n")

        intercept <- FALSE
        if (sum(xdata[,1]==rep(1,nrow(xdata)))==nrow(xdata))
          {
            intercept <- TRUE
            xdata <- xdata[,2:ncol(xdata)]
          }

        
        for (s in 1:nboots)
          {
            if (verbose > 1)
              cat("s: ",s,"\n")
            ssample <- sample(sindx,obs, replace=TRUE, prob=weights)

            if (ncol(as.matrix(xdata)) > 1)
              {
                sxdata <- xdata[ssample,]
              } else {
                sxdata <- as.matrix(xdata[ssample])
              }
            sTr <- Tr[ssample]
            sweight <- data$weight37172[ssample]

            if (intercept)
              {
                s1  <- glm(sTr~sxdata, family=binomial(link=logit), weights=sweight,
                           control=glm.control(maxit=maxit, ...))
              } else {
                s1  <- glm(sTr~sxdata-1, family=binomial(link=logit), weights=sweight,
                           control=glm.control(maxit=maxit, ...))                
              }
            
            s.ks <- Mks.test(s1$fitted.values[sTr==1], s1$fitted.values[sTr==0])
            dev.stats.unmatched[s,1] <-  s.ks$statistic - bm.ks$statistic

            dev.stats.unmatched[s,2] <- (s1$null.deviance-s1$deviance)-t1$stat

#            w <- sweight[sTr==1]
#            meanp.Tr <- sum(s1$fitted[sTr==1]*w)/sum(w)
            
#            w <- sweight[sTr==0]
#            meanp.Co <- sum(s1$fitted[sTr==0]*w)/sum(w)            

#            dev.stats.unmatched[s,3] <- meanp.Tr - meanp.Co

            if (bm.ks$statistic < dev.stats.unmatched[s,1])
              k.boot <- k.boot + 1
            if (t1$stat < dev.stats.unmatched[s,2])
              p.boot <- p.boot + 1
          } #end of bootstrap loop

        p.boot <- p.boot/(nboots+1)
        k.boot <- k.boot/(nboots+1)
      } else {
        p.boot <- NULL
        k.boot <- NULL
        dev.stats.unmatched <- NULL
      }#if nboots
    

    if(!is.null(match.out))
      {
        Mdata  <- rbind(as.data.frame(data[match.out$index.treated,]), data[match.out$index.control,])
        Mdata$weight37172  <- c(match.out$weights*weights[match.out$index.treated], 
                                match.out$weights*weights[match.out$index.control])
	MTr <- c(rep(1,length(match.out$index.treated)), rep(0,length(match.out$index.control)))

        xdata <- as.data.frame(get.xdata(formul, Mdata))
        xdata <- as.matrix(xdata)
        intercept <- FALSE
        if (sum(xdata[,1]==rep(1,nrow(xdata)))==nrow(xdata))
          {
            intercept <- TRUE
            xdata <- xdata[,2:ncol(xdata)]

            Mt1  <- glm(MTr~xdata, family=quasibinomial(link=logit), 
                        control=glm.control(maxit=maxit, ...),
                        weights=Mdata$weight37172)
          } else {
            Mt1  <- glm(MTr~xdata-1, family=quasibinomial(link=logit), weights=Mdata$weight37172,
                        control=glm.control(maxit=maxit, ...))                        
          }

        Mdata0  <- list()
        Mdata0$y  <- MTr
        Mdata0$weight37172  <- Mdata$weight37172
        
        Mt0  <- glm(y~1, family=quasibinomial(link=logit), weights=Mdata0$weight37172,
                    control=glm.control(maxit=maxit, ...), data=Mdata0)
        
        rd0<-residuals(Mt0) # deviance residuals
        rd1<-residuals(Mt1) # deviance residuals
        Mt1$df <- Mt1$df.null-Mt1$df.residual
        #the square root of the weights is already included in the residuals
        wdeviance1  <- sum( rd1^2 *sqrt(Mdata$weight37172) )
        wdeviance0  <- sum( rd0^2 *sqrt(Mdata$weight37172) )
        rr  <- (rd1^2)*sqrt(Mdata$weight37172)    
        Mt1$dispersion <- sum( rr )/( sum(Mdata$weight37172) - Mt1$df)
        Mt1$stat  <- (wdeviance0-wdeviance1)/Mt1$dispersion
        Mt1$p.value  <- 1-pchisq(Mt1$stat,Mt1$df)

        Mt1$treated.fitted  <- Mt1$fitted.values[MTr==1]
        Mt1$control.fitted  <- Mt1$fitted.values[MTr==0]
        
        am.ks  <- Mks.test(Mt1$treated.fitted, Mt1$control.fitted)

	ddata$Tr.matched <- MTr        
	ddata$weights.matched <- Mdata$weight37172
	ddata$weights <- match.out$weights
        ddata$index.treated.indata  <- match.out$index.treated.indata
        ddata$index.control.indata  <- match.out$index.control.indata

        #BOOTSTRAP SAMPLE RUN
        if (nboots > 0)
          {
            obs <- nrow(Mdata)
            sindx <- 1:obs
            dev.stats.matched <- matrix(0, nrow=nboots, ncol=2)
            Mp.boot <- 0
            Mk.boot <- 0

            if (verbose > 1)
              cat("matched bootstraps:\n")

            for (s in 1:nboots)
              {
                if (verbose > 1)
                  cat("s: ",s,"\n")
                ssample <- sample(sindx,obs, replace=TRUE, prob=Mdata$weights37172)

                if (ncol(as.matrix(xdata)) > 1)
                  {
                    sxdata <- xdata[ssample,]
                  } else {
                    sxdata <- as.matrix(xdata[ssample])
                  }
                sMTr <- MTr[ssample]
                sMweight <- Mdata$weight37172[ssample]

                if (intercept)
                  {
                    s1  <- glm(sMTr~sxdata, family=binomial(link=logit), weights=sMweight,
                               control=glm.control(maxit=maxit, ...))
                  } else {
                    s1  <- glm(sMTr~sxdata-1, family=binomial(link=logit), weights=sMweight,
                               control=glm.control(maxit=maxit, ...))
                  }                
                
                s0  <-  glm(sMTr~1, family=quasibinomial(link=logit), weights=sMweight,
                            control=glm.control(maxit=maxit, ...))

                srd1<-residuals(s1) # deviance residuals                                
                srd0<-residuals(s0) # deviance residuals
                #the square root of the weights is already included in the residuals
                wdeviance1  <- sum( srd1^2 *sqrt(sMweight) )
                wdeviance0  <- sum( srd0^2 *sqrt(sMweight) )
                rr  <- (srd1^2)*sqrt(sMweight)    
                sdispersion <- sum( rr )/( sum(sMweight) - Mt1$df)
                sstat  <- (wdeviance0-wdeviance1)/sdispersion

                s.ks <- Mks.test(s1$fitted.values[sMTr==1], s1$fitted.values[sMTr==0])
                dev.stats.matched[s,1] <-  s.ks$statistic - am.ks$statistic

                dev.stats.matched[s,2] <-   sstat - Mt1$stat

#                w <- sMweight[sMTr==1]
#                meanp.Tr <- sum(s1$fitted[sMTr==1]*w)/sum(w)
            
#                w <- sMweight[sMTr==0]
#                meanp.Co <- sum(s1$fitted[sMTr==0]*w)/sum(w)            

#                dev.stats.matched[s,3] <- meanp.Tr - meanp.Co                

                if (am.ks$statistic < dev.stats.matched[s,1])
                  Mk.boot <- Mk.boot + 1            
                if (Mt1$stat < dev.stats.matched[s,2])
                  Mp.boot <- Mp.boot + 1
              } #end of bootstrap loop
            
            Mp.boot <- Mp.boot/(nboots+1)
            Mk.boot <- Mk.boot/(nboots+1)        
          }  else {
            Mp.boot <- NULL
            Mk.boot <- NULL
            dev.stats.matched <- NULL
          }#if nboots
        
      } else {
        am.ks  <- NULL
        Mt1  <- NULL

        Mp.boot <- NULL
        Mk.boot <- NULL
        dev.stats.matched <- NULL        
      }

    z  <- list(pval.kboot.unmatched=k.boot, pval.kboot.matched=Mk.boot,
               pval.cboot.unmatched=p.boot, pval.cboot.matched=Mp.boot,                
               logit.unmatched=t1,logit.matched=Mt1,               
               ks.unmatched=bm.ks, ks.matched=am.ks,
               dev.stats.unmatched=dev.stats.unmatched,
               dev.stats.matched=dev.stats.matched,
               data=ddata)
    class(z)  <- "balanceMV"

    return(z)
  } #end of balanceMV

summary.balanceMV  <- function(object, ..., digits=5)
  {
    if (class(object) != "balanceMV") {
      warning("Object not of class 'balanceMV'")
      return(NULL)
    }

    t1.df <- object$logit.unmatched$df.null-object$logit.unmatched$df.residual
    t1.stat <-  object$logit.unmatched$null.deviance-object$logit.unmatched$deviance

    if(!is.null(object$ks.matched))
      {    
        Mt1.df  <- object$logit.matched$df.null-object$logit.matched$df.residual
        Mt1.stat  <- object$logit.matched$null.deviance-object$logit.matched$deviance
      }

    cat("\nBefore Matching:\n")
    w <- object$data$weights.unmatched[object$data$Tr==1]
    mean.tr.unmatched <- sum(object$logit.unmatched$fitted[object$data$Tr==1]*w)/sum(w)

    cat("Mean Probability of Treatment for Treated Observations:",
        format(mean.tr.unmatched,digits=digits),"\n")
    
    w <- object$data$weights.unmatched[object$data$Tr==0]
    mean.co.unmatched <- sum(object$logit.unmatched$fitted[object$data$Tr==0]*w)/sum(w)
    
    cat("Mean Probability of Treatment for Control Observations:",
        format(mean.co.unmatched,digits=digits),"\n")
    
#    if( object$data$nboots > 0)
#      {
#        m.boot <- 0
#        diff <- mean.tr.unmatched - mean.co.unmatched
#        for (s in 1:object$data$nboots)
#          {
#            if ( diff < (object$dev.stats.unmatched[s,3]) )
#              m.boot <- m.boot + 1
#          }
#        m.boot <- m.boot/(object$data$nboots+1)
#        cat("bootstrap p.value for equal means:",format.pval(m.boot,digits=digits),"\n")
#      } 

    if(!is.null(object$ks.matched))
      {
        mean.tr.matched <- 
          sum(object$logit.matched$fitted[object$data$Tr.matched==1]*object$data$weights)/sum(object$data$weights)

        mean.co.matched <- 
          sum(object$logit.matched$fitted[object$data$Tr.matched==0]*object$data$weights)/sum(object$data$weights)

        cat("\nAfter Matching:\n")    
        cat("Mean Probability of Treatment for Treated Observations:", format(mean.tr.matched, digits=digits),"\n")
        cat("Mean Probability of Treatment for Control Observations:", format(mean.co.matched, digits=digits),"\n")
#        if( object$data$nboots > 0)
#          {
#            m.boot <- 0
#            diff <- mean.tr.matched - mean.co.matched
#            for (s in 1:object$data$nboots)
#              {
#                if ( diff < (object$dev.stats.matched[s,3]))
#                  m.boot <- m.boot + 1
#              }
#            m.boot <- m.boot/(object$data$nboots+1)
#            cat("bootstrap p.value for equal means:",format.pval(m.boot,digits=digits),"\n")
#          }        
      }

    cat("\nKolmogorov-Smirnov Test for Balance Before Matching:\n")
    cat("statistic:",format(object$ks.unmatched$statistic,digits=digits), " p-val: ",
        format.pval(object$ks.unmatched$p.value,digits=digits),"\n")
    if( object$data$nboots > 0)
      cat("bootstrap p-value:",format.pval(object$pval.kboot.unmatched,digits=digits),"\n")      
      

    if(!is.null(object$ks.matched))
      {    
        cat("\nKolmogorov-Smirnov Test for Balance After Matching:\n")
        cat("statistic:",format(object$ks.matched$statistic,digits=digits), " p-val: ",
            format.pval(object$ks.matched$p.value,digits=digits),"\n")
        if( object$data$nboots > 0)
          cat("bootstrap p-value:",format.pval(object$pval.kboot.matched,digits=digits),"\n")      
      }

    cat("\nChi-Square Deviance Test for Balance Before Matching:\n")
    cat("statistic:",format(t1.stat,digits=digits),
        " p-val:",format.pval(object$logit.unmatched$p.value,digits=digits),
        "df:",format(t1.df,digits=digits),"\n")
    if( object$data$nboots > 0)
      cat("bootstrap p-value:",format.pval(object$pval.cboot.unmatched,digits=digits),"\n")          

    if(!is.null(object$ks.matched))
      {
        cat("\nChi-Square Deviance Test for Balance After Matching:\n")
        cat("statistic:",format(Mt1.stat,digits=digits),
            " p-val:",format.pval(object$logit.matched$p.value,digits=digits),"df:",
            format(Mt1.df,digits=digits),"\n")
        if( object$data$nboots > 0)
          cat("bootstrap p-value:",format.pval(object$pval.cboot.matched,digits=digits),"\n")                  
      }

    cat("\n\n")
  }#end of summary.Match


get.xdata <- function(formul, datafr) {
  t1 <- terms(formul, data=datafr);
  if (length(attr(t1, "term.labels"))==0 & attr(t1, "intercept")==0) {
    m <- NULL;  # no regressors specified for the model matrix
  } else {
    m <- model.matrix(formul, data=datafr, drop.unused.levels = TRUE);
  }
  return(m);
}


# get.ydata:
# Return response vector corresponding to the formula in formul
# 
get.ydata <- function(formul, datafr) {
  t1 <- terms(formul, data=datafr);
  if (length(attr(t1, "response"))==0) {
    m <- NULL;  # no response variable specified
  }  else {
    m <- model.response(model.frame(formul, data=datafr));
  }
  return(m);
}
