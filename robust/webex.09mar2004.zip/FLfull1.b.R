#
# This estimates the Florida model for five categories

options(width=120);
set.seed(19342)

if (!exists("multinomRob"))
	library(multinomRob)

## read data
dta <- read.table("REPLICATION_DATA.asc", header=TRUE)

dta$pdemnader96 <- dta$pdem96 + dta$pnader96 ;
dta$other00 <- dta$other.candidates00 ;

## See names
names(dta)
## And define a model using these names:
model <- list(buchanan00 ~ pperot96 + pChangeRepRV00 + pcuban00 + pr1...1.,
              nader00    ~ pdemnader96 +  pGreenRV00 + pcuban00 +   pr1...2.,
              gore00     ~ pdem96 + pChangeDemRV00 + pcuban00 + pr1...3.,
              bush00     ~ prep96 + pChangeRepRV00 + pcuban00 + pr1...4.,
              other00    ~ 0
              )

## Set parameters for Genoud
zz.genoud.parms <- list(wait.generations      = 30,
                        pop.size              = 3000,
                        P5                    = 750,
                        scale.domains         = 4,
                        MemoryMatrix          = TRUE
                        )

load("FLfull1.a.RData");
starts <- muFLfull1$mtanh$coeffvec;

muFLfull1 <- multinomRob(model,
                 data=dta,
                 starting.values = starts,
                 genoud.parms   = zz.genoud.parms,
                 print.level    = 3 ) 

summary(muFLfull1, weights=TRUE)

save(muFLfull1, file="FLfull1.b.RData");
