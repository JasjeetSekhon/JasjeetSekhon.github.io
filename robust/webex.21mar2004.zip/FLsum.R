# print summaries of the FLfull1.R results

options(width=120);

if (!exists("multinomRob"))
	library(multinomRob)

## read data
dta <- read.table("REPLICATION_DATA.asc", header=TRUE)

dta$pdemnader96 <- dta$pdem96 + dta$pnader96 ;
dta$other00 <- dta$other.candidates00 ;

load("FLfull1.RData");

sum1 <- summary(muFLfull1, weights=TRUE)

sum1$name <- dta$name;

print(sum1);

