#
#  multinomRob
#
#  Walter R. Mebane, Jr.
#  Cornell University
#  http://macht.arts.cornell.edu/wrm1/
#  wrm1@macht.arts.cornell.edu
#
#  Jasjeet Singh Sekhon 
#  Harvard University
#  http://jsekhon.fas.harvard.edu/
#  jsekhon@fas.harvard.edu
#
#  $Id: newtanh8a.R,v 1.10 2004/02/17 05:17:01 wrm1 Exp $
#

## *** NOTE:  mGNtanh definition moved into multinomTanh.R ***
