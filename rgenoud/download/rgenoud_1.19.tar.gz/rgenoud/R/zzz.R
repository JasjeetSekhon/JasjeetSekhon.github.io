#  Cornell University
#  http://macht.arts.cornell.edu/wrm1
#  wrm1@macht.arts.cornell.edu
#
#  Jasjeet Singh Sekhon 
#  Harvard University and Lamarck, Inc.
#  http://jsekhon.fas.harvard.edu/
#  jsekhon@fas.harvard.edu
#
#  $Header: /home/jsekhon/xchg/genoud/rgenoud.distribution/sources/RCS/zzz.R,v 1.19 2002/10/19 08:30:28 jsekhon Exp $
#

.First.lib <- function(lib, pkg) library.dynam("rgenoud", pkg, lib)
