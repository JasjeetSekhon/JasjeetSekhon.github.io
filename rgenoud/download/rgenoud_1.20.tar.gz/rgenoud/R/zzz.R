#  Cornell University
#  http://macht.arts.cornell.edu/wrm1
#  wrm1@macht.arts.cornell.edu
#
#  Jasjeet Singh Sekhon 
#  Harvard University and Lamarck, Inc.
#  http://jsekhon.fas.harvard.edu/
#  jsekhon@fas.harvard.edu
#
#  $Header: /home/jsekhon/xchg/genoud/rgenoud.distribution/sources/RCS/zzz.R,v 1.20 2002/11/06 02:12:26 jsekhon Exp $
#

.First.lib <- function(lib, pkg) library.dynam("rgenoud", pkg, lib)
