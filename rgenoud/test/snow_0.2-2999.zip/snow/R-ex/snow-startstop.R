### Name: snow-startstop
### Title: Starting and Stopping SNOW Clusters
### Aliases: getMPIcluster makeMPIcluster makePVMcluster makeSOCKcluster
###   makeCluster stopCluster setDefaultClusterOptions
### Keywords: programming

### ** Examples

  ## Not run: 
##D cl <- makeCluster(c("localhost","localhost"), type = "SOCK")
##D clusterApply(cl, 1:2, get("+"), 3)
##D   
## End(Not run)



