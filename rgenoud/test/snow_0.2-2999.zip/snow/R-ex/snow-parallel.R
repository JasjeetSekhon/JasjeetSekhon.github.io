### Name: snow-parallel
### Title: Higher Level SNOW Functions
### Aliases: parLapply parRapply parCapply parApply parMM parSapply
### Keywords: programming

### ** Examples

  ## Not run: 
##D cl <- makeSOCKcluster(c("localhost","localhost"))
##D parSapply(cl, 1:20, get("+"), 3)
##D   
## End(Not run)



