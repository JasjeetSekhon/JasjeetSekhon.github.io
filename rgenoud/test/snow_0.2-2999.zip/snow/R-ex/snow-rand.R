### Name: snow-rand
### Title: Uniform Random Number Generation in SNOW Clusters
### Aliases: clusterSetupRNG clusterSetupSPRNG clusterSetupRNGstream
### Keywords: programming

### ** Examples

  ## Not run: 
##D clusterSetupSPRNG(cl)
##D clusterSetupSPRNG(cl, seed=1234)
##D clusterSetupRNG(cl, seed=rep(1,6))
##D   
## End(Not run)



