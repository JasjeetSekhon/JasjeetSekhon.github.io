### Name: snow-cluster
### Title: Cluster-Level SNOW Functions
### Aliases: clusterSplit clusterCall clusterApply clusterApplyLB
###   clusterEvalQ clusterExport
### Keywords: programming

### ** Examples

  ## Not run: 
##D cl <- makeSOCKcluster(c("localhost","localhost"))
##D 
##D clusterApply(cl, 1:2, get("+"), 3)
##D 
##D clusterEvalQ(cl, library(boot))
##D 
##D x<-1
##D clusterExport(cl, "x")
##D clusterCall(cl, function(y) x + y, 2)
##D 
##D   
## End(Not run)



