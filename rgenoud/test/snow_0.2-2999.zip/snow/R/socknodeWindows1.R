library(snow)

options(timeout=getClusterOption("timeout"))

slaveLoop(makeSOCKmaster(master="localhost",port=600011))


          
